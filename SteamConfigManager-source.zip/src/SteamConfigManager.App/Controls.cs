using System.Globalization;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace SteamConfigManager.App;

public sealed class BoolVisibilityConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) => value is true ? Visibility.Visible : Visibility.Collapsed;
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => value is Visibility.Visible;
}

public sealed class InverseBoolVisibilityConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) => value is true ? Visibility.Collapsed : Visibility.Visible;
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => value is not Visibility.Visible;
}

/// <summary>Short compositor-friendly transitions. Each transition checks Windows' reduced-motion preference.</summary>
public static class Motion
{
    public static bool Enabled { get; set; } = true;
    public static bool IsAllowed => Enabled && SystemParameters.ClientAreaAnimation && !SystemParameters.HighContrast;

    public static readonly DependencyProperty EnterProperty = DependencyProperty.RegisterAttached(
        "Enter", typeof(bool), typeof(Motion), new PropertyMetadata(false, OnEnterChanged));
    public static void SetEnter(DependencyObject element, bool value) => element.SetValue(EnterProperty, value);
    public static bool GetEnter(DependencyObject element) => (bool)element.GetValue(EnterProperty);

    private static void OnEnterChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        if (d is not FrameworkElement element) return;
        element.Loaded -= EnterLoaded;
        if (e.NewValue is true) element.Loaded += EnterLoaded;
    }

    private static void EnterLoaded(object sender, RoutedEventArgs e) => AnimateIn((FrameworkElement)sender);

    public static void AnimateIn(FrameworkElement element)
    {
        if (!IsAllowed) return;
        var duration = TimeSpan.FromMilliseconds(240);
        var ease = new CubicEase { EasingMode = EasingMode.EaseOut };
        element.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0, 1, duration) { EasingFunction = ease, FillBehavior = FillBehavior.Stop });
        // Preserve existing transforms: never replace application-supplied rotation, layout or scaling.
        var translate = element.RenderTransform as TranslateTransform;
        if (translate is null && (element.RenderTransform is null || element.RenderTransform == Transform.Identity))
        {
            translate = new TranslateTransform();
            element.RenderTransform = translate;
        }
        if (translate is not null && !translate.IsFrozen)
            translate.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(9, 0, duration) { EasingFunction = ease, FillBehavior = FillBehavior.Stop });
    }

    public static readonly DependencyProperty ButtonFeedbackProperty = DependencyProperty.RegisterAttached(
        "ButtonFeedback", typeof(bool), typeof(Motion), new PropertyMetadata(false, OnFeedbackChanged));
    public static void SetButtonFeedback(DependencyObject element, bool value) => element.SetValue(ButtonFeedbackProperty, value);
    public static bool GetButtonFeedback(DependencyObject element) => (bool)element.GetValue(ButtonFeedbackProperty);

    public static readonly DependencyProperty SmoothProgressProperty = DependencyProperty.RegisterAttached(
        "SmoothProgress", typeof(bool), typeof(Motion), new PropertyMetadata(false, OnSmoothProgressChanged));
    public static void SetSmoothProgress(DependencyObject element, bool value) => element.SetValue(SmoothProgressProperty, value);
    public static bool GetSmoothProgress(DependencyObject element) => (bool)element.GetValue(SmoothProgressProperty);

    private static void OnSmoothProgressChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        if (d is not ProgressBar progress) return;
        progress.ValueChanged -= ProgressChanged;
        if (e.NewValue is true) progress.ValueChanged += ProgressChanged;
    }

    private static void ProgressChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (sender is not ProgressBar progress || progress.IsIndeterminate || !IsAllowed) return;
        var previous = e.OldValue;
        var next = e.NewValue;
        _ = progress.Dispatcher.InvokeAsync(() =>
        {
            if (!progress.IsLoaded || progress.IsIndeterminate || !IsAllowed || progress.Maximum <= progress.Minimum) return;
            if (progress.Template?.FindName("PART_Indicator", progress) is not FrameworkElement indicator ||
                progress.Template.FindName("PART_Track", progress) is not FrameworkElement track) return;
            var range = progress.Maximum - progress.Minimum;
            var from = track.ActualWidth * Math.Clamp((previous - progress.Minimum) / range, 0, 1);
            var to = track.ActualWidth * Math.Clamp((next - progress.Minimum) / range, 0, 1);
            indicator.BeginAnimation(FrameworkElement.WidthProperty, new DoubleAnimation(from, to, TimeSpan.FromMilliseconds(220))
            {
                EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut },
                FillBehavior = FillBehavior.Stop
            });
        });
    }

    private static void OnFeedbackChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        if (d is not Control element) return;
        element.MouseEnter -= HoverEnter;
        element.MouseLeave -= HoverLeave;
        element.MouseMove -= MoveLight;
        element.PreviewMouseLeftButtonDown -= Press;
        element.PreviewMouseLeftButtonUp -= Release;
        element.LostMouseCapture -= LostCapture;
        element.PreviewKeyDown -= KeyPress;
        element.PreviewKeyUp -= KeyRelease;
        if (element is RadioButton previousRadio) previousRadio.Checked -= SelectionChanged;
        if (e.NewValue is not true) return;
        element.MouseEnter += HoverEnter;
        element.MouseLeave += HoverLeave;
        element.MouseMove += MoveLight;
        element.PreviewMouseLeftButtonDown += Press;
        element.PreviewMouseLeftButtonUp += Release;
        element.LostMouseCapture += LostCapture;
        element.PreviewKeyDown += KeyPress;
        element.PreviewKeyUp += KeyRelease;
        if (element is RadioButton radio) radio.Checked += SelectionChanged;
    }

    private static void MoveLight(object sender, MouseEventArgs e)
    {
        if (!IsAllowed || sender is not Control control || control.ActualWidth <= 0 || control.ActualHeight <= 0 ||
            control.Template?.FindName("HoverGlow", control) is not Border { Background: RadialGradientBrush } glow) return;
        var brush = (RadialGradientBrush)glow.Background;
        if (brush.IsFrozen) { brush = brush.Clone(); glow.Background = brush; }
        var point = e.GetPosition(control);
        var position = new Point(Math.Clamp(point.X / control.ActualWidth, 0, 1), Math.Clamp(point.Y / control.ActualHeight, 0, 1));
        brush.Center = position;
        brush.GradientOrigin = position;
    }

    private static void SelectionChanged(object sender, RoutedEventArgs e)
    {
        if (sender is not RadioButton radio || !IsAllowed) return;
        var duration = TimeSpan.FromMilliseconds(260);
        var ease = new CubicEase { EasingMode = EasingMode.EaseOut };
        foreach (var name in new[] { "SelectionGlow", "SelectionDot" })
            if (radio.Template?.FindName(name, radio) is UIElement part)
                part.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0, 1, duration) { EasingFunction = ease, FillBehavior = FillBehavior.Stop });
        if (GetMutableScale(radio) is { } scale)
        {
            var animation = new DoubleAnimation(.988, 1, duration) { EasingFunction = ease, FillBehavior = FillBehavior.Stop };
            scale.BeginAnimation(ScaleTransform.ScaleXProperty, animation);
            scale.BeginAnimation(ScaleTransform.ScaleYProperty, animation);
        }
    }

    private static void HoverEnter(object sender, MouseEventArgs e) => SetGlow((Control)sender, 1);
    private static void HoverLeave(object sender, MouseEventArgs e) { SetGlow((Control)sender, 0); SetScale((Control)sender, 1); }
    private static void Press(object sender, MouseButtonEventArgs e) => SetScale((Control)sender, 0.978);
    private static void Release(object sender, MouseButtonEventArgs e) => SetScale((Control)sender, 1);
    private static void LostCapture(object sender, MouseEventArgs e) => SetScale((Control)sender, 1);
    private static void KeyPress(object sender, KeyEventArgs e) { if (e.Key is Key.Space or Key.Enter) SetScale((Control)sender, 0.978); }
    private static void KeyRelease(object sender, KeyEventArgs e) { if (e.Key is Key.Space or Key.Enter) SetScale((Control)sender, 1); }

    private static void SetGlow(Control control, double value)
    {
        if (control.Template?.FindName("HoverGlow", control) is not UIElement glow) return;
        if (!IsAllowed) { glow.BeginAnimation(UIElement.OpacityProperty, null); glow.Opacity = value; return; }
        glow.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(value, TimeSpan.FromMilliseconds(180)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } });
    }

    private static void SetScale(Control control, double value)
    {
        if (GetMutableScale(control) is not { } scale) return;
        if (!IsAllowed) { scale.BeginAnimation(ScaleTransform.ScaleXProperty, null); scale.BeginAnimation(ScaleTransform.ScaleYProperty, null); scale.ScaleX = 1; scale.ScaleY = 1; return; }
        var animation = new DoubleAnimation(value, TimeSpan.FromMilliseconds(160)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } };
        scale.BeginAnimation(ScaleTransform.ScaleXProperty, animation);
        scale.BeginAnimation(ScaleTransform.ScaleYProperty, animation);
    }

    private static ScaleTransform? GetMutableScale(Control control)
    {
        if (control.Template?.FindName("Surface", control) is not FrameworkElement { RenderTransform: ScaleTransform scale } surface) return null;
        if (!scale.IsFrozen) return scale;
        var mutable = scale.Clone();
        surface.RenderTransform = mutable;
        return mutable;
    }
}

public static class WindowEffects
{
    [DllImport("dwmapi.dll", PreserveSig = true)]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int size);

    /// <summary>Windows 11 system Mica backdrop; Windows 10 retains the same opaque, legible glass palette.</summary>
    public static void Apply(Window window)
    {
        if (SystemParameters.HighContrast) return;
        void ApplyNow()
        {
            if (!OperatingSystem.IsWindowsVersionAtLeast(10, 0, 22000)) return;
            var handle = new WindowInteropHelper(window).Handle;
            if (handle == IntPtr.Zero) return;
            try
            {
                var dark = 1;
                _ = DwmSetWindowAttribute(handle, 20, ref dark, sizeof(int));
                var corners = 2;
                _ = DwmSetWindowAttribute(handle, 33, ref corners, sizeof(int));
                if (OperatingSystem.IsWindowsVersionAtLeast(10, 0, 22621))
                {
                    var backdrop = 2;
                    if (DwmSetWindowAttribute(handle, 38, ref backdrop, sizeof(int)) == 0)
                    {
                        // Keep the system material visible through a restrained tint; Windows 10 uses the opaque XAML fallback.
                        window.Background = new SolidColorBrush(Color.FromArgb(184, 5, 5, 8));
                        if (PresentationSource.FromVisual(window) is HwndSource source && source.CompositionTarget is not null)
                            source.CompositionTarget.BackgroundColor = Colors.Transparent;
                    }
                }
            }
            catch (DllNotFoundException) { }
            catch (EntryPointNotFoundException) { }
        }
        if (new WindowInteropHelper(window).Handle == IntPtr.Zero)
            window.SourceInitialized += (_, _) => ApplyNow();
        else ApplyNow();
    }
}
