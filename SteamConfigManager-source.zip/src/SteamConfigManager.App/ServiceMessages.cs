using System.Text.RegularExpressions;

namespace SteamConfigManager.App;

/// <summary>Presentation-only translations of stable Core messages. Raw logs remain in their original language.</summary>
public static partial class ServiceMessages
{
    private static readonly IReadOnlyDictionary<string, string> Russian = new Dictionary<string, string>(StringComparer.Ordinal)
    {
        ["Added"] = "Добавлено", ["Removed"] = "Удалено", ["Changed"] = "Изменено", ["Unchanged"] = "Без изменений",
        ["Identical"] = "Совпадает", ["Different"] = "Различается", ["Skipped"] = "Пропущено", ["Warning"] = "Предупреждение",
        ["Healthy"] = "В порядке", ["Error"] = "Ошибка", ["Success"] = "Успешно", ["Partial Failure"] = "Частичная ошибка",
        ["Complete"] = "Завершено", ["Pending"] = "Ожидает завершения", ["Preparing"] = "Подготовка",
        ["RecoveryRequired"] = "Требуется восстановление", ["Recovered"] = "Восстановлено", ["RolledBack"] = "Выполнен откат",
        ["Recovery"] = "Восстановление", ["Keybinds"] = "Бинды", ["Gameplay"] = "Настройки игры", ["HeroSettings"] = "Настройки героев",
        ["HeroGrids"] = "Сетки героев", ["ItemBuilds"] = "Сборки предметов", ["Other"] = "Другие файлы",
        ["Crosshair"] = "Прицел", ["Sensitivity"] = "Чувствительность", ["Viewmodel"] = "Положение оружия",
        ["RadarHud"] = "Радар и HUD", ["Audio"] = "Звук", ["Video"] = "Видео",
        ["The profile belongs to another game."] = "Профиль относится к другой игре.",
        ["Hardware or mixed settings require explicit consent."] = "Аппаратные и смешанные настройки требуют явного согласия.",
        ["No transferable setting was selected in this file."] = "В этом файле не выбраны настройки для переноса.",
        ["Compared complete file bytes; reliable parameter counts are unavailable."] = "Сравнены байты файлов целиком; точный подсчёт параметров недоступен.",
        ["Compared the settings that would result from the selected transfer."] = "Сравнены настройки, которые получатся после выбранного переноса.",
        ["A configuration entry is missing its path or content."] = "В записи конфигурации отсутствует путь или содержимое.",
        ["The configuration is empty or larger than 16 MiB."] = "Конфигурация пуста или превышает 16 МиБ.",
        ["The configuration contains binary or invalid control data."] = "Конфигурация содержит двоичные данные или недопустимые управляющие символы.",
        ["A hero grid must contain a JSON object."] = "Сетка героев должна содержать объект JSON.",
        ["The hero grid does not contain a configs array."] = "В сетке героев отсутствует массив configs.",
        ["The hero grid has invalid JSON structure."] = "Структура JSON сетки героев некорректна.",
        ["The configuration has no settings."] = "В конфигурации отсутствуют настройки.",
        ["Expected a bindings object in the CS2 keybind file."] = "В файле биндов CS2 ожидается объект bindings.",
        ["Expected a config object in the target keybind file."] = "В целевом файле биндов ожидается объект config.",
        ["Expected a config object in the VCFG file."] = "В файле VCFG ожидается объект config.",
        ["Expected a convars object in the VCFG file."] = "В файле VCFG ожидается объект convars.",
        ["Source changed after scanning. Rescan before copying."] = "Исходные файлы изменились после сканирования. Повторите сканирование перед копированием.",
        ["No supported configuration files were found."] = "Поддерживаемые файлы конфигурации не найдены.",
        ["Choose a different target account."] = "Выберите другой аккаунт-получатель.",
        ["Merge selected recognized settings; retain target device and unknown values"] = "Объединить выбранные распознанные настройки; сохранить устройства и неизвестные параметры получателя",
        ["Add file"] = "Добавить файл", ["Replace complete file"] = "Заменить файл целиком", ["Apply configuration"] = "Применить конфигурацию",
        ["Restore original file"] = "Восстановить исходный файл",
        ["Remove file absent before the original operation"] = "Удалить файл, отсутствовавший до исходной операции",
        ["Recover the interrupted operation before restoring this backup."] = "Восстановите прерванную операцию перед восстановлением этого бэкапа.",
        ["No changes: selected configuration is already identical."] = "Изменений нет: выбранные настройки уже совпадают.",
        ["An interrupted operation must be recovered before changing this account."] = "Перед изменением этого аккаунта необходимо восстановить прерванную операцию.",
        ["Operation cancelled."] = "Операция отменена.",
        ["Original files restored and verified."] = "Исходные файлы восстановлены и проверены.",
        ["Original backup is retained."] = "Исходная резервная копия сохранена.",
        ["Too many files."] = "Слишком много файлов.",
        ["Invalid or duplicate target path."] = "Целевой путь некорректен или указан повторно.",
        ["Transfer exceeds safety limits."] = "Объём переноса превышает безопасные ограничения.",
        ["Transfer checksum mismatch."] = "Контрольная сумма переноса не совпадает.",
        ["Invalid game or account identifier."] = "Некорректный идентификатор игры или аккаунта.",
        ["The target must be the selected account's Steam configuration directory."] = "Целевой путь должен указывать на папку конфигурации Steam выбранного аккаунта.",
        ["Target configuration exceeds backup safety limits."] = "Объём целевой конфигурации превышает безопасные ограничения резервного копирования.",
        ["The game is running. Close it before changing configuration files."] = "Игра запущена. Закройте её перед изменением файлов конфигурации.",
        ["Unsupported game."] = "Игра не поддерживается.",
        ["This filename is not recognized for the selected game."] = "Имя файла не распознано для выбранной игры.",
        ["This filename is not a supported configuration for the selected game. Import its original filename or a Steam Config Manager ZIP profile."] = "Этот файл не поддерживается для выбранной игры. Используйте исходное имя файла или ZIP-профиль Steam Config Manager.",
        ["Checksum mismatch."] = "Контрольная сумма не совпадает.",
        ["Archive contains too many entries."] = "В архиве слишком много записей.",
        ["Unsafe archive path."] = "Архив содержит небезопасный путь.",
        ["Archive links are not supported."] = "Ссылки в архивах не поддерживаются.",
        ["Duplicate archive entry."] = "Архив содержит повторяющуюся запись.",
        ["Archive exceeds size limits."] = "Размер архива превышает допустимые ограничения.",
        ["This is a complete backup archive, not a transferable profile. Restore local backups from Library; the archive retains original files and recovery metadata."] = "Это полный архив резервной копии. Восстановите локальный бэкап из Библиотеки. Архив сохраняет исходные файлы и данные восстановления и не импортируется как профиль переноса.",
        ["This ZIP is not a Steam Config Manager profile (profile.json is missing)."] = "Этот ZIP не является профилем Steam Config Manager: отсутствует profile.json.",
        ["Invalid profile manifest."] = "Некорректное описание профиля.",
        ["Unsupported profile version or selected game does not match the profile."] = "Версия профиля не поддерживается либо профиль относится к другой игре.",
        ["Archive has undeclared or missing files."] = "Состав архива не соответствует описанию: есть лишние или отсутствующие файлы.",
        ["Invalid profile file metadata."] = "Некорректные метаданные файла профиля.",
        ["Invalid configuration path in archive."] = "В архиве указан некорректный путь конфигурации.",
        ["Profile entry is missing or its size does not match the manifest."] = "Файл профиля отсутствует либо его размер не соответствует описанию.",
        ["Expanded archive entry exceeds its limit."] = "Распакованный файл архива превышает допустимый размер.",
        ["Archive entry length mismatch."] = "Длина файла архива не соответствует указанной.",
        ["Only recognized selected settings are merged. Unknown and device settings remain unchanged."] = "Объединяются только выбранные распознанные параметры. Неизвестные настройки и устройства получателя сохраняются.",
        ["Hardware and device settings require explicit consent and are copied as a whole file."] = "Настройки оборудования и устройств переносятся целым файлом и требуют явного согласия.",
        ["Command scripts may contain hardware settings or executable console commands. Whole-file transfer requires explicit consent."] = "Скрипт может содержать настройки оборудования и консольные команды. Перенос целого файла требует явного согласия.",
        ["Whole-file transfer: this format combines settings and cannot be safely split into categories."] = "Перенос файла целиком: формат объединяет разные настройки и не позволяет безопасно разделить их по категориям.",
        ["May contain hardware-dependent settings; explicit consent is required."] = "Может содержать аппаратно-зависимые настройки; требуется явное согласие.",
        ["Combined hero-specific settings and keybinds: select this entire file explicitly to transfer it."] = "Настройки героев и бинды объединены: явно выберите целый файл для переноса.",
        ["Whole console script; may contain hardware-specific commands. Explicit consent is required."] = "Консольный скрипт целиком; возможны команды для конкретного оборудования. Требуется явное согласие.",
        ["Empty or oversized configuration file."] = "Файл конфигурации пуст или превышает допустимый размер.",
        ["Unsupported text encoding; UTF-8 or UTF-16 is required for safe editing."] = "Кодировка текста не поддерживается. Для безопасного редактирования требуется UTF-8 или UTF-16.",
        ["Invalid Steam AccountID."] = "Некорректный Steam AccountID.",
        ["No local configuration was found. This account can still receive a configuration."] = "Локальная конфигурация не найдена. Этот аккаунт может быть получателем.",
        ["The config scan reached its safe file-count limit."] = "Сканирование достигло безопасного ограничения по количеству файлов.",
        ["Skipped a symbolic link or junction."] = "Символическая ссылка или junction пропущена.",
        ["The file is larger than the safe 16 MiB limit."] = "Файл превышает безопасное ограничение 16 МиБ.",
        ["No supported local files were found. Login and create settings in the game first, or import a supported profile."] = "Поддерживаемые локальные файлы не найдены. Войдите в игру и сохраните настройки либо импортируйте поддерживаемый профиль.",
        ["Some files include hardware-dependent settings and require explicit consent."] = "Некоторые файлы содержат настройки оборудования и требуют явного согласия.",
        ["The configuration exceeds the supported text limits."] = "Конфигурация превышает ограничения по размеру текста.",
        ["Unexpected data after the configuration."] = "После конфигурации обнаружены неожиданные данные.",
        ["The configuration is nested too deeply."] = "Конфигурация содержит слишком глубокую вложенность.",
        ["Unexpected closing brace."] = "Обнаружена лишняя закрывающая скобка.",
        ["Unsupported configuration directive or structure."] = "Директива или структура конфигурации не поддерживается.",
        ["The configuration has too many settings."] = "В конфигурации слишком много параметров.",
        ["A configuration value is missing."] = "Отсутствует значение параметра конфигурации.",
        ["A configuration value is missing before a closing brace."] = "Перед закрывающей скобкой отсутствует значение параметра.",
        ["The configuration has an unclosed brace."] = "В конфигурации есть незакрытая скобка.",
        ["The configuration has an unclosed quoted string."] = "В конфигурации есть строка с незакрытыми кавычками.",
        ["A storage root is required."] = "Необходимо указать корневую папку хранилища.",
        ["The configuration path is not a safe relative path."] = "Путь конфигурации должен быть безопасным относительным путём.",
        ["The configuration path contains an unsafe component."] = "Путь конфигурации содержит небезопасный компонент.",
        ["Reserved Windows names are not permitted."] = "Зарезервированные имена Windows запрещены.",
        ["The path escapes its storage root."] = "Путь выходит за пределы корневой папки хранилища.",
        ["Steam loginusers.vdf does not contain a users object."] = "В файле Steam loginusers.vdf отсутствует объект users.",
        ["Account discovery reached its safe limit of 1000 accounts."] = "Обнаружение аккаунтов достигло безопасного ограничения: 1000 аккаунтов.",
        ["Skipped a linked userdata folder."] = "Папка userdata, являющаяся ссылкой, пропущена.",
        ["The metadata file is empty or larger than the supported limit."] = "Файл метаданных пуст или превышает допустимый размер.",
        ["Steam was not found. Select the Steam installation folder in Library preferences."] = "Steam не найден. Укажите папку установки Steam в настройках Библиотеки.",
        ["No locally known Steam accounts were found. Sign in to Steam once, then rescan."] = "Локально известные аккаунты Steam не найдены. Войдите в Steam и повторите сканирование.",
        ["A Steam registry location could not be read."] = "Не удалось прочитать запись Steam в реестре.",
        ["The selected path is not a recognized Steam installation folder."] = "Выбранная папка не распознана как установка Steam.",
        ["Invalid storage identifier."] = "Некорректный идентификатор хранилища.",
        ["File exceeds the configured safety limit."] = "Файл превышает установленное безопасное ограничение по размеру.",
        ["Empty metadata."] = "Метаданные отсутствуют.",
        ["A supported profile must contain 1–2048 configuration files."] = "Поддерживаемый профиль должен содержать от 1 до 2048 файлов конфигурации.",
        ["A profile entry is missing its path or content."] = "В записи профиля отсутствует путь или содержимое.",
        ["Duplicate profile path."] = "Профиль содержит повторяющийся путь.",
        ["Profile exceeds safety limits."] = "Профиль превышает безопасные ограничения по размеру.",
        ["Preset metadata identifier mismatch."] = "Идентификатор пресета не соответствует имени файла метаданных.",
        ["Preset identifier mismatch."] = "Идентификатор пресета не совпадает.",
        ["Use a preset name of 1–120 characters."] = "Используйте название пресета длиной от 1 до 120 символов.",
        ["Invalid backup metadata."] = "Метаданные резервной копии некорректны.",
        ["Unrecognized backup transaction state."] = "Состояние операции резервного копирования не распознано.",
        ["Unrecognized backup path."] = "Путь резервной копии не распознан.",
        ["Missing or invalid backup checksum."] = "Контрольная сумма резервной копии отсутствует или некорректна.",
        ["Target changed during backup. Refresh the preview."] = "Целевые файлы изменились во время резервного копирования. Обновите предварительный обзор.",
        ["Backup verification failed before writing target configuration."] = "Проверка резервной копии не пройдена. Целевая конфигурация не записывалась.",
        ["File did not exist in this backup."] = "Файл отсутствовал в этой резервной копии.",
        ["Backup exceeds export size limits."] = "Резервная копия превышает ограничение по размеру экспорта.",
        ["Retention must be between 1 and 3650 days."] = "Срок хранения должен составлять от 1 до 3650 дней.",
        ["This backup is required to recover an interrupted operation."] = "Эта резервная копия необходима для восстановления прерванной операции.",
        ["Unsafe backup path."] = "Путь резервной копии небезопасен.",
        ["File exceeds safety limit."] = "Файл превышает безопасное ограничение по размеру.",
        ["Invalid or truncated VBKV header."] = "Заголовок VBKV некорректен или обрезан.",
        ["VBKV checksum mismatch."] = "Контрольная сумма VBKV не совпадает.",
        ["VBKV must contain one root object."] = "VBKV должен содержать один корневой объект.",
        ["VBKV root does not match the selected Dota configuration file."] = "Корневой объект VBKV не соответствует выбранному файлу конфигурации Dota.",
        ["VBKV has missing end markers or trailing data."] = "В VBKV отсутствуют маркеры завершения или есть лишние данные.",
        ["VBKV nesting exceeds the safe limit."] = "Вложенность VBKV превышает безопасное ограничение.",
        ["VBKV contains too many settings."] = "VBKV содержит слишком много параметров.",
        ["VBKV contains a truncated integer value."] = "VBKV содержит обрезанное целочисленное значение.",
        ["Unsupported VBKV value type; only the verified Dota profile variant can be transferred."] = "Тип значения VBKV не поддерживается. Переносится только проверенный вариант профиля Dota.",
        ["VBKV is truncated or an end marker is missing."] = "VBKV обрезан или отсутствует маркер завершения.",
        ["VBKV contains an invalid or unterminated string."] = "VBKV содержит некорректную или незавершённую строку.",
        ["VBKV contains invalid UTF-8 text."] = "VBKV содержит некорректный текст UTF-8.",
        ["VBKV is supported only for the recognized Dota hero configuration files."] = "VBKV поддерживается только для распознанных файлов настроек героев Dota."
    };

    private static readonly (string English, string Russian)[] Prefixes =
    [
        ("This file is not a supported configuration for the selected game: ", "Этот файл не поддерживается для выбранной игры: "),
        ("The configuration checksum does not match: ", "Контрольная сумма конфигурации не совпадает: "),
        ("The target file exceeds the supported 16 MB limit: ", "Целевой файл превышает ограничение 16 МиБ: "),
        ("A file changed outside this operation; recovery will not overwrite it: ", "Файл изменён другой программой; восстановление не будет его перезаписывать: "),
        ("Target changed since the preview. Refresh before applying: ", "Целевой файл изменился после предварительного обзора. Обновите обзор перед применением: "),
        ("Symbolic links and junctions are not supported for configuration files: ", "Символические ссылки и junction не поддерживаются для файлов конфигурации: "),
        ("Duplicate settings prevent a reliable comparison: ", "Повторяющиеся параметры не позволяют надёжно сравнить настройки: "),
        ("A target setting has an unexpected nested structure: ", "Целевой параметр содержит неожиданную вложенную структуру: "),
        ("Unsupported game configuration path: ", "Путь конфигурации игры не поддерживается: "),
        ("Backup checksum mismatch: ", "Контрольная сумма резервной копии не совпадает: "),
        ("Profile checksum mismatch: ", "Контрольная сумма профиля не совпадает: "),
        ("Recovery verification failed: ", "Проверка восстановления не пройдена: "),
        ("File changed during recovery: ", "Файл изменился во время восстановления: "),
        ("Verification failed: ", "Проверка не пройдена: "),
        ("Target is read-only: ", "Целевой файл доступен только для чтения: "),
        ("Cannot read Steam account names: ", "Не удалось прочитать имена аккаунтов Steam: "),
        ("Cannot enumerate Steam userdata: ", "Не удалось прочитать список папок Steam userdata: "),
        ("Skipped an inaccessible or linked Steam candidate: ", "Пропущен недоступный путь Steam или путь со ссылкой: "),
        ("Additional Steam libraries could not be fully inspected: ", "Не удалось полностью проверить дополнительные библиотеки Steam: "),
        ("A shared game config directory could not be inspected: ", "Не удалось проверить общую папку конфигурации игры: "),
        ("Recovery requires attention: ", "Восстановление требует внимания: ")
    ];

    /// <summary>Unknown text, technical keys, paths and operating-system error details are retained verbatim.</summary>
    public static string Translate(string message, string language)
    {
        if (string.IsNullOrEmpty(message) || language != "ru") return message;
        return LinePattern().Replace(message, match => TranslateLine(match.Value));
    }

    private static string TranslateLine(string line)
    {
        if (Russian.TryGetValue(line, out var exact)) return exact;
        var success = SuccessPattern().Match(line);
        if (success.Success) return $"Применены и проверены файлы: {success.Groups[1].Value}. Запустите игру для проверки; Steam Cloud может сообщить о конфликте.";
        var recovered = RecoveredPattern().Match(line);
        if (recovered.Success) return $"Прерванная операция аккаунта {recovered.Groups[1].Value} восстановлена.";
        var recovery = RecoveryPattern().Match(line);
        if (recovery.Success) return $"Восстановление аккаунта {recovery.Groups[1].Value} требует внимания: {TranslateLine(recovery.Groups[2].Value)}";

        // Core appends recovery outcomes to an arbitrary original error. Only the known suffix is translated.
        foreach (var suffix in new[] { " Original files restored and verified.", " Original backup is retained." })
            if (line.EndsWith(suffix, StringComparison.Ordinal)) return TranslateLine(line[..^suffix.Length]) + " " + Russian[suffix[1..]];
        const string recoveryMarker = " Recovery requires attention: ";
        var recoveryIndex = line.IndexOf(recoveryMarker, StringComparison.Ordinal);
        if (recoveryIndex >= 0) return TranslateLine(line[..recoveryIndex]) + " Восстановление требует внимания: " + TranslateLine(line[(recoveryIndex + recoveryMarker.Length)..]);

        foreach (var (english, russian) in Prefixes)
            if (line.StartsWith(english, StringComparison.Ordinal))
            {
                var payload = line[english.Length..];
                var nestedError = english is "Cannot read Steam account names: " or "Cannot enumerate Steam userdata: "
                    or "Skipped an inaccessible or linked Steam candidate: " or "Additional Steam libraries could not be fully inspected: "
                    or "A shared game config directory could not be inspected: " or "Recovery requires attention: ";
                return russian + (nestedError ? TranslateLine(payload) : payload);
            }

        // Discovery and format rules can join several complete known warnings with a space.
        foreach (var entry in Russian)
            if (entry.Key.EndsWith('.') && line.StartsWith(entry.Key + " ", StringComparison.Ordinal))
                return entry.Value + " " + TranslateLine(line[(entry.Key.Length + 1)..]);

        // History labels contain categories separated by commas or metadata separated by middle dots.
        if (line.Contains(" · ", StringComparison.Ordinal)) return string.Join(" · ", line.Split(" · ").Select(TranslateLine));
        if (line.Contains(", ", StringComparison.Ordinal))
        {
            var parts = line.Split(", ");
            if (parts.All(Russian.ContainsKey)) return string.Join(", ", parts.Select(p => Russian[p]));
        }
        var account = AccountPattern().Match(line);
        if (account.Success) return "Аккаунт " + account.Groups[1].Value;
        // Only generated backup labels and imported filenames get a prefix translation.
        if (line.StartsWith("Restore backup ", StringComparison.Ordinal)) return "Восстановить резервную копию " + line[15..];
        if (line.StartsWith("Backup ", StringComparison.Ordinal)) return "Резервная копия " + line[7..];
        if (line.StartsWith("Imported ", StringComparison.Ordinal)) return "Импорт: " + line[9..];
        return line;
    }

    [GeneratedRegex(@"[^\r\n]+", RegexOptions.CultureInvariant)] private static partial Regex LinePattern();
    [GeneratedRegex(@"^Applied and verified (\d+) file\(s\)\. Start the game to confirm; Steam Cloud may offer a conflict\.$", RegexOptions.CultureInvariant)] private static partial Regex SuccessPattern();
    [GeneratedRegex(@"^Recovered interrupted operation for account (\d+)\.$", RegexOptions.CultureInvariant)] private static partial Regex RecoveredPattern();
    [GeneratedRegex(@"^Recovery requires attention for account (\d+): (.*)$", RegexOptions.CultureInvariant)] private static partial Regex RecoveryPattern();
    [GeneratedRegex(@"^Account (\d+)$", RegexOptions.CultureInvariant)] private static partial Regex AccountPattern();
}
