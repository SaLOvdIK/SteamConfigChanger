using System.Windows;
using System.Runtime.InteropServices;
namespace SteamConfigManager.App;
public partial class App : Application
{
    private Mutex? _instance;
    [DllImport("user32.dll",CharSet=CharSet.Unicode)] private static extern IntPtr FindWindow(string? className,string windowName);
    [DllImport("user32.dll")] private static extern bool ShowWindow(IntPtr handle,int command);
    [DllImport("user32.dll")] private static extern bool SetForegroundWindow(IntPtr handle);
    protected override void OnStartup(StartupEventArgs e)
    {
        _instance=new Mutex(true,"Local\\SteamConfigManager.Desktop",out bool created);
        if(!created)
        {
            var existing=FindWindow(null,"Steam Config Manager");
            if(existing!=IntPtr.Zero){ShowWindow(existing,9);SetForegroundWindow(existing);}
            _instance.Dispose();_instance=null;Shutdown();return;
        }
        base.OnStartup(e);
        DispatcherUnhandledException += (_, args) =>
        {
            if (MainWindow?.DataContext is MainViewModel vm) { vm.Notify(args.Exception.Message); args.Handled = true; }
        };
    }
    protected override void OnExit(ExitEventArgs e) { _instance?.ReleaseMutex();_instance?.Dispose();base.OnExit(e); }
}
