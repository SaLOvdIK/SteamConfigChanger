using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Windows;
using System.Windows.Threading;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Win32;
using SteamConfigManager.Core;

namespace SteamConfigManager.App;

public sealed partial class AccountVM : ObservableObject
{
    public SteamAccount Account { get; }
    public string AccountId => Account.AccountId;
    public string SteamId64 => Account.SteamId64;
    public string DisplayName { get; }
    public bool Favorite { get; }
    public string Initials => string.Concat(DisplayName.TrimStart('★',' ').Split(' ',StringSplitOptions.RemoveEmptyEntries).Take(2).Select(x=>x[0])).ToUpperInvariant();
    public string Summary { get; }
    public string ConfigStatus { get; }
    public string HealthDetails { get; }
    public string LastModified { get; }
    public ImageSource? Avatar { get; }
    public bool HasAvatar => Avatar is not null;
    public GameConfig? Config { get; }
    [ObservableProperty] private bool selected;
    public AccountVM(SteamAccount account, GameConfig? config, AppSettings settings, Localization text)
    {
        Account=account; Config=config;
        Favorite=settings.Favorites.Contains(account.AccountId);
        DisplayName=settings.Aliases.GetValueOrDefault(account.AccountId) is { Length:>0 } alias ? alias : account.Name;
        Summary=config is null ? "" : $"{config.Files.Count} {text.Choose("files", "файлов")} · {config.Files.Sum(x=>x.Size)/1024d:0.#} KB";
        ConfigStatus=config?.Files.Count > 0 ? text[config.Health.ToString()] : text["ConfigMissing"];
        HealthDetails=ServiceMessages.Translate(config?.Warning??ConfigStatus,text.Language);
        LastModified=config?.Files.Count > 0 ? config.Files.Max(x=>x.ModifiedUtc).ToLocalTime().ToString("g") : "—";
        try
        {
            var steam=config is null?null:Directory.GetParent(config.RootPath)?.Parent?.Parent?.FullName;
            if(steam is not null)
            {
                var path=SafePaths.Resolve(steam,"config/avatarcache/"+account.SteamId64+".png");
                if(File.Exists(path)&&new FileInfo(path).Length<=1024*1024)
                {
                    var bitmap=new BitmapImage();using var stream=File.OpenRead(path);
                    bitmap.BeginInit();bitmap.CacheOption=BitmapCacheOption.OnLoad;bitmap.DecodePixelWidth=96;bitmap.StreamSource=stream;bitmap.EndInit();bitmap.Freeze();Avatar=bitmap;
                }
            }
        }
        catch(Exception ex) when(ex is IOException or UnauthorizedAccessException or NotSupportedException or ArgumentException or FileFormatException) { }
    }
}
public sealed partial class CategoryVM(ConfigCategory category,string name,string info,bool available,bool selected) : ObservableObject
{
    public ConfigCategory Category { get; }=category;
    public string Name { get; }=name;
    public string Info { get; }=info;
    public bool Available { get; }=available;
    [ObservableProperty] private bool selected=selected;
}
public sealed partial class FileVM(string path,string info,bool enabled) : ObservableObject
{
    public string Path { get; }=path;
    public string Info { get; }=info;
    public bool Enabled { get; set; }=enabled;
    [ObservableProperty] private bool selected;
}
public sealed record LibraryItemVM(string Id,string Title,string Detail,object Raw,bool CanUndo=false);
public sealed record DetailRow(string Title,string Detail);

public sealed partial class MainViewModel : ObservableObject
{
    public Localization Text { get; }=new();
    private readonly ApplicationSettingsService _settingsService;
    private readonly SteamDiscoveryService _discovery=new();
    private readonly PresetService _presets;
    private readonly OperationHistoryService _history;
    private BackupService _backups;
    private ConfigTransferService _transfer;
    private readonly ImportExportService _exchange=new();
    private DiscoveryResult? _scan;
    private ConfigProfile? _profile;
    private bool _backupStorageReady=true;
    private string? _backupStorageError;
    private GameId _game=GameId.Dota2;
    private Func<Task>? _panelAction;
    private readonly DispatcherTimer _processTimer=new() { Interval=TimeSpan.FromSeconds(3) };
    private int _toastVersion;
    [ObservableProperty] private AppSettings settings;
    [ObservableProperty] private string language="en";
    [ObservableProperty] private bool isLibrary;
    [ObservableProperty] private bool isBusy;
    [ObservableProperty] private string status="";
    [ObservableProperty] private string toast="";
    [ObservableProperty] private bool toastVisible;
    [ObservableProperty] private string steamStatus="";
    [ObservableProperty] private string recommendation="";
    [ObservableProperty] private bool hardwareConsent;
    [ObservableProperty] private AccountVM? source;
    [ObservableProperty] private AccountVM? target;
    [ObservableProperty] private bool panelOpen;
    [ObservableProperty] private string panelTitle="";
    [ObservableProperty] private string panelDescription="";
    [ObservableProperty] private string panelInput="";
    [ObservableProperty] private bool panelHasInput;
    [ObservableProperty] private bool panelIsAccount;
    [ObservableProperty] private bool panelFavorite;
    [ObservableProperty] private string panelConfirm="";
    [ObservableProperty] private double operationProgress;
    public string Alias { get; set; }="";
    public bool IsDota => _game==GameId.Dota2;
    public bool IsCs => !IsDota;
    public string SelectedGameName => GameName(_game);
    public bool HasProfile => _profile is not null;
    public string ProfileSummary => _profile is null ? Text["SelectSource"] : $"{Text["CopiedBadge"]} · {_profile.SourceName} · {_profile.Files.Count} {Text.Choose("files", "файлов")}";
    public string DotaCount => Count(GameId.Dota2);
    public string CsCount => Count(GameId.Cs2);
    public ObservableCollection<AccountVM> SourceAccounts { get; }=[];
    public ObservableCollection<AccountVM> TargetAccounts { get; }=[];
    public ObservableCollection<AccountVM> BatchTargets { get; }=[];
    public ObservableCollection<CategoryVM> Categories { get; }=[];
    public ObservableCollection<FileVM> ConfigFiles { get; }=[];
    public ObservableCollection<LibraryItemVM> Presets { get; }=[];
    public ObservableCollection<LibraryItemVM> Backups { get; }=[];
    public ObservableCollection<LibraryItemVM> History { get; }=[];
    public ObservableCollection<DetailRow> PanelRows { get; }=[];
    public bool CanWork => !IsBusy;
    public bool CanCopy => !IsBusy && Source?.Config?.Files.Any(f=>f.Issue is null)==true;
    public bool CanUseProfile => !IsBusy && HasProfile;
    public bool CanApply => !IsBusy && _backupStorageReady && HasProfile && !IsGameRunning() && (Target is not null || BatchTargets.Any(x=>x.Selected));

    public MainViewModel(string? storageRoot=null)
    {
        _settingsService=new(storageRoot);
        string? loadError=null;
        try { settings=_settingsService.Load(); } catch(Exception ex) { settings=new(); loadError=ex.Message; }
        language=Settings.Language; Text.SetLanguage(Language); Motion.Enabled=Settings.Animations;
        _presets=new(_settingsService.Root); _history=new(_settingsService.Root);
        try { _backups=new(BackupStorage()); }
        catch(Exception ex) when(ex is IOException or UnauthorizedAccessException or ArgumentException)
        {
            _backupStorageReady=false;_backupStorageError=ex.Message;
            _backups=new(_settingsService.Root);
        }
        _transfer=new(_backups,_history);
        Status=Text["Ready"];
        _processTimer.Tick+=(_,_)=>UpdateStatus(); _processTimer.Start();
        if(loadError is not null) Notify(loadError);
    }
    public async Task InitializeAsync()
    {
        await Run(async()=>
        {
            var recovery=_backupStorageReady?await _transfer.RecoverPendingAsync():[];
            if(recovery.Count>0) ShowPanel(Text.Choose("Interrupted operation recovery","Восстановление прерванной операции"),string.Join("\n",recovery.Select(Message)));
            if(_backupStorageReady)await _backups.ApplyRetentionAsync(Settings);
            await RefreshLibrary();
            if(Settings.AutoScan) await ScanInternal();
            if(!_backupStorageReady)ShowPanel(Text["Error"],Text.Choose("Backup storage is unavailable. Transfers and restores are blocked. Choose an accessible directory in Preferences. ","Хранилище бэкапов недоступно. Перенос и восстановление заблокированы. Выберите доступный каталог в настройках. ")+_backupStorageError);
        });
    }
    private string BackupStorage()=>string.IsNullOrWhiteSpace(Settings.BackupPath)?_settingsService.Root:Path.GetFullPath(Settings.BackupPath);
    private string Count(GameId game)=>$"{_scan?.Configs.Count(x=>x.Game==game && x.Files.Any(f=>f.Issue is null)) ?? 0} {Text["Accounts"]}";
    public static string GameName(GameId game)=>game==GameId.Dota2?"Dota 2":"Counter-Strike 2";
    partial void OnLanguageChanged(string value)
    {
        Text.SetLanguage(value); Settings.Language=value;
        RebuildAccounts(); RebuildComposition(); RaiseGame();
        if(_scan is not null)Status=_scan.SteamPath is null?Text["NotFound"]:$"{Text["SteamDetected"]} · {_scan.Accounts.Count} {Text.Choose("accounts", "аккаунтов")} · {_scan.Configs.Sum(x=>x.Files.Count)} {Text.Choose("files", "файлов")}";
        _=RefreshLibraryCaught();
    }
    partial void OnIsBusyChanged(bool value) { OnPropertyChanged(nameof(CanWork)); UpdateCommands(); }
    partial void OnSourceChanged(AccountVM? value)
    {
        _profile=null; HardwareConsent=false; BuildTargets(); RebuildComposition(); RaiseProfile(); UpdateStatus();
    }
    partial void OnTargetChanged(AccountVM? value) { UpdateCommands(); UpdateStatus(); }
    partial void OnHardwareConsentChanged(bool value)=>RebuildComposition(true);
    private void RaiseProfile() { OnPropertyChanged(nameof(HasProfile)); OnPropertyChanged(nameof(ProfileSummary)); UpdateCommands(); }
    private void RaiseGame() { foreach(var p in new[]{nameof(IsDota),nameof(IsCs),nameof(SelectedGameName),nameof(DotaCount),nameof(CsCount)}) OnPropertyChanged(p); }
    private void UpdateCommands()
    {
        foreach(var c in new IRelayCommand[]{RescanCommand,CopyCommand,ApplyCommand,SavePresetCommand,ImportCommand,ExportCommand,ExportFileCommand,CompareCommand,OpenFolderCommand,SaveSettingsCommand,SelectGameCommand,SwapCommand,ManageAccountCommand,RestoreBackupCommand,DeleteBackupCommand,RenamePresetCommand,DeletePresetCommand,LoadPresetCommand,CompareBackupCommand,ExportBackupCommand,UndoCommand,ChooseSteamCommand,ChooseBackupCommand}) c.NotifyCanExecuteChanged();
    }
    public async void Notify(string message)
    {
        var version=++_toastVersion; Toast=Message(message); ToastVisible=true;
        await Task.Delay(6500);
        if(version==_toastVersion) ToastVisible=false;
    }
    private async Task Run(Func<Task> action)
    {
        if(IsBusy) return;
        IsBusy=true; OperationProgress=8;Status=Text["Working"];
        try { await action(); OperationProgress=100;if(Status==Text["Working"])Status=Text["Done"]; }
        catch(Exception ex) { Status=Text["Error"]+": "+Message(ex.Message); Notify(Status); }
        finally { IsBusy=false; UpdateStatus(false); }
    }
    private bool IsGameRunning()
    {
        try { var ps=Process.GetProcessesByName(_game==GameId.Dota2?"dota2":"cs2"); bool running=ps.Length>0; foreach(var p in ps)p.Dispose(); return running; }
        catch { return true; }
    }
    private void UpdateStatus(bool recommendations=true)
    {
        SteamStatus=IsGameRunning()?Text["GameRunning"]:_scan?.SteamPath is not null?Text["SteamDetected"]:Text.Choose("Steam not detected","Steam не обнаружен");
        UpdateCommands();
        if(!recommendations)return;
        if(IsGameRunning())Recommendation=Text["GameRunning"];
        else if(!_backupStorageReady)Recommendation=Text.Choose("Backup storage unavailable. Open Preferences to fix its path.","Хранилище бэкапов недоступно. Исправьте путь в настройках.");
        else if(_scan?.SteamPath is null)Recommendation=Text["NotFound"];
        else if(_scan.Accounts.Count==0)Recommendation=Text["NoAccounts"];
        else if(Source?.Config is { } sourceConfig && Target?.Config is { } targetConfig && sourceConfig.Files.Count>0 && sourceConfig.Files.All(f=>f.Issue is null&&f.Hash.Length==64) && targetConfig.Files.All(f=>f.Issue is null&&f.Hash.Length==64) && sourceConfig.Files.Count==targetConfig.Files.Count && sourceConfig.Files.All(f=>targetConfig.Files.Any(t=>t.RelativePath==f.RelativePath && t.Hash==f.Hash)))Recommendation=Text.Choose("These accounts have identical local configuration files.","У этих аккаунтов одинаковые локальные конфиги.");
        else if(Target is not null && !Backups.Any(x=>x.Raw is BackupRecord b && b.Game==_game && b.AccountId==Target.AccountId))Recommendation=Text.Choose("No backup for this account yet. One will be created before applying.","Для этого аккаунта пока нет бэкапа. Он будет создан перед применением.");
        else Recommendation=Text["HardwareNote"];
    }
    [RelayCommand] private void ShowDashboard()=>IsLibrary=false;
    [RelayCommand] private void ShowLibrary()=>IsLibrary=true;
    [RelayCommand] private void ShowPreferences() { IsLibrary=true; PreferencesRequested?.Invoke(this,EventArgs.Empty); }
    public event EventHandler? PreferencesRequested;
    [RelayCommand(CanExecute=nameof(CanWork))] private Task Rescan()=>Run(ScanInternal);
    private async Task ScanInternal()
    {
        Status=Text["Scanning"]; OperationProgress=15;
        _scan=await _discovery.ScanAsync(Settings.SteamPath); OperationProgress=75;
        RebuildAccounts(); RaiseGame(); UpdateStatus();
        Status=_scan.SteamPath is null?Text["NotFound"]:$"{Text["SteamDetected"]} · {_scan.Accounts.Count} {Text.Choose("accounts", "аккаунтов")} · {_scan.Configs.Sum(x=>x.Files.Count)} {Text.Choose("files", "файлов")}";
        if(_scan.Warnings.Count>0) { Recommendation=Message(_scan.Warnings[0]); Notify(string.Join("\n",_scan.Warnings.Take(3))); }
    }
    private void RebuildAccounts()
    {
        var old=Source?.AccountId; var previousTarget=Target?.AccountId;
        var batchIds=BatchTargets.Where(x=>x.Selected).Select(x=>x.AccountId).ToHashSet();
        var captured=_profile;
        bool virtualSource=captured is not null&&Source is null;
        SourceAccounts.Clear();
        if(_scan is not null)
        foreach(var account in _scan.Accounts.OrderByDescending(x=>Settings.Favorites.Contains(x.AccountId)).ThenByDescending(x=>x.MostRecent).ThenBy(x=>Settings.Aliases.GetValueOrDefault(x.AccountId,x.Name)))
            SourceAccounts.Add(new(account,_scan.Configs.FirstOrDefault(c=>c.AccountId==account.AccountId && c.Game==_game),Settings,Text));
        Source=virtualSource?null:SourceAccounts.FirstOrDefault(x=>x.AccountId==old) ?? SourceAccounts.FirstOrDefault(x=>x.Config?.Files.Count>0) ?? SourceAccounts.FirstOrDefault();
        BuildTargets(); Target=TargetAccounts.FirstOrDefault(x=>x.AccountId==previousTarget) ?? TargetAccounts.FirstOrDefault();
        if(captured?.Game==_game) _profile=captured;
        foreach(var batch in BatchTargets)batch.Selected=batchIds.Contains(batch.AccountId);
        RebuildComposition(); RaiseProfile();
    }
    private void BuildTargets()
    {
        var previous=Target?.AccountId; TargetAccounts.Clear(); BatchTargets.Clear();
        foreach(var account in SourceAccounts.Where(x=>x.AccountId!=Source?.AccountId))
        {
            TargetAccounts.Add(account);
            var batch=new AccountVM(account.Account,account.Config,Settings,Text);
            batch.PropertyChanged+=(_,e)=> { if(e.PropertyName==nameof(AccountVM.Selected)) UpdateCommands(); };
            BatchTargets.Add(batch);
        }
        Target=TargetAccounts.FirstOrDefault(x=>x.AccountId==previous) ?? TargetAccounts.FirstOrDefault();
    }
    [RelayCommand(CanExecute=nameof(CanWork))] private void SelectGame(string? value)
    {
        var next=value=="730"?GameId.Cs2:GameId.Dota2;
        if(next==_game)return;
        _game=next; _profile=null; HardwareConsent=false; RebuildAccounts();
        if(Source?.Config?.Files.Any(f=>f.Issue is null)!=true && SourceAccounts.FirstOrDefault(x=>x.Config?.Files.Any(f=>f.Issue is null)==true) is {} available)Source=available;
        RaiseGame(); RaiseProfile(); UpdateStatus(); GameChanged?.Invoke(this,EventArgs.Empty);
    }
    public event EventHandler? GameChanged;
    [RelayCommand(CanExecute=nameof(CanWork))] private void Swap()
    {
        if(Target is null || Source is null)return;
        var old=Source.AccountId; var next=Target.AccountId;
        Source=SourceAccounts.First(x=>x.AccountId==next); Target=TargetAccounts.FirstOrDefault(x=>x.AccountId==old);
    }
    private void RebuildComposition(bool preserve=false)
    {
        var chosen=Categories.Where(x=>x.Selected).Select(x=>x.Category).ToHashSet();
        var whole=ConfigFiles.Where(x=>x.Selected).Select(x=>x.Path).ToHashSet();
        Categories.Clear(); ConfigFiles.Clear();
        var detected=new HashSet<ConfigCategory>(); var safe=new HashSet<ConfigCategory>();
        IEnumerable<(string Path,byte[]? Bytes,long Size,string? Issue)> files=_profile is not null
            ? _profile.Files.Select(f=>(f.RelativePath,(byte[]?)f.Content,(long)f.Content.Length,(string?)null))
            : Source?.Config?.Files.Select(f=>(f.RelativePath,(byte[]?)null,f.Size,f.Issue)) ?? [];
        foreach(var file in files)
        {
            var rule=GameRules.Describe(_game,file.Path); if(rule is null)continue;
            IReadOnlyList<ConfigCategory> categories;
            if(file.Bytes is not null)categories=GameRules.AvailableCategories(_game,file.Path,file.Bytes);
            else if(_game==GameId.Cs2 && file.Path.Contains("cs2_user_convars_",StringComparison.OrdinalIgnoreCase))categories=[];
            else categories=[rule.Category];
            bool vbkv=file.Bytes is not null&&file.Bytes.AsSpan().StartsWith("VBKV"u8);
            bool combined=file.Path.EndsWith("dotakeys_personal.lst",StringComparison.OrdinalIgnoreCase)||vbkv;
            foreach(var c in categories) { detected.Add(c); if(!combined && file.Issue is null && (!rule.HardwareSpecific || HardwareConsent))safe.Add(c); }
            string note=file.Issue is not null?Text["Warning"]+": "+Message(file.Issue):Text.Choose(rule.SupportsPartial?"Recognized settings merge":"Whole-file transfer",rule.SupportsPartial?"Перенос распознанных параметров":"Перенос файла целиком");
            if(rule.HardwareSpecific)note+=" · "+Text.Choose("hardware consent required","требуется согласие на оборудование");
            if(file.Path.EndsWith("dotakeys_personal.lst",StringComparison.OrdinalIgnoreCase))note=Text.Choose("Combined keybinds + hero settings. Select this entire file explicitly.","Бинды и настройки героев объединены. Отметьте файл для переноса целиком.");
            if(vbkv)note=Text.Choose("VBKV binary · select this whole file explicitly; no partial editing.","Бинарный VBKV · отметьте файл целиком; частичный перенос недоступен.");
            var vm=new FileVM(file.Path,$"{file.Size/1024d:0.#} KB · {note}",file.Issue is null && (!rule.HardwareSpecific || HardwareConsent));
            vm.Selected=preserve && whole.Contains(file.Path) && vm.Enabled; ConfigFiles.Add(vm);
        }
        ConfigCategory[] order=IsDota?[ConfigCategory.Keybinds,ConfigCategory.Gameplay,ConfigCategory.HeroSettings,ConfigCategory.HeroGrids,ConfigCategory.ItemBuilds,ConfigCategory.Other,ConfigCategory.Video]:[ConfigCategory.Keybinds,ConfigCategory.Crosshair,ConfigCategory.Sensitivity,ConfigCategory.Viewmodel,ConfigCategory.RadarHud,ConfigCategory.Audio,ConfigCategory.Gameplay,ConfigCategory.Video,ConfigCategory.Other];
        foreach(var c in order)
        {
            bool available=safe.Contains(c);
            string info=!detected.Contains(c)?(_profile is null && IsCs?Text.Choose("Copy to inspect fields","Скопируйте для анализа полей"):Text["Unavailable"]):!available?Text.Choose("Select whole file / hardware consent","Выберите файл целиком / согласие на оборудование"):IsDota?Text["WholeFile"]:Text["Detected"];
            if(IsDota && c==ConfigCategory.HeroSettings)info=Text.Choose("Mixed files: inspect file selection","Смешанные файлы: проверьте выбор файлов");
            Categories.Add(new(c,Text[c.ToString()],info,available,available && (preserve?chosen.Contains(c):c is not ConfigCategory.Video and not ConfigCategory.Other)));
        }
    }
    private TransferSelection Selection()=>new(Categories.Where(x=>x.Selected&&x.Available).Select(x=>x.Category).ToHashSet(),ConfigFiles.Where(x=>x.Selected&&x.Enabled).Select(x=>x.Path).ToHashSet(StringComparer.OrdinalIgnoreCase),HardwareConsent);
    [RelayCommand] private void SelectAll() { foreach(var c in Categories)c.Selected=c.Available && c.Category is not ConfigCategory.Video and not ConfigCategory.Other; }
    [RelayCommand] private void SelectBinds() { foreach(var c in Categories)c.Selected=c.Available&&c.Category==ConfigCategory.Keybinds; foreach(var f in ConfigFiles)f.Selected=false; }
    [RelayCommand] private void SelectAim() { foreach(var c in Categories)c.Selected=c.Available && c.Category is ConfigCategory.Crosshair or ConfigCategory.Sensitivity; foreach(var f in ConfigFiles)f.Selected=false; }
    [RelayCommand(CanExecute=nameof(CanCopy))] private Task Copy()=>Run(async()=>
    {
        var config=Source!.Config!; var readable=config with { Files=config.Files.Where(f=>f.Issue is null).ToArray() };
        _profile=await _transfer.CaptureAsync(readable,Source.DisplayName); OperationProgress=85; RebuildComposition(); RaiseProfile(); Status=Text["Copied"]; Notify(Status);
        if(readable.Files.Count<config.Files.Count)ShowPanel(Text["Warning"],Text.Choose("Files with errors were excluded from this snapshot.","Файлы с ошибками исключены из копии."),config.Files.Where(f=>f.Issue is not null).Select(f=>new DetailRow(f.RelativePath,Message(f.Issue!))));
    });
    private GameConfig TargetConfig(AccountVM account)=>account.Config ?? new(_game,account.AccountId,Path.Combine(_scan!.SteamPath!,"userdata",account.AccountId,((int)_game).ToString()),[]);
    [RelayCommand(CanExecute=nameof(CanApply))] private Task Apply()=>Run(async()=>
    {
        var targets=BatchTargets.Where(x=>x.Selected).ToList(); if(targets.Count==0 && Target is not null) targets.Add(Target);
        var plans=new List<TransferPlan>(); var rows=new List<DetailRow>(); var previewFailures=new List<DetailRow>(); var selection=Selection();
        foreach(var targetAccount in targets)
        {
            try
            {
                var plan=await _transfer.PreviewAsync(_profile!,TargetConfig(targetAccount),selection); plans.Add(plan);
                rows.Add(new(targetAccount.DisplayName,$"{plan.Changes.Count} {Text.Choose("file(s) will change", "файл(ов) будет изменено")}"));
                rows.AddRange(plan.Changes.Select(c=>new DetailRow(c.RelativePath,ChangeDescription(c))));
            }
            catch(Exception ex) { var row=new DetailRow(targetAccount.DisplayName,Text["Error"]+": "+Message(ex.Message)); rows.Add(row);previewFailures.Add(row); }
        }
        if(plans.All(p=>p.Changes.Count==0)) { ShowPanel(Text["Review"],previewFailures.Count>0?Text["Error"]:Text["NoChanges"],rows); return; }
        ShowPanel(Text["Review"],Text["Cloud"]+"\n"+Text.Choose("Each target receives its own verified backup. New files are removed by Undo.","Для каждого получателя создаётся проверенный бэкап. Undo также удаляет новые файлы."),rows,Text["ApplyConfirmed"],async()=>await Run(async()=>
        {
            var outcomes=new List<DetailRow>(previewFailures); int i=0; int failed=previewFailures.Count;
            foreach(var plan in plans)
            {
                var result=await _transfer.ApplyAsync(plan); if(!result.Success)failed++; outcomes.Add(new(plan.Target.AccountId,Message(result.Message))); OperationProgress=10+80d*++i/plans.Count;
            }
            await RefreshLibrary(); await ScanInternal();
            ShowPanel(Text.Choose("Transfer results","Результаты переноса"),Text.Choose("Verify the settings after launching the game.","Проверьте настройки после запуска игры."),outcomes);
            Status=failed==0?Text["Done"]:Text.Choose($"{failed} target(s) failed. Review individual results.",$"Не удалось применить к {failed} аккаунтам. Проверьте результаты для каждого."); Notify(Status);
        }));
    });
    private string ChangeDescription(PlannedChange change)=>$"{(change.ExpectedHash is null?Text["Added"]:Text["Changed"])}{(change.ChangedParameters is {} n?$" · {n} {Text.Choose("parameters", "параметров")}":"")} · {Text.Choose(change.Description,change.Description.StartsWith("Merge")?"Объединение выбранных параметров с сохранением остальных":"Замена файла целиком")}";
    [RelayCommand(CanExecute=nameof(CanWork))] private Task Compare()=>Run(async()=>
    {
        if(Target is null)throw new InvalidOperationException(Text["NoTarget"]);
        var profile=_profile ?? (Source?.Config is {} c?await _transfer.CaptureAsync(c with {Files=c.Files.Where(f=>f.Issue is null).ToArray()},Source.DisplayName):throw new InvalidOperationException(Text["SelectSource"]));
        if(_profile is null){_profile=profile;RebuildComposition();RaiseProfile();}
        var rows=new List<DetailRow>();
        foreach(var category in Categories)
        {
            var selection=new TransferSelection([category.Category],[],HardwareConsent);
            var compared=await new ConfigComparisonService().CompareAsync(profile,TargetConfig(Target),selection);
            var applicable=compared.Where(x=>x.Status!="Skipped").ToArray();
            var changed=applicable.Where(x=>x.Status is "Different" or "Added").ToArray();
            rows.Add(new(category.Name,applicable.Length==0?Text.Choose("Skipped / unavailable","Пропущено / недоступно"):applicable.Any(x=>x.Status=="Warning")?Text["Warning"]:changed.Length==0?Text["Identical"]:$"{Text["Changed"]} · {changed.Length} {Text.Choose("files", "файлов")}"));
        }
        var full=await new ConfigComparisonService().CompareAsync(profile,TargetConfig(Target),Selection());
        rows.AddRange(ComparisonRows(full));
        if(_scan?.GlobalConfigPaths.Count>0) rows.AddRange(_scan.GlobalConfigPaths.Select(p=>new DetailRow(Text["Global"],p)));
        ShowPanel(Text["Compare"],$"{profile.SourceName} → {Target.DisplayName}\n"+Text.Choose("Only detected values are compared. Skipped hardware, unselected files and unknown settings are not claimed identical.","Сравниваются обнаруженные значения. Пропущенные файлы, оборудование и неизвестные параметры не считаются совпадающими."),rows);
    });
    private IEnumerable<DetailRow> ComparisonRows(IReadOnlyList<FileComparison> comparisons)
    {
        foreach(var file in comparisons)
        {
            string state=file.Status switch {"Different"=>Text["Changed"],"Added"=>Text["Added"],"Identical"=>Text["Identical"],"Skipped"=>Text.Choose("Skipped","Пропущено"),_=>Text["Warning"]};
            string counts=file.ChangedParameters is null?Text.Choose("Parameter count unavailable; file bytes compared.","Количество параметров недоступно; сравниваются байты файла."):$"{Text["Changed"]}: {file.ChangedParameters} · {Text["Added"]}: {file.AddedParameters} · {Text.Choose("removed", "удалено")}: {file.RemovedParameters} · {Text.Choose("unchanged", "без изменений")}: {file.UnchangedParameters}";
            yield return new(file.RelativePath,state+" · "+(file.Status is "Skipped" or "Warning"?Message(file.Description):counts));
            foreach(var parameter in file.Parameters.Where(p=>p.Status!="Unchanged").Take(300))yield return new(parameter.Key,$"{parameter.CurrentValue??"∅"} → {parameter.IncomingValue??"∅"}");
            if(file.Parameters.Count(p=>p.Status!="Unchanged")>300)yield return new("…",Text.Choose("More than 300 parameter differences; showing the first 300.","Более 300 различий; показаны первые 300."));
        }
    }
    private ConfigProfile SelectedProfile()
    {
        if(_profile is null)throw new InvalidOperationException(Text["SelectSource"]);
        var selection=Selection(); var files=new List<ProfileFile>();
        foreach(var file in _profile.Files)
        {
            var bytes=GameRules.Merge(_game,file.RelativePath,file.Content,null,selection); if(bytes is not null)files.Add(new(file.RelativePath,bytes,Convert.ToHexString(SHA256.HashData(bytes))));
        }
        if(files.Count==0)throw new InvalidOperationException(Text.Choose("Select supported categories or individual files.","Выберите категории или конкретные файлы."));
        return _profile with {Files=files};
    }
    [RelayCommand(CanExecute=nameof(CanUseProfile))] private void SavePreset()
    {
        ShowPanel(Text["Preset"],Text["PresetsName"],confirm:Text["Save"],action:async()=>await Run(async()=> { await _presets.SaveAsync(PanelInput,SelectedProfile()); await RefreshLibrary(); Notify(Text["Done"]); }),input:_profile!.SourceName+" · "+SelectedGameName);
    }
    [RelayCommand(CanExecute=nameof(CanWork))] private Task Import()=>Run(async()=>
    {
        var dialog=new OpenFileDialog {Title=Text["Import"],Filter="Config profiles (*.zip;*.cfg;*.vcfg;*.json;*.lst;*.txt;*.build)|*.zip;*.cfg;*.vcfg;*.json;*.lst;*.txt;*.build",CheckFileExists=true};
        if(dialog.ShowDialog()!=true)return;
        var imported=await _exchange.ImportAsync(dialog.FileName,_game); Source=null;_profile=imported; HardwareConsent=false; RebuildComposition();
        SelectExplicitOpaqueFiles();
        RaiseProfile(); Notify(Text["Copied"]);
    });
    [RelayCommand(CanExecute=nameof(CanUseProfile))] private Task Export()=>Run(async()=>
    {
        var dialog=new SaveFileDialog {Title=Text["Export"],Filter="Steam Config Manager profile (*.zip)|*.zip",FileName=IsDota?"Dota2-profile.zip":"CS2-profile.zip"};
        if(dialog.ShowDialog()==true){await _exchange.ExportAsync(SelectedProfile(),dialog.FileName);Notify(Text["Done"]);}
    });
    [RelayCommand(CanExecute=nameof(CanUseProfile))] private Task ExportFile(FileVM? file)=>Run(async()=>
    {
        if(file is null)return;
        var original=_profile!.Files.First(x=>x.RelativePath==file.Path);
        var dialog=new SaveFileDialog {Title=Text["ExportFile"],FileName=Path.GetFileName(file.Path),Filter="Configuration file|*.*"};
        if(dialog.ShowDialog()==true){await _exchange.ExportFileAsync(original,_game,dialog.FileName);Notify(Text["Done"]);}
    });
    [RelayCommand(CanExecute=nameof(CanWork))] private void OpenFolder()
    {
        var config=Source?.Config; if(config is null || !Directory.Exists(config.RootPath)){Notify(Text["ConfigMissing"]);return;}
        SafePaths.EnsureNoLinks(config.RootPath); Process.Start(new ProcessStartInfo("explorer.exe",'"'+config.RootPath+'"') {UseShellExecute=true});
    }
    [RelayCommand(CanExecute=nameof(CanWork))] private void ManageAccount()
    {
        if(Source is null)return;
        var account=Source.AccountId;
        ShowPanel(Text["ManageAccount"],Source.Account.Name+" · "+Source.SteamId64,confirm:Text["Save"],action:async()=>await Run(()=>
        {
            if(PanelInput.Length>100)throw new ArgumentException(Text.Choose("Alias must be under 100 characters.","Псевдоним должен быть короче 100 символов."));
            Settings.Aliases[account]=PanelInput.Trim(); if(PanelFavorite)Settings.Favorites.Add(account);else Settings.Favorites.Remove(account);
            _settingsService.Save(Settings); RebuildAccounts(); Notify(Text["Done"]);return Task.CompletedTask;
        }),input:Settings.Aliases.GetValueOrDefault(account,""));
        PanelIsAccount=true;PanelFavorite=Settings.Favorites.Contains(account);
    }
    private async Task RefreshLibrary()
    {
        var presets=await _presets.ListAsync(); var backups=await _backups.ListAsync(); var history=await _history.ListAsync();
        Presets.Clear(); Backups.Clear(); History.Clear();
        foreach(var p in presets)Presets.Add(new(p.Id,p.Name,$"{GameName(p.Profile.Game)} · {p.Profile.SourceName} · {p.CreatedUtc.ToLocalTime():g} · {p.Profile.Files.Sum(f=>f.Content.Length)/1024d:0.#} KB · {p.Profile.Files.Count} {Text.Choose("files", "файлов")}",p));
        foreach(var b in backups)Backups.Add(new(b.Id,$"{GameName(b.Game)} · {b.AccountId}",$"{b.CreatedUtc.ToLocalTime():g} · {b.Files.Count} {Text.Choose("files", "файлов")} · {Message(b.State)}",b));
        foreach(var h in history.Take(100))History.Add(new(h.Id,$"{h.Source} → {h.Target}",$"{h.TimeUtc.ToLocalTime():g} · {GameName(h.Game)} · {Message(h.Categories)}\n{Message(h.Message)}",h,h.Success && h.BackupId is not null && backups.Any(b=>b.Id==h.BackupId)));
    }
    private async Task RefreshLibraryCaught() { try {await RefreshLibrary();}catch(Exception ex){Notify(Text["Error"]+": "+ex.Message);} }
    [RelayCommand(CanExecute=nameof(CanWork))] private void LoadPreset(LibraryItemVM? item)
    {
        if(item?.Raw is not PresetRecord p)return;
        _game=p.Profile.Game; _profile=null; RebuildAccounts();
        var originalSource=SourceAccounts.FirstOrDefault(x=>x.AccountId==p.Profile.SourceAccountId); Source=originalSource;
        _profile=p.Profile; HardwareConsent=false; RebuildComposition();
        SelectExplicitOpaqueFiles();
        RaiseGame(); RaiseProfile(); IsLibrary=false;Notify(Text["Copied"]);
    }
    [RelayCommand(CanExecute=nameof(CanWork))] private void RenamePreset(LibraryItemVM? item)
    {
        if(item is null)return;
        ShowPanel(Text["Rename"],item.Title,confirm:Text["Save"],action:async()=>await Run(async()=>{await _presets.RenameAsync(item.Id,PanelInput);await RefreshLibrary();}),input:item.Title);
    }
    [RelayCommand(CanExecute=nameof(CanWork))] private void DeletePreset(LibraryItemVM? item)
    {
        if(item is null)return;
        ShowPanel(Text["Delete"],item.Title,confirm:Text["Delete"],action:async()=>await Run(async()=>{await _presets.DeleteAsync(item.Id);await RefreshLibrary();}));
    }
    [RelayCommand(CanExecute=nameof(CanWork))] private void RestoreBackup(LibraryItemVM? item)
    {
        if(item?.Raw is not BackupRecord backup) {IsLibrary=true;return;}
        if(!_backupStorageReady){Notify(Text.Choose("Fix backup storage in Preferences first.","Сначала исправьте путь хранилища бэкапов в настройках."));return;}
        ShowPanel(Text["Restore"],Text["Cloud"]+"\n"+backup.TargetRoot,backup.Files.Select(f=>new DetailRow(f.RelativePath,f.Existed?Text.Choose("Restore original bytes","Восстановить исходный файл"):Text.Choose("Remove file created by the transfer","Удалить файл, созданный переносом"))),Text["Restore"],async()=>await Run(async()=>
        {
            var result=await _transfer.RestoreAsync(backup); await RefreshLibrary(); if(_scan is not null)await ScanInternal(); Notify(result.Message); ShowPanel(Text["Restore"],Message(result.Message));
        }));
    }
    [RelayCommand(CanExecute=nameof(CanWork))] private void Undo(LibraryItemVM? item)
    {
        if(item?.Raw is OperationRecord h && h.BackupId is not null)RestoreBackup(Backups.FirstOrDefault(x=>x.Id==h.BackupId));
    }
    [RelayCommand(CanExecute=nameof(CanWork))] private Task CompareBackup(LibraryItemVM? item)=>Run(async()=>
    {
        if(item?.Raw is not BackupRecord b)return;
        var original=await _backups.ReadProfileAsync(b.Id);
        List<DetailRow> rows;
        try
        {
            var comparisons=await new ConfigComparisonService().CompareAsync(original,new(b.Game,b.AccountId,b.TargetRoot,[]),new([],b.Files.Where(f=>f.Existed).Select(f=>f.RelativePath).ToHashSet(StringComparer.OrdinalIgnoreCase),true));
            rows=ComparisonRows(comparisons).ToList();
        }
        catch(InvalidDataException)
        {
            rows=[];
            foreach(var file in b.Files.Where(f=>f.Existed))
            {
                var path=SafePaths.Resolve(b.TargetRoot,file.RelativePath);
                if(File.Exists(path)&&new FileInfo(path).Length>GameRules.MaxFileBytes)throw new InvalidDataException("File exceeds safety limit.");
                string? hash=File.Exists(path)?Convert.ToHexString(SHA256.HashData(await File.ReadAllBytesAsync(path))):null;
                rows.Add(new(file.RelativePath,(hash==file.Hash?Text["Identical"]:Text["Changed"])+" · "+Text.Choose("Opaque file; checksum comparison only.","Неразобранный файл; сравнение контрольных сумм.")));
            }
        }
        rows.AddRange(b.Files.Where(f=>!f.Existed).Select(f=>new DetailRow(f.RelativePath,File.Exists(SafePaths.Resolve(b.TargetRoot,f.RelativePath))?Text.Choose("Restore will remove this file (absent in backup).","При восстановлении файл будет удалён: его не было до переноса."):Text["Identical"])));
        ShowPanel(Text["Compare"],item.Title,rows);
    });
    [RelayCommand(CanExecute=nameof(CanWork))] private Task ExportBackup(LibraryItemVM? item)=>Run(async()=>
    {
        if(item is null)return;
        var dialog=new SaveFileDialog{Title=Text["Export"],Filter="Backup archive (*.zip)|*.zip",FileName="backup-"+item.Id[..8]+".zip"};
        if(dialog.ShowDialog()==true){await _backups.ExportAsync(item.Id,dialog.FileName);Notify(Text["Done"]);}
    });
    [RelayCommand(CanExecute=nameof(CanWork))] private void DeleteBackup(LibraryItemVM? item)
    {
        if(item is null)return;
        ShowPanel(Text["Delete"],item.Title+"\n"+Text.Choose("The restore point will be permanently removed.","Точка восстановления будет удалена безвозвратно."),confirm:Text["Delete"],action:async()=>await Run(async()=>{await _backups.DeleteAsync(item.Id);await RefreshLibrary();}));
    }
    [RelayCommand(CanExecute=nameof(CanWork))] private Task ChooseSteam()=>Run(async()=>
    {
        var dialog=new OpenFolderDialog{Title=Text["SteamPath"]}; if(dialog.ShowDialog()!=true)return;
        Settings.SteamPath=dialog.FolderName;OnPropertyChanged(nameof(Settings));_settingsService.Save(Settings);await ScanInternal();
    });
    [RelayCommand(CanExecute=nameof(CanWork))] private void ChooseBackup()
    {
        var dialog=new OpenFolderDialog{Title=Text["BackupPath"]};if(dialog.ShowDialog()==true){Settings.BackupPath=dialog.FolderName;OnPropertyChanged(nameof(Settings));}
    }
    [RelayCommand(CanExecute=nameof(CanWork))] private void SaveSettings()
    {
        async Task Save()=>await Run(async()=>
        {
            Settings.Language=Language;Motion.Enabled=Settings.Animations;OnPropertyChanged(nameof(Settings));
            if(Settings.RetentionDays is <1 or >3650)throw new ArgumentException(Text.Choose("Retention must be 1–3650 days.","Срок хранения: от 1 до 3650 дней."));
            if(!string.IsNullOrWhiteSpace(Settings.BackupPath))SafePaths.EnsureNoLinks(Path.GetFullPath(Settings.BackupPath));
            if(!string.Equals(_backups.Root,Path.Combine(BackupStorage(),"backups"),StringComparison.OrdinalIgnoreCase))
            {
                var unresolved=(await _backups.ListAsync()).Any(b=>b.State is "Pending" or "RecoveryRequired");
                if(unresolved)throw new IOException(Text.Choose("Recover pending operations before changing backup storage.","Восстановите прерванные операции перед сменой хранилища."));
                _backups=new(BackupStorage()); _transfer=new(_backups,_history);
            }
            _backupStorageReady=true;_backupStorageError=null;
            _settingsService.Save(Settings); await _backups.ApplyRetentionAsync(Settings); await RefreshLibrary(); UpdateStatus();Notify(Text["Done"]);
        });
        if(Settings.RetentionEnabled)ShowPanel(Text["Retention"],Text.Choose($"Completed backups older than {Settings.RetentionDays} days will be deleted. Pending recovery points are kept.",$"Завершённые бэкапы старше {Settings.RetentionDays} дней будут удалены. Точки незавершённого восстановления сохранятся."),confirm:Text["Save"],action:Save);
        else _=Save();
    }
    [RelayCommand(CanExecute=nameof(CanWork))] private void ResetSettings()=>ShowPanel(Text["Reset"],Text.Choose("Presets, backups and history will stay in their current storage. Only application preferences will reset.","Пресеты, бэкапы и история останутся в текущих хранилищах. Будут сброшены только настройки приложения."),confirm:Text["Confirm"],action:async()=>await Run(async()=>
    {
        if((await _backups.ListAsync()).Any(b=>b.State is "Pending" or "RecoveryRequired"))throw new IOException(Text.Choose("Recover pending operations before resetting preferences.","Восстановите прерванные операции перед сбросом настроек."));
        Settings=new(); Language="en"; _settingsService.Save(Settings); Motion.Enabled=true;
        _backups=new(BackupStorage());_transfer=new(_backups,_history);await RefreshLibrary();await ScanInternal();Notify(Text["Done"]);
    }));
    private void ShowPanel(string title,string description,IEnumerable<DetailRow>? rows=null,string? confirm=null,Func<Task>? action=null,string? input=null)
    {
        PanelTitle=title; PanelDescription=description;PanelRows.Clear();if(rows is not null)foreach(var row in rows)PanelRows.Add(row);
        PanelHasInput=input is not null; PanelInput=input??""; PanelIsAccount=false; PanelConfirm=confirm??Text["Close"];_panelAction=action;PanelOpen=true;
    }
    private string Message(string message)=>ServiceMessages.Translate(message,Language);
    private void SelectExplicitOpaqueFiles()
    {
        foreach(var f in ConfigFiles.Where(f=>f.Enabled))
            if(f.Path.EndsWith("dotakeys_personal.lst",StringComparison.OrdinalIgnoreCase)||_profile?.Files.Any(p=>p.RelativePath==f.Path&&p.Content.AsSpan().StartsWith("VBKV"u8))==true)f.Selected=true;
    }
    [RelayCommand] private async Task ConfirmPanel()
    {
        var action=_panelAction; PanelOpen=false;_panelAction=null; if(action is not null)await action();
    }
    [RelayCommand] private void ClosePanel(){PanelOpen=false;_panelAction=null;}
}
