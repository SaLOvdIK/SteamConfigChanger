using System.ComponentModel;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Animation;

namespace SteamConfigManager.App;
public partial class MainWindow : Window
{
    private readonly MainViewModel _viewModel;
    public MainWindow()
    {
        InitializeComponent();
        _viewModel=new MainViewModel();DataContext=_viewModel;
        WindowEffects.Apply(this);
        _viewModel.PropertyChanged+=ViewModelChanged;
        _viewModel.GameChanged+=(_,_)=>Animate("DashboardSurface");
        _viewModel.PreferencesRequested+=(_,_)=>Dispatcher.InvokeAsync(()=>{if(FindName("PreferencesCard") is FrameworkElement card)card.BringIntoView();});
        Loaded+=async(_,_)=> { Motion.AnimateIn(this);await _viewModel.InitializeAsync(); };
        PreviewKeyDown+=(_,e)=> {if(e.Key==Key.Escape && _viewModel.PanelOpen) { _viewModel.ClosePanelCommand.Execute(null);e.Handled=true; } };
        Closing+=(_,e)=> { if(_viewModel.IsBusy) { e.Cancel=true;_viewModel.Notify(_viewModel.Text.Choose("Wait for the current operation to finish before closing.","Дождитесь окончания текущей операции перед закрытием.")); } };
    }
    private void ViewModelChanged(object? sender,PropertyChangedEventArgs e)
    {
        if(e.PropertyName==nameof(MainViewModel.IsLibrary))Animate(_viewModel.IsLibrary?"LibrarySurface":"DashboardSurface");
        if(e.PropertyName==nameof(MainViewModel.PanelOpen)&&_viewModel.PanelOpen)
        {
            Animate("PanelCard");
            Dispatcher.InvokeAsync(()=> {if(FindName("PanelCard") is FrameworkElement card)card.MoveFocus(new TraversalRequest(FocusNavigationDirection.First));});
        }
        if(e.PropertyName==nameof(MainViewModel.ToastVisible)&&_viewModel.ToastVisible)Animate("ToastCard");
    }
    private void Animate(string name)=>Dispatcher.InvokeAsync(()=> {if(FindName(name) is FrameworkElement element)Motion.AnimateIn(element);});
    private void Minimize_Click(object sender,RoutedEventArgs e)=>WindowState=WindowState.Minimized;
    private void Maximize_Click(object sender,RoutedEventArgs e)=>WindowState=WindowState==WindowState.Maximized?WindowState.Normal:WindowState.Maximized;
    private void Close_Click(object sender,RoutedEventArgs e)=>Close();
    private void DragTitle_MouseLeftButtonDown(object sender,MouseButtonEventArgs e)
    {
        if(e.ChangedButton!=MouseButton.Left)return;
        if(e.ClickCount==2){Maximize_Click(sender,e);return;}
        try {DragMove();}catch(InvalidOperationException){}
    }
}
