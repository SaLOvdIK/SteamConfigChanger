using System.IO.Compression;
using System.Text.Json;

namespace SteamConfigManager.Core;

public sealed class ImportExportService
{
    private sealed record ManifestFile(string Path, string Hash, long Size);
    private sealed record ProfileManifest(string Format, int Version, GameId Game, string SourceAccountId, string SourceName, DateTime CapturedUtc, IReadOnlyList<ManifestFile> Files);
    public async Task<ConfigProfile> ImportAsync(string path, GameId game, CancellationToken ct = default)
    {
        if (!Enum.IsDefined(game)) throw new InvalidDataException("Unsupported game.");
        SafePaths.EnsureNoLinks(path);
        if (string.Equals(Path.GetExtension(path), ".zip", StringComparison.OrdinalIgnoreCase)) return await ImportZipAsync(path, game, ct);
        var name = Path.GetFileName(path);
        var candidates = game == GameId.Cs2 ? new[] { "local/cfg/" + name } : new[] { "remote/" + name, "remote/cfg/" + name, "local/cfg/" + name };
        var relative = candidates.FirstOrDefault(p => GameRules.IsAllowed(game, p));
        if (relative == null) throw new InvalidDataException("This filename is not recognized for the selected game.");
        if (!GameRules.IsAllowed(game, relative)) throw new InvalidDataException("This filename is not a supported configuration for the selected game. Import its original filename or a Steam Config Manager ZIP profile.");
        var bytes = await StorageIO.ReadAsync(path, ct);
        var profile = new ConfigProfile(game, "", "Imported " + name, [new(relative, bytes, StorageIO.Hash(bytes))], DateTime.UtcNow);
        StorageIO.ValidateProfile(profile);
        return profile;
    }
    public async Task ExportAsync(ConfigProfile profile, string path, CancellationToken ct = default)
    {
        StorageIO.ValidateProfile(profile);
        SafePaths.EnsureNoLinks(path);
        var manifest = new ProfileManifest("SteamConfigManager", 1, profile.Game, profile.SourceAccountId, profile.SourceName, profile.CapturedUtc,
            profile.Files.Select(f => new ManifestFile(f.RelativePath.Replace('\\','/'), f.Hash, f.Content.LongLength)).ToArray());
        // Build into memory within the fixed profile limit, then replace the export atomically.
        using var output = new MemoryStream();
        using (var archive = new ZipArchive(output, ZipArchiveMode.Create, true))
        {
            var metadata = archive.CreateEntry("profile.json", CompressionLevel.Optimal);
            await using (var stream = metadata.Open()) await JsonSerializer.SerializeAsync(stream, manifest, StorageIO.Json, ct);
            foreach (var file in profile.Files)
            {
                var entry = archive.CreateEntry("files/" + file.RelativePath.Replace('\\','/'), CompressionLevel.Optimal);
                await using var stream = entry.Open();
                await stream.WriteAsync(file.Content, ct);
            }
        }
        await StorageIO.WriteAtomicAsync(path, output.ToArray(), ct);
    }
    public async Task ExportFileAsync(ProfileFile file, GameId game, string path, CancellationToken ct = default)
    {
        ConfigValidationService.Validate(file, game);
        if (!string.Equals(file.Hash, StorageIO.Hash(file.Content), StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Checksum mismatch.");
        await StorageIO.WriteAtomicAsync(path, file.Content, ct);
    }
    private static async Task<ConfigProfile> ImportZipAsync(string path, GameId game, CancellationToken ct)
    {
        var compressed = await StorageIO.ReadAsync(path, ct);
        using var buffer = new MemoryStream(compressed, false);
        using var archive = new ZipArchive(buffer, ZipArchiveMode.Read);
        if (archive.Entries.Count is < 1 or > 2049) throw new InvalidDataException("Archive contains too many entries.");
        var entries = new Dictionary<string, ZipArchiveEntry>(StringComparer.OrdinalIgnoreCase);
        long total = 0;
        foreach (var entry in archive.Entries)
        {
            ct.ThrowIfCancellationRequested();
            var name = entry.FullName;
            if (name.Contains('\\') || name.StartsWith('/') || name.Contains(':') || name.Split('/').Any(p => p is "" or "." or "..") || name.Any(char.IsControl)) throw new InvalidDataException("Unsafe archive path.");
            // Reject UNIX symlinks and Windows reparse points. No archive contents are ever executed.
            if (((entry.ExternalAttributes >> 16) & 0xF000) == 0xA000 || (entry.ExternalAttributes & (int)FileAttributes.ReparsePoint) != 0) throw new InvalidDataException("Archive links are not supported.");
            if (!entries.TryAdd(name, entry)) throw new InvalidDataException("Duplicate archive entry.");
            var limit = name == "profile.json" ? 1024 * 1024 : StorageIO.MaxFileBytes;
            if (entry.Length > limit || (total += entry.Length) > StorageIO.MaxProfileBytes + 1024 * 1024) throw new InvalidDataException("Archive exceeds size limits.");
        }
        if (!entries.TryGetValue("profile.json", out var metadata)) throw new InvalidDataException(entries.ContainsKey("backup.json")
            ? "This is a complete backup archive, not a transferable profile. Restore local backups from Library; the archive retains original files and recovery metadata."
            : "This ZIP is not a Steam Config Manager profile (profile.json is missing).");
        var manifest = JsonSerializer.Deserialize<ProfileManifest>(await ReadEntryAsync(metadata, 1024 * 1024, ct), StorageIO.Json) ?? throw new InvalidDataException("Invalid profile manifest.");
        if (manifest.Format != "SteamConfigManager" || manifest.Version != 1 || manifest.Game != game || manifest.Files == null || manifest.Files.Count > 2048)
            throw new InvalidDataException("Unsupported profile version or selected game does not match the profile.");
        if (entries.Count != manifest.Files.Count + 1) throw new InvalidDataException("Archive has undeclared or missing files.");
        var files = new List<ProfileFile>();
        var declared = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var file in manifest.Files)
        {
            if (file is null || string.IsNullOrWhiteSpace(file.Path) || string.IsNullOrWhiteSpace(file.Hash) || file.Size < 1) throw new InvalidDataException("Invalid profile file metadata.");
            if (!declared.Add(file.Path) || !GameRules.IsAllowed(game, file.Path)) throw new InvalidDataException("Invalid configuration path in archive.");
            if (!entries.TryGetValue("files/" + file.Path, out var entry) || entry.Length != file.Size) throw new InvalidDataException("Profile entry is missing or its size does not match the manifest.");
            files.Add(new(file.Path, await ReadEntryAsync(entry, StorageIO.MaxFileBytes, ct), file.Hash));
        }
        var profile = new ConfigProfile(game, manifest.SourceAccountId, manifest.SourceName, files, manifest.CapturedUtc);
        StorageIO.ValidateProfile(profile);
        return profile;
    }
    private static async Task<byte[]> ReadEntryAsync(ZipArchiveEntry entry, long limit, CancellationToken ct)
    {
        await using var stream = entry.Open();
        using var result = new MemoryStream();
        var bytes = new byte[81920];
        int count;
        while ((count = await stream.ReadAsync(bytes, ct)) != 0)
        {
            if (result.Length + count > limit) throw new InvalidDataException("Expanded archive entry exceeds its limit.");
            await result.WriteAsync(bytes.AsMemory(0, count), ct);
        }
        if (result.Length != entry.Length) throw new InvalidDataException("Archive entry length mismatch.");
        return result.ToArray();
    }
}
