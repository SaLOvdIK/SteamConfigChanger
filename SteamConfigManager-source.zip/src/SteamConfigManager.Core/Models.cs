namespace SteamConfigManager.Core;

public enum GameId { Dota2 = 570, Cs2 = 730 }
public enum ConfigCategory { Keybinds, Gameplay, HeroSettings, HeroGrids, ItemBuilds, Other, Crosshair, Sensitivity, Viewmodel, RadarHud, Audio, Video }
public enum HealthStatus { Healthy, Warning, Error }
public sealed record ConfigFile(string RelativePath, ConfigCategory Category, bool HardwareSpecific, bool SupportsPartial, long Size, DateTime ModifiedUtc, string Hash, string? Issue = null);
public sealed record GameConfig(GameId Game, string AccountId, string RootPath, IReadOnlyList<ConfigFile> Files, HealthStatus Health = HealthStatus.Healthy, string? Warning = null);
public sealed record SteamAccount(string AccountId, string SteamId64, string Name, bool MostRecent = false);
public sealed record DiscoveryResult(string? SteamPath, IReadOnlyList<SteamAccount> Accounts, IReadOnlyList<GameConfig> Configs, IReadOnlyList<string> Warnings, IReadOnlyList<string> GlobalConfigPaths);
public sealed record ProfileFile(string RelativePath, byte[] Content, string Hash);
public sealed record ConfigProfile(GameId Game, string SourceAccountId, string SourceName, IReadOnlyList<ProfileFile> Files, DateTime CapturedUtc);
public sealed record TransferSelection(HashSet<ConfigCategory> Categories, HashSet<string> WholeFiles, bool AllowHardware = false);
public sealed record PlannedChange(string RelativePath, byte[] Content, string? ExpectedHash, string NewHash, int? ChangedParameters, string Description);
public sealed record TransferPlan(GameConfig Target, IReadOnlyList<PlannedChange> Changes, string SourceName, string SourceAccountId, IReadOnlyList<ConfigCategory> Categories);
public sealed record TransferResult(bool Success, string Message, string? BackupId = null);
public sealed record BackupFile(string RelativePath, bool Existed, string? Hash, string? AppliedHash);
public sealed record BackupRecord(string Id, GameId Game, string AccountId, string TargetRoot, DateTime CreatedUtc, IReadOnlyList<BackupFile> Files, string Reason, string State = "Complete");
public sealed record PresetRecord(string Id, string Name, ConfigProfile Profile, DateTime CreatedUtc);
public sealed record OperationRecord(string Id, DateTime TimeUtc, GameId Game, string Source, string Target, string Categories, bool Success, string Message, string? BackupId);
public sealed class AppSettings
{
    public string Language { get; set; } = "en";
    public bool Animations { get; set; } = true;
    public double Effects { get; set; } = .65;
    public bool AutoScan { get; set; } = true;
    public string? SteamPath { get; set; }
    public string? BackupPath { get; set; }
    public bool RetentionEnabled { get; set; }
    public int RetentionDays { get; set; } = 90;
    public Dictionary<string,string> Aliases { get; set; } = [];
    public HashSet<string> Favorites { get; set; } = [];
}
public interface IGameConfigService
{
    GameId Game { get; }
    Task<GameConfig> DiscoverAsync(string steamPath, string accountId, CancellationToken ct = default);
}
