using System.Diagnostics;

namespace SteamConfigManager.Core;

public sealed class ConfigTransferService
{
    private static readonly SemaphoreSlim OperationGate = new(1, 1);
    private readonly BackupService _backups;
    private readonly OperationHistoryService _history;
    // A deterministic failure hook used by the self-test executable; production callers leave it null.
    internal Action<int>? AfterWriteForTesting { get; set; }
    public ConfigTransferService(BackupService backups, OperationHistoryService history) { _backups = backups; _history = history; }

    public async Task<ConfigProfile> CaptureAsync(GameConfig config, string sourceName, CancellationToken ct = default)
    {
        ValidateTarget(config.Game, config.AccountId, config.RootPath);
        var files = new List<ProfileFile>();
        foreach (var file in config.Files)
        {
            ct.ThrowIfCancellationRequested();
            var data = await StorageIO.ReadAsync(SafePaths.Resolve(config.RootPath, file.RelativePath), ct, StorageIO.MaxFileBytes);
            if (!string.Equals(StorageIO.Hash(data), file.Hash, StringComparison.OrdinalIgnoreCase)) throw new IOException("Source changed after scanning. Rescan before copying.");
            files.Add(new(file.RelativePath, data, StorageIO.Hash(data)));
        }
        var profile = new ConfigProfile(config.Game, config.AccountId, sourceName, files, DateTime.UtcNow);
        StorageIO.ValidateProfile(profile);
        if (files.Count == 0) throw new InvalidDataException("No supported configuration files were found.");
        return profile;
    }

    public async Task<TransferPlan> PreviewAsync(ConfigProfile profile, GameConfig target, TransferSelection selection, CancellationToken ct = default)
    {
        StorageIO.ValidateProfile(profile);
        ValidateTarget(target.Game, target.AccountId, target.RootPath);
        if (profile.Game != target.Game) throw new InvalidDataException("The profile belongs to another game.");
        if (profile.SourceAccountId == target.AccountId) throw new InvalidOperationException("Choose a different target account.");
        var changes = new List<PlannedChange>();
        foreach (var file in profile.Files)
        {
            var rule = GameRules.Describe(profile.Game, file.RelativePath)!;
            if (rule.HardwareSpecific && !selection.AllowHardware) continue;
            var path = SafePaths.Resolve(target.RootPath, file.RelativePath);
            var previous = File.Exists(path) ? await StorageIO.ReadAsync(path, ct, StorageIO.MaxFileBytes) : null;
            if (previous?.LongLength > StorageIO.MaxFileBytes) throw new InvalidDataException("The target file exceeds the supported 16 MB limit: " + file.RelativePath);
            var content = GameRules.Merge(profile.Game, file.RelativePath, file.Content, previous, selection);
            if (content == null) continue;
            ConfigValidationService.Validate(new(file.RelativePath, content, StorageIO.Hash(content)), target.Game);
            var beforeHash = previous == null ? null : StorageIO.Hash(previous);
            var afterHash = StorageIO.Hash(content);
            if (string.Equals(beforeHash, afterHash, StringComparison.OrdinalIgnoreCase)) continue;
            bool whole = selection.WholeFiles.Any(p => p.Equals(file.RelativePath, StringComparison.OrdinalIgnoreCase));
            bool filteredConvars = profile.Game == GameId.Cs2 && GameRules.IsUserConvars(file.RelativePath) && !(whole && selection.AllowHardware);
            changes.Add(new(file.RelativePath, content, beforeHash, afterHash, CountChangedParameters(file.RelativePath, previous, content),
                filteredConvars ? "Merge selected recognized settings; retain target device and unknown values" : previous == null ? "Add file" : "Replace complete file"));
        }
        return new(target, changes, profile.SourceName, profile.SourceAccountId, selection.Categories.ToArray());
    }

    public async Task<TransferResult> ApplyAsync(TransferPlan plan, CancellationToken ct = default)
    {
        await OperationGate.WaitAsync(ct);
        try { return await ExecuteAsync(plan, new HashSet<string>(StringComparer.OrdinalIgnoreCase), "Apply configuration", ct); }
        finally { OperationGate.Release(); }
    }

    public async Task<TransferResult> RestoreAsync(BackupRecord requested, CancellationToken ct = default)
    {
        await OperationGate.WaitAsync(ct);
        try
        {
            var backup = await _backups.LoadAsync(requested.Id, ct);
            if (backup.State is "Pending" or "RecoveryRequired") throw new IOException("Recover the interrupted operation before restoring this backup.");
            EnsureGameClosed(backup.Game);
            var changes = new List<PlannedChange>();
            var deletions = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var file in backup.Files)
            {
                var currentHash = await CurrentHashAsync(SafePaths.Resolve(backup.TargetRoot, file.RelativePath), ct);
                if (file.Existed)
                {
                    var data = await _backups.ReadOriginalAsync(backup, file, ct);
                    if (currentHash != file.Hash) changes.Add(new(file.RelativePath, data, currentHash, StorageIO.Hash(data), null, "Restore original file"));
                }
                else if (currentHash != null)
                {
                    deletions.Add(file.RelativePath);
                    changes.Add(new(file.RelativePath, [], currentHash, "", null, "Remove file absent before the original operation"));
                }
            }
            var target = new GameConfig(backup.Game, backup.AccountId, backup.TargetRoot, []);
            return await ExecuteAsync(new(target, changes, "Backup " + backup.Id, "", []), deletions, "Restore backup " + backup.Id, ct, true);
        }
        finally { OperationGate.Release(); }
    }

    public async Task<IReadOnlyList<string>> RecoverPendingAsync(CancellationToken ct = default)
    {
        await OperationGate.WaitAsync(ct);
        try
        {
            var results = new List<string>();
            foreach (var backup in (await _backups.ListAsync(ct)).Where(b => b.State is "Pending" or "RecoveryRequired"))
            {
                try
                {
                    EnsureGameClosed(backup.Game);
                    await RollbackAsync(backup);
                    await _backups.SaveAsync(backup with { State = "Recovered" }, ct);
                    var message = "Recovered interrupted operation for account " + backup.AccountId + ".";
                    results.Add(message);
                    await LogAsync(backup.Game, "Recovery", backup.AccountId, "", true, message, backup.Id);
                }
                catch (Exception ex) when (ex is not OperationCanceledException)
                {
                    await _backups.SaveAsync(backup with { State = "RecoveryRequired" }, CancellationToken.None);
                    results.Add("Recovery requires attention for account " + backup.AccountId + ": " + ex.Message);
                }
            }
            return results;
        }
        finally { OperationGate.Release(); }
    }

    private async Task<TransferResult> ExecuteAsync(TransferPlan plan, HashSet<string> deletions, string reason, CancellationToken ct, bool restoringOriginal = false)
    {
        BackupRecord? backup = null;
        try
        {
            ValidatePlan(plan, deletions, restoringOriginal);
            EnsureGameClosed(plan.Target.Game);
            if (plan.Changes.Count == 0) return new(true, "No changes: selected configuration is already identical.");
            // An unresolved transaction must be recovered before any further write to its account.
            var pending = (await _backups.ListAsync(ct)).Any(b => b.Game == plan.Target.Game && b.AccountId == plan.Target.AccountId && b.State is "Pending" or "RecoveryRequired");
            if (pending) throw new IOException("An interrupted operation must be recovered before changing this account.");
            await PreflightAsync(plan, ct);
            backup = await _backups.CreateAsync(plan, reason, ct);
            var index = 0;
            foreach (var change in plan.Changes)
            {
                ct.ThrowIfCancellationRequested(); EnsureGameClosed(plan.Target.Game);
                var path = SafePaths.Resolve(plan.Target.RootPath, change.RelativePath);
                await CheckExpectedAsync(path, change.ExpectedHash, ct);
                if (deletions.Contains(change.RelativePath)) File.Delete(path);
                else await StorageIO.WriteAtomicAsync(path, change.Content, ct);
                var expected = deletions.Contains(change.RelativePath) ? null : change.NewHash;
                if (!string.Equals(await CurrentHashAsync(path, ct), expected, StringComparison.OrdinalIgnoreCase)) throw new IOException("Verification failed: " + change.RelativePath);
                AfterWriteForTesting?.Invoke(++index);
            }
            await _backups.SaveAsync(backup with { State = "Complete" }, CancellationToken.None);
            var message = $"Applied and verified {plan.Changes.Count} file(s). Start the game to confirm; Steam Cloud may offer a conflict.";
            await LogAsync(plan.Target.Game, plan.SourceName, plan.Target.AccountId, string.Join(", ", plan.Categories), true, message, backup.Id);
            return new(true, message, backup.Id);
        }
        catch (Exception ex)
        {
            var message = ex is OperationCanceledException ? "Operation cancelled." : ex.Message;
            if (backup != null)
            {
                try
                {
                    await RollbackAsync(backup);
                    await _backups.SaveAsync(backup with { State = "RolledBack" }, CancellationToken.None);
                    message += " Original files restored and verified.";
                }
                catch (Exception rollbackError)
                {
                    await _backups.SaveAsync(backup with { State = "RecoveryRequired" }, CancellationToken.None);
                    message += " Recovery requires attention: " + rollbackError.Message + " Original backup is retained.";
                }
            }
            await LogAsync(plan.Target.Game, plan.SourceName, plan.Target.AccountId, string.Join(", ", plan.Categories), false, message, backup?.Id);
            return new(false, message, backup?.Id);
        }
    }

    private async Task RollbackAsync(BackupRecord backup)
    {
        ValidateTarget(backup.Game, backup.AccountId, backup.TargetRoot);
        EnsureGameClosed(backup.Game);
        var originals = new Dictionary<string, byte[]>(StringComparer.OrdinalIgnoreCase);
        // Verify every original and current file before restoring any file.
        foreach (var file in backup.Files)
        {
            var path = SafePaths.Resolve(backup.TargetRoot, file.RelativePath);
            var hash = await CurrentHashAsync(path);
            if (!SameHash(hash, file.Hash) && !SameHash(hash, file.AppliedHash)) throw new IOException("A file changed outside this operation; recovery will not overwrite it: " + file.RelativePath);
            if (file.Existed) originals[file.RelativePath] = await _backups.ReadOriginalAsync(backup, file);
        }
        foreach (var file in backup.Files.Reverse())
        {
            EnsureGameClosed(backup.Game);
            var path = SafePaths.Resolve(backup.TargetRoot, file.RelativePath);
            var current = await CurrentHashAsync(path);
            if (SameHash(current, file.Hash)) continue;
            if (!SameHash(current, file.AppliedHash)) throw new IOException("File changed during recovery: " + file.RelativePath);
            if (file.Existed) await StorageIO.WriteAtomicAsync(path, originals[file.RelativePath]);
            else File.Delete(path);
            if (!SameHash(await CurrentHashAsync(path), file.Hash)) throw new IOException("Recovery verification failed: " + file.RelativePath);
        }
    }

    private static void ValidatePlan(TransferPlan plan, HashSet<string> deletions, bool restoringOriginal)
    {
        ValidateTarget(plan.Target.Game, plan.Target.AccountId, plan.Target.RootPath);
        var paths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        long total = 0;
        if (plan.Changes.Count > 2048) throw new InvalidDataException("Too many files.");
        foreach (var change in plan.Changes)
        {
            if (!paths.Add(change.RelativePath.Replace('\\','/')) || !GameRules.IsAllowed(plan.Target.Game, change.RelativePath)) throw new InvalidDataException("Invalid or duplicate target path.");
            SafePaths.Resolve(plan.Target.RootPath, change.RelativePath);
            if (!deletions.Contains(change.RelativePath))
            {
                if (change.Content.LongLength > StorageIO.MaxFileBytes || (total += change.Content.LongLength) > StorageIO.MaxProfileBytes) throw new InvalidDataException("Transfer exceeds safety limits.");
                if (!SameHash(StorageIO.Hash(change.Content), change.NewHash)) throw new InvalidDataException("Transfer checksum mismatch.");
                // Original backup bytes are restored exactly, even when the previous file was malformed.
                if (!restoringOriginal) ConfigValidationService.Validate(new(change.RelativePath, change.Content, change.NewHash), plan.Target.Game);
            }
        }
    }
    internal static void ValidateTarget(GameId game, string accountId, string root)
    {
        if (!Enum.IsDefined(game) || !uint.TryParse(accountId, out var id) || id == 0 || id.ToString() != accountId) throw new InvalidDataException("Invalid game or account identifier.");
        var full = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        var suffix = Path.Combine("userdata", accountId, ((int)game).ToString());
        if (!full.EndsWith(Path.DirectorySeparatorChar + suffix, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("The target must be the selected account's Steam configuration directory.");
        SafePaths.EnsureNoLinks(full);
    }
    private static async Task PreflightAsync(TransferPlan plan, CancellationToken ct)
    {
        long total = 0;
        foreach (var change in plan.Changes)
        {
            var path = SafePaths.Resolve(plan.Target.RootPath, change.RelativePath);
            await CheckExpectedAsync(path, change.ExpectedHash, ct);
            if (File.Exists(path))
            {
                using var stream = new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None);
                if (stream.Length > StorageIO.MaxFileBytes || (total += stream.Length) > StorageIO.MaxProfileBytes) throw new InvalidDataException("Target configuration exceeds backup safety limits.");
                if ((File.GetAttributes(path) & FileAttributes.ReadOnly) != 0) throw new UnauthorizedAccessException("Target is read-only: " + change.RelativePath);
            }
        }
    }
    private static async Task CheckExpectedAsync(string path, string? expected, CancellationToken ct)
    {
        if (!SameHash(await CurrentHashAsync(path, ct), expected)) throw new IOException("Target changed since the preview. Refresh before applying: " + Path.GetFileName(path));
    }
    private static async Task<string?> CurrentHashAsync(string path, CancellationToken ct = default)
    {
        SafePaths.EnsureNoLinks(path);
        return File.Exists(path) ? StorageIO.Hash(await StorageIO.ReadAsync(path, ct, StorageIO.MaxFileBytes)) : null;
    }
    private static bool SameHash(string? a, string? b) => string.Equals(a, b, StringComparison.OrdinalIgnoreCase);
    private static int? CountChangedParameters(string path, byte[]? before, byte[] after)
    {
        if (!path.EndsWith(".vcfg", StringComparison.OrdinalIgnoreCase)) return null;
        try
        {
            var oldValues = before == null ? new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase) : KeyValues.Parse(GameRules.Decode(before)).FlattenLeaves();
            var newValues = KeyValues.Parse(GameRules.Decode(after)).FlattenLeaves();
            return oldValues.Keys.Union(newValues.Keys, StringComparer.OrdinalIgnoreCase).Count(key => !oldValues.TryGetValue(key, out var oldValue) || !newValues.TryGetValue(key, out var newValue) || oldValue != newValue);
        }
        catch (InvalidDataException) { return null; }
    }
    private static void EnsureGameClosed(GameId game)
    {
        foreach (var process in Process.GetProcessesByName(game == GameId.Dota2 ? "dota2" : "cs2"))
        {
            using (process) { if (!process.HasExited) throw new IOException("The game is running. Close it before changing configuration files."); }
        }
    }
    private Task LogAsync(GameId game, string source, string target, string categories, bool success, string message, string? backupId) =>
        _history.AddAsync(new(StorageIO.Id(), DateTime.UtcNow, game, source, target, categories, success, message, backupId), CancellationToken.None);
}
