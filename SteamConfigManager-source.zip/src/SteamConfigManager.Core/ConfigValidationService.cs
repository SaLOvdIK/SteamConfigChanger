using System.Security.Cryptography;
using System.Text.Json;

namespace SteamConfigManager.Core;

public static class ConfigValidationService
{
    public static void Validate(ProfileFile file, GameId game)
    {
        if (file is null || string.IsNullOrWhiteSpace(file.RelativePath) || file.Content is null) throw new InvalidDataException("A configuration entry is missing its path or content.");
        if (!GameRules.IsAllowed(game, file.RelativePath)) throw new InvalidDataException("This file is not a supported configuration for the selected game: " + file.RelativePath);
        _ = SafePaths.Resolve(Path.GetTempPath(), file.RelativePath);
        if (file.Content.Length == 0 || file.Content.Length > GameRules.MaxFileBytes) throw new InvalidDataException("The configuration is empty or larger than 16 MiB.");
        var actualHash = Convert.ToHexString(SHA256.HashData(file.Content));
        if (string.IsNullOrWhiteSpace(file.Hash) || !actualHash.Equals(file.Hash, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("The configuration checksum does not match: " + file.RelativePath);
        var ext = Path.GetExtension(file.RelativePath).ToLowerInvariant();
        if (game == GameId.Dota2 && BinaryKeyValues.HasHeader(file.Content))
        {
            var relative = file.RelativePath.Replace('\\', '/').ToLowerInvariant();
            var root = relative switch
            {
                "remote/cfg/herobuilds.cfg" => "HeroBuildConfig",
                "remote/cfg/hero_facet_config.cfg" => "hero_facet_config",
                _ => throw new InvalidDataException("VBKV is supported only for the recognized Dota hero configuration files.")
            };
            BinaryKeyValues.Validate(file.Content, root);
            return;
        }
        var text = GameRules.Decode(file.Content);
        // Dota's guide writer can include one final C-string terminator. Preserve the original bytes,
        // accepting the terminator only for this known format; embedded or repeated NUL bytes remain invalid.
        if (game == GameId.Dota2 && ext == ".build" && text.EndsWith('\0')) text = text[..^1];
        if (text.Contains('\0') || text.Any(c => char.IsControl(c) && c is not '\r' and not '\n' and not '\t')) throw new InvalidDataException("The configuration contains binary or invalid control data.");
        if (ext == ".json")
        {
            try
            {
                using var json = JsonDocument.Parse(text, new JsonDocumentOptions { MaxDepth = 64 });
                if (json.RootElement.ValueKind != JsonValueKind.Object) throw new InvalidDataException("A hero grid must contain a JSON object.");
                if (!json.RootElement.TryGetProperty("configs", out var grids) || grids.ValueKind != JsonValueKind.Array) throw new InvalidDataException("The hero grid does not contain a configs array.");
            }
            catch (JsonException ex) { throw new InvalidDataException("The hero grid has invalid JSON structure.", ex); }
        }
        else if (ext is ".vcfg" or ".lst" or ".build" || file.RelativePath.Contains("/itembuilds/", StringComparison.OrdinalIgnoreCase) || Path.GetFileName(file.RelativePath) is "cs2_video.txt" or "video.txt")
        {
            var document = KeyValues.Parse(text, useEscapeSequences: ext != ".lst");
            if (document.Entries.Count == 0) throw new InvalidDataException("The configuration has no settings.");
            if (game == GameId.Cs2 && GameRules.IsUserConvars(file.RelativePath))
            {
                _ = GameRules.Convars(document);
                _ = document.FlattenLeaves();
            }
            if (game == GameId.Cs2 && Path.GetFileName(file.RelativePath).StartsWith("cs2_user_keys_", StringComparison.OrdinalIgnoreCase))
            {
                if (document.Find("config")?.Children?.Find("bindings")?.Children is null) throw new InvalidDataException("Expected a bindings object in the CS2 keybind file.");
                _ = document.FlattenLeaves();
            }
        }
        // Console scripts are transferred as opaque text. They are never executed by this application.
    }
}
