using System.Buffers.Binary;
using System.Text;

namespace SteamConfigManager.Core;

/// <summary>
/// Read-only structural validation for the observed Dota VBKV profile variant: objects, UTF-8 strings,
/// int32 values and 0x0B end markers. Unknown variants are refused, never rewritten or interpreted as commands.
/// Binary node layout: Valve Source SDK tier1/KeyValues.cpp (WriteAsBinary/ReadAsBinary).
/// VBKV envelope: https://github.com/ValvePython/vdf/blob/master/vdf/__init__.py (vbkv_loads).
/// </summary>
public static class BinaryKeyValues
{
    private static readonly UTF8Encoding Utf8 = new(false, true);
    private static readonly uint[] CrcTable = CreateCrcTable();
    public static bool HasHeader(ReadOnlySpan<byte> content) => content.Length >= 4 && content[..4].SequenceEqual("VBKV"u8);

    public static void Validate(byte[] content, string expectedRoot)
    {
        if (content.Length is < 12 or > GameRules.MaxFileBytes || !HasHeader(content)) throw new InvalidDataException("Invalid or truncated VBKV header.");
        if (BinaryPrimitives.ReadUInt32LittleEndian(content.AsSpan(4, 4)) != ComputeCrc32(content.AsSpan(8))) throw new InvalidDataException("VBKV checksum mismatch.");
        new Reader(content.AsSpan(8)).Validate(expectedRoot);
    }

    internal static uint ComputeCrc32(ReadOnlySpan<byte> data)
    {
        uint crc = uint.MaxValue;
        foreach (var item in data) crc = (crc >> 8) ^ CrcTable[(byte)(crc ^ item)];
        return ~crc;
    }
    private static uint[] CreateCrcTable()
    {
        var table = new uint[256];
        for (uint i = 0; i < table.Length; i++)
        {
            var value = i;
            for (int bit = 0; bit < 8; bit++) value = (value >> 1) ^ ((value & 1) == 0 ? 0u : 0xEDB88320u);
            table[i] = value;
        }
        return table;
    }
    private ref struct Reader(ReadOnlySpan<byte> data)
    {
        private readonly ReadOnlySpan<byte> _data = data;
        private int _position, _nodes;
        public void Validate(string expectedRoot)
        {
            if (Take() != 0) throw new InvalidDataException("VBKV must contain one root object.");
            var root = ReadString(true);
            if (!Utf8.GetString(root).Equals(expectedRoot, StringComparison.Ordinal)) throw new InvalidDataException("VBKV root does not match the selected Dota configuration file.");
            ReadChildren(1);
            if (Take() != 11 || _position != _data.Length) throw new InvalidDataException("VBKV has missing end markers or trailing data.");
        }
        private void ReadChildren(int depth)
        {
            if (depth > 64) throw new InvalidDataException("VBKV nesting exceeds the safe limit.");
            while (true)
            {
                var type = Take();
                if (type == 11) return;
                if (++_nodes > 200_000) throw new InvalidDataException("VBKV contains too many settings.");
                _ = ReadString(true);
                switch (type)
                {
                    case 0: ReadChildren(depth + 1); break;
                    case 1: _ = ReadString(false); break;
                    case 2:
                        if (_data.Length - _position < 4) throw new InvalidDataException("VBKV contains a truncated integer value.");
                        _position += 4;
                        break;
                    default: throw new InvalidDataException("Unsupported VBKV value type; only the verified Dota profile variant can be transferred.");
                }
            }
        }
        private byte Take()
        {
            if (_position >= _data.Length) throw new InvalidDataException("VBKV is truncated or an end marker is missing.");
            return _data[_position++];
        }
        private ReadOnlySpan<byte> ReadString(bool isKey)
        {
            var remaining = _data[_position..];
            int end = remaining.IndexOf((byte)0);
            if (end < 0 || end > (isKey ? 4096 : 1024 * 1024) || isKey && end == 0) throw new InvalidDataException("VBKV contains an invalid or unterminated string.");
            var value = remaining[..end];
            try { _ = Utf8.GetCharCount(value); }
            catch (DecoderFallbackException ex) { throw new InvalidDataException("VBKV contains invalid UTF-8 text.", ex); }
            _position += end + 1;
            return value;
        }
    }
}
