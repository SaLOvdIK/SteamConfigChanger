using System.Text;

namespace SteamConfigManager.Core;

public sealed class KeyValuesEntry(string key, string? value = null, KeyValuesDocument? children = null)
{
    public string Key { get; set; } = key;
    public string? Value { get; set; } = value;
    public KeyValuesDocument? Children { get; set; } = children;
    public KeyValuesEntry Clone() => new(Key, Value, Children?.Clone());
}

public sealed class KeyValuesDocument
{
    public List<KeyValuesEntry> Entries { get; } = [];
    public KeyValuesEntry? Find(string key) => Entries.FirstOrDefault(e => e.Key.Equals(key, StringComparison.OrdinalIgnoreCase));
    public KeyValuesDocument Clone()
    {
        var copy = new KeyValuesDocument();
        copy.Entries.AddRange(Entries.Select(e => e.Clone()));
        return copy;
    }
    public Dictionary<string, string> FlattenLeaves()
    {
        var values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        Flatten(this, "", values);
        return values;
    }
    private static void Flatten(KeyValuesDocument doc, string prefix, Dictionary<string,string> values)
    {
        var siblings = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var item in doc.Entries)
        {
            // Duplicate objects can have disjoint leaf names and still be ambiguous to Valve's reader.
            // Reject them before any merge, including an object/leaf pair with the same name.
            if (!siblings.Add(item.Key)) throw new InvalidDataException("Duplicate settings prevent a reliable comparison: " + prefix + item.Key);
            var name = prefix + item.Key;
            if (item.Children is not null) Flatten(item.Children, name + "/", values);
            else if (!values.TryAdd(name, item.Value ?? "")) throw new InvalidDataException("Duplicate settings prevent a reliable comparison: " + name);
        }
    }
    public override string ToString()
    {
        var output = new StringBuilder();
        Write(this, output, 0);
        return output.ToString();
    }
    private static void Write(KeyValuesDocument doc, StringBuilder text, int depth)
    {
        foreach (var e in doc.Entries)
        {
            text.Append('\t', depth).Append('"').Append(Escape(e.Key)).Append('"');
            if (e.Children is null) text.Append("\t\t\"").Append(Escape(e.Value ?? "")).Append("\"\r\n");
            else { text.Append("\r\n").Append('\t', depth).Append("{\r\n"); Write(e.Children, text, depth + 1); text.Append('\t', depth).Append("}\r\n"); }
        }
    }
    private static string Escape(string value) => value.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", "\\r").Replace("\n", "\\n").Replace("\t", "\\t");
}

/// <summary>Bounded Valve KeyValues 1 parser. Conditional/include directives are rejected rather than guessed.</summary>
public static class KeyValues
{
    public static KeyValuesDocument Parse(string text, bool useEscapeSequences = true)
    {
        if (text.Length > 16 * 1024 * 1024 || text.Contains('\0')) throw new InvalidDataException("The configuration exceeds the supported text limits.");
        return new Parser(text.TrimStart('\uFEFF'),useEscapeSequences).Parse();
    }

    private sealed class Parser(string text,bool useEscapeSequences)
    {
        private int _position, _entries;
        private sealed record Token(string Value, bool Quoted = false);
        public KeyValuesDocument Parse()
        {
            var result = Block(0, false);
            if (Next() is not null) throw new InvalidDataException("Unexpected data after the configuration.");
            return result;
        }
        private KeyValuesDocument Block(int depth, bool nested)
        {
            if (depth > 64) throw new InvalidDataException("The configuration is nested too deeply.");
            var result = new KeyValuesDocument();
            Token? key;
            while ((key = Next()) is not null)
            {
                if (!key.Quoted && key.Value == "}") { if (!nested) throw new InvalidDataException("Unexpected closing brace."); return result; }
                if (!key.Quoted && (key.Value == "{" || key.Value.StartsWith('#') || key.Value.StartsWith('['))) throw new InvalidDataException("Unsupported configuration directive or structure.");
                if (++_entries > 200_000) throw new InvalidDataException("The configuration has too many settings.");
                var value = Next() ?? throw new InvalidDataException("A configuration value is missing.");
                if (!value.Quoted && value.Value == "}") throw new InvalidDataException("A configuration value is missing before a closing brace.");
                result.Entries.Add(!value.Quoted && value.Value == "{" ? new(key.Value, children: Block(depth + 1, true)) : new(key.Value, value.Value));
            }
            if (nested) throw new InvalidDataException("The configuration has an unclosed brace.");
            return result;
        }
        private Token? Next()
        {
            while (_position < text.Length)
            {
                if (char.IsWhiteSpace(text[_position])) { _position++; continue; }
                if (text[_position] == '/' && _position + 1 < text.Length && text[_position + 1] == '/')
                { while (_position < text.Length && text[_position] != '\n') _position++; continue; }
                break;
            }
            if (_position == text.Length) return null;
            char first = text[_position++];
            if (first is '{' or '}') return new(first.ToString());
            var result = new StringBuilder();
            if (first == '"')
            {
                while (_position < text.Length)
                {
                    var c = text[_position++];
                    if (c == '"') return new(result.ToString(), true);
                    if (useEscapeSequences && c == '\\' && _position < text.Length)
                    {
                        char escaped = text[_position++];
                        switch (escaped) { case 'n': result.Append('\n'); break; case 'r': result.Append('\r'); break; case 't': result.Append('\t'); break; case '\\': result.Append('\\'); break; case '"': result.Append('"'); break; default: result.Append('\\').Append(escaped); break; }
                    }
                    else result.Append(c);
                }
                throw new InvalidDataException("The configuration has an unclosed quoted string.");
            }
            result.Append(first);
            while (_position < text.Length && !char.IsWhiteSpace(text[_position]) && text[_position] is not '{' and not '}') result.Append(text[_position++]);
            return new(result.ToString());
        }
    }
}
