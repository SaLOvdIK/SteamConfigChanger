namespace SteamConfigManager.Core;

public sealed record ParameterDifference(string Key, string? CurrentValue, string? IncomingValue, string Status);
public sealed record FileComparison(string RelativePath, string Status, int? ChangedParameters, int? AddedParameters,
    int? RemovedParameters, int? UnchangedParameters, IReadOnlyList<ParameterDifference> Parameters, string Description);

/// <summary>Read-only comparison of the effective selected transfer, retaining target settings outside the selection.</summary>
public sealed class ConfigComparisonService
{
    public async Task<IReadOnlyList<FileComparison>> CompareAsync(ConfigProfile source, GameConfig target,
        TransferSelection selection, CancellationToken ct = default)
    {
        StorageIO.ValidateProfile(source);
        ConfigTransferService.ValidateTarget(target.Game, target.AccountId, target.RootPath);
        if (source.Game != target.Game) throw new InvalidDataException("The profile belongs to another game.");
        var results = new List<FileComparison>();
        foreach (var file in source.Files)
        {
            ct.ThrowIfCancellationRequested();
            var rule = GameRules.Describe(source.Game, file.RelativePath)!;
            if (rule.HardwareSpecific && !selection.AllowHardware)
            {
                results.Add(new(file.RelativePath, "Skipped", null, null, null, null, [], "Hardware or mixed settings require explicit consent."));
                continue;
            }
            try
            {
                var path = SafePaths.Resolve(target.RootPath, file.RelativePath);
                var before = File.Exists(path) ? await StorageIO.ReadAsync(path, ct, StorageIO.MaxFileBytes) : null;
                var after = GameRules.Merge(source.Game, file.RelativePath, file.Content, before, selection);
                if (after is null)
                {
                    results.Add(new(file.RelativePath, "Skipped", null, null, null, null, [], "No transferable setting was selected in this file."));
                    continue;
                }
                var status = before is null ? "Added" : before.SequenceEqual(after) ? "Identical" : "Different";
                IReadOnlyList<ParameterDifference> parameters = [];
                int? changed = null, added = null, removed = null, unchanged = null;
                if (file.RelativePath.EndsWith(".vcfg", StringComparison.OrdinalIgnoreCase))
                {
                    try
                    {
                        var oldValues = before is null ? new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase) : KeyValues.Parse(GameRules.Decode(before)).FlattenLeaves();
                        var newValues = KeyValues.Parse(GameRules.Decode(after)).FlattenLeaves();
                        parameters = oldValues.Keys.Union(newValues.Keys, StringComparer.OrdinalIgnoreCase).Order(StringComparer.OrdinalIgnoreCase)
                            .Select(key =>
                            {
                                var existed = oldValues.TryGetValue(key, out var current);
                                var exists = newValues.TryGetValue(key, out var incoming);
                                return new ParameterDifference(key, current, incoming, !existed ? "Added" : !exists ? "Removed" : current == incoming ? "Unchanged" : "Changed");
                            }).ToArray();
                        changed = parameters.Count(p => p.Status == "Changed");
                        added = parameters.Count(p => p.Status == "Added");
                        removed = parameters.Count(p => p.Status == "Removed");
                        unchanged = parameters.Count(p => p.Status == "Unchanged");
                        // Formatting differences alone do not claim changed settings.
                        if (before is not null && changed + added + removed == 0) status = "Identical";
                    }
                    catch (InvalidDataException) { /* Opaque whole-file comparison remains valid; parameter counts are unavailable. */ }
                }
                results.Add(new(file.RelativePath, status, changed, added, removed, unchanged, parameters,
                    changed is null ? "Compared complete file bytes; reliable parameter counts are unavailable." : "Compared the settings that would result from the selected transfer."));
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or InvalidDataException)
            {
                results.Add(new(file.RelativePath, "Warning", null, null, null, null, [], ex.Message));
            }
        }
        return results;
    }
}
