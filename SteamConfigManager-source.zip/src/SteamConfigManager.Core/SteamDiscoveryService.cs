using System.Collections.Concurrent;
using Microsoft.Win32;

namespace SteamConfigManager.Core;

public static class SteamAccountService
{
    public const ulong IndividualPublicBase = 76561197960265728UL;
    public static bool TryGetAccountId(string steamId64, out string accountId)
    {
        accountId = "";
        if (!ulong.TryParse(steamId64, out var value) || value <= IndividualPublicBase || value > IndividualPublicBase + uint.MaxValue) return false;
        accountId = (value - IndividualPublicBase).ToString(System.Globalization.CultureInfo.InvariantCulture);
        return true;
    }

    internal static IReadOnlyList<SteamAccount> Discover(string steamPath, List<string> warnings)
    {
        var accounts = new Dictionary<string, SteamAccount>(StringComparer.Ordinal);
        var loginPath = SafePaths.Resolve(steamPath, "config/loginusers.vdf");
        if (File.Exists(loginPath))
        {
            try
            {
                var bytes = ReadBounded(loginPath, 4 * 1024 * 1024);
                var document = KeyValues.Parse(GameRules.Decode(bytes));
                var users = document.Find("users")?.Children;
                if (users is null) warnings.Add("Steam loginusers.vdf does not contain a users object.");
                else foreach (var entry in users.Entries.Take(1000))
                {
                    if (!TryGetAccountId(entry.Key, out var id) || entry.Children is null) continue;
                    var persona = entry.Children.Find("PersonaName")?.Value;
                    var name = string.IsNullOrWhiteSpace(persona) ? "Account " + id : persona.Length > 100 ? persona[..100] : persona;
                    accounts.TryAdd(id, new(id, entry.Key, name, entry.Children.Find("MostRecent")?.Value == "1"));
                }
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or InvalidDataException) { warnings.Add("Cannot read Steam account names: " + ex.Message); }
        }
        var userdata = SafePaths.Resolve(steamPath, "userdata");
        if (Directory.Exists(userdata))
        {
            try
            {
                foreach (var path in Directory.EnumerateDirectories(userdata).Take(1001))
                {
                    if (accounts.Count >= 1000) { warnings.Add("Account discovery reached its safe limit of 1000 accounts."); break; }
                    var id = Path.GetFileName(path);
                    if (!uint.TryParse(id, out var value) || value == 0 || id != value.ToString(System.Globalization.CultureInfo.InvariantCulture)) continue;
                    try { SafePaths.EnsureNoLinks(path); }
                    catch (InvalidDataException) { warnings.Add("Skipped a linked userdata folder."); continue; }
                    accounts.TryAdd(id, new(id, (IndividualPublicBase + value).ToString(System.Globalization.CultureInfo.InvariantCulture), "Account " + id));
                }
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { warnings.Add("Cannot enumerate Steam userdata: " + ex.Message); }
        }
        return accounts.Values.OrderByDescending(a => a.MostRecent).ThenBy(a => a.Name, StringComparer.CurrentCultureIgnoreCase).ToArray();
    }

    internal static byte[] ReadBounded(string path, int maxBytes)
    {
        SafePaths.EnsureNoLinks(path);
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        if (stream.Length == 0 || stream.Length > maxBytes) throw new InvalidDataException("The metadata file is empty or larger than the supported limit.");
        var bytes = new byte[checked((int)stream.Length)];
        stream.ReadExactly(bytes);
        return bytes;
    }
}

public sealed class SteamDiscoveryService
{
    public async Task<DiscoveryResult> ScanAsync(string? manualPath = null, CancellationToken cancellationToken = default)
    {
        var warnings = new List<string>();
        var steam = await Task.Run(() => FindSteam(manualPath, warnings), cancellationToken).ConfigureAwait(false);
        if (steam is null) return new(null, [], [], warnings.Count > 0 ? warnings : ["Steam was not found. Select the Steam installation folder in Library preferences."], []);
        var accounts = await Task.Run(() => SteamAccountService.Discover(steam, warnings), cancellationToken).ConfigureAwait(false);
        var configs = new ConcurrentBag<GameConfig>();
        await Parallel.ForEachAsync(accounts, new ParallelOptions { CancellationToken = cancellationToken, MaxDegreeOfParallelism = 4 }, async (account, ct) =>
        {
            foreach (var service in new IGameConfigService[] { new DotaConfigService(), new CS2ConfigService() })
            {
                try { configs.Add(await service.DiscoverAsync(steam, account.AccountId, ct).ConfigureAwait(false)); }
                catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or InvalidDataException)
                {
                    var root = Path.Combine(steam, "userdata", account.AccountId, ((int)service.Game).ToString());
                    configs.Add(new(service.Game, account.AccountId, root, [], HealthStatus.Error, ex.Message));
                }
            }
        }).ConfigureAwait(false);
        var globals = await Task.Run(() => DiscoverGlobals(steam, warnings), cancellationToken).ConfigureAwait(false);
        if (accounts.Count == 0) warnings.Add("No locally known Steam accounts were found. Sign in to Steam once, then rescan.");
        return new(steam, accounts, configs.OrderBy(c => c.AccountId).ThenBy(c => c.Game).ToArray(), warnings.Distinct().ToArray(), globals);
    }

    private static string? FindSteam(string? manualPath, List<string> warnings)
    {
        var candidates = new List<string>();
        if (!string.IsNullOrWhiteSpace(manualPath)) candidates.Add(manualPath);
        if (OperatingSystem.IsWindows())
        {
            foreach (var (hive, view, key, value) in new[] {
                (RegistryHive.CurrentUser, RegistryView.Default, @"Software\Valve\Steam", "SteamPath"),
                (RegistryHive.CurrentUser, RegistryView.Default, @"Software\Valve\Steam", "SteamExe"),
                (RegistryHive.LocalMachine, RegistryView.Registry32, @"SOFTWARE\Valve\Steam", "InstallPath"),
                (RegistryHive.LocalMachine, RegistryView.Registry64, @"SOFTWARE\Valve\Steam", "InstallPath") })
            {
                try
                {
                    using var baseKey = RegistryKey.OpenBaseKey(hive, view);
                    using var steamKey = baseKey.OpenSubKey(key, false);
                    if (steamKey?.GetValue(value) is string path) candidates.Add(value == "SteamExe" ? Path.GetDirectoryName(path) ?? "" : path);
                }
                catch (Exception ex) when (ex is UnauthorizedAccessException or System.Security.SecurityException or IOException) { warnings.Add("A Steam registry location could not be read."); }
            }
        }
        candidates.Add(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Steam"));
        candidates.Add(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Steam"));
        try
        {
            foreach (var drive in DriveInfo.GetDrives().Where(d => d.DriveType == DriveType.Fixed && d.IsReady))
            {
                candidates.Add(Path.Combine(drive.RootDirectory.FullName, "Steam"));
                candidates.Add(Path.Combine(drive.RootDirectory.FullName, "Program Files (x86)", "Steam"));
                candidates.Add(Path.Combine(drive.RootDirectory.FullName, "Program Files", "Steam"));
            }
        }
        catch (IOException) { }
        foreach (var path in candidates.Where(p => !string.IsNullOrWhiteSpace(p)).Distinct(StringComparer.OrdinalIgnoreCase))
        {
            try
            {
                var full = Path.GetFullPath(path.Trim().Trim('"'));
                SafePaths.EnsureNoLinks(full);
                if (Directory.Exists(full) && (File.Exists(Path.Combine(full, "steam.exe")) || (Directory.Exists(Path.Combine(full, "userdata")) && File.Exists(Path.Combine(full, "config", "loginusers.vdf"))))) return full;
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or InvalidDataException or ArgumentException or NotSupportedException) { warnings.Add("Skipped an inaccessible or linked Steam candidate: " + ex.Message); }
        }
        if (!string.IsNullOrWhiteSpace(manualPath)) warnings.Add("The selected path is not a recognized Steam installation folder.");
        return null;
    }

    private static IReadOnlyList<string> DiscoverGlobals(string steam, List<string> warnings)
    {
        var libraries = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { steam };
        var result = new List<string>();
        try
        {
            var folders = SafePaths.Resolve(steam, "steamapps/libraryfolders.vdf");
            if (File.Exists(folders))
            {
                var doc = KeyValues.Parse(GameRules.Decode(SteamAccountService.ReadBounded(folders, 4 * 1024 * 1024)));
                foreach (var entry in doc.Find("libraryfolders")?.Children?.Entries ?? [])
                {
                    var path = entry.Children?.Find("path")?.Value ?? (uint.TryParse(entry.Key, out _) ? entry.Value : null);
                    if (string.IsNullOrWhiteSpace(path) || !Path.IsPathRooted(path)) continue;
                    SafePaths.EnsureNoLinks(path);
                    if (Directory.Exists(path)) libraries.Add(Path.GetFullPath(path));
                    if (libraries.Count >= 64) break;
                }
            }
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or InvalidDataException or ArgumentException) { warnings.Add("Additional Steam libraries could not be fully inspected: " + ex.Message); }
        foreach (var library in libraries)
        {
            foreach (var (id, gameFolder) in new[] { (570, "dota"), (730, "csgo") })
            {
                try
                {
                    var manifest = SafePaths.Resolve(library, $"steamapps/appmanifest_{id}.acf");
                    if (!File.Exists(manifest)) continue;
                    var doc = KeyValues.Parse(GameRules.Decode(SteamAccountService.ReadBounded(manifest, 1024 * 1024)));
                    var install = doc.Find("AppState")?.Children?.Find("installdir")?.Value;
                    if (string.IsNullOrWhiteSpace(install)) continue;
                    var cfg = SafePaths.Resolve(library, $"steamapps/common/{install}/game/{gameFolder}/cfg");
                    if (Directory.Exists(cfg)) result.Add(cfg);
                }
                catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or InvalidDataException or ArgumentException) { warnings.Add("A shared game config directory could not be inspected: " + ex.Message); }
            }
        }
        // These directories are intentionally reported separately and never merged into an account profile.
        return result.Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
    }
}
