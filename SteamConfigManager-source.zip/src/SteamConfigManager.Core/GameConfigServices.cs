using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace SteamConfigManager.Core;

public sealed record ConfigRule(ConfigCategory Category, bool HardwareSpecific = false, bool SupportsPartial = false, string? Warning = null);

public static partial class GameRules
{
    public const int MaxFileBytes = 16 * 1024 * 1024;
    private const string WholeWarning = "Whole-file transfer: this format combines settings and cannot be safely split into categories.";
    private static readonly UTF8Encoding Utf8Strict = new(false, true);

    public static ConfigRule? Describe(GameId game, string relativePath)
    {
        var p = relativePath.Replace('\\', '/').ToLowerInvariant();
        if (p.StartsWith('/') || p.Split('/').Any(s => s is ".." or "." or "") || p.Contains(':')) return null;
        if (game == GameId.Cs2)
        {
            if (!p.StartsWith("local/cfg/", StringComparison.Ordinal) || p[10..].Contains('/')) return null;
            var name = p[10..];
            if (CsKeysPattern().IsMatch(name)) return new(ConfigCategory.Keybinds, SupportsPartial: true);
            if (CsConvarsPattern().IsMatch(name)) return new(ConfigCategory.Gameplay, SupportsPartial: true, Warning: "Only recognized selected settings are merged. Unknown and device settings remain unchanged.");
            if (name is "cs2_video.txt" or "cs2_machine_convars.vcfg") return new(ConfigCategory.Video, true, Warning: "Hardware and device settings require explicit consent and are copied as a whole file.");
            if (name is "autoexec.cfg" or "config.cfg") return new(ConfigCategory.Other, true, Warning: "Command scripts may contain hardware settings or executable console commands. Whole-file transfer requires explicit consent.");
            return null;
        }
        if (game != GameId.Dota2) return null;
        if (p is "remote/user_keys.vcfg" || DotaSlotKeysPattern().IsMatch(p)) return new(ConfigCategory.Keybinds, Warning: WholeWarning);
        // Dota convars contain mixed graphics/device settings: require the same explicit hardware opt-in.
        if (p is "remote/user_convars.vcfg" or "remote/user.vcfg" || DotaSlotConvarsPattern().IsMatch(p)) return new(ConfigCategory.Gameplay, true, Warning: WholeWarning + " May contain hardware-dependent settings; explicit consent is required.");
        if (p == "remote/cfg/dotakeys_personal.lst") return new(ConfigCategory.HeroSettings, Warning: "Combined hero-specific settings and keybinds: select this entire file explicitly to transfer it.");
        if (p == "remote/cfg/hero_grid_config.json") return new(ConfigCategory.HeroGrids);
        if (p is "remote/cfg/herobuilds.cfg" or "remote/cfg/hero_facet_config.cfg") return new(ConfigCategory.HeroSettings, Warning: WholeWarning);
        if (p == "remote/scripts/control_groups.txt") return new(ConfigCategory.HeroSettings, Warning: WholeWarning);
        if (DotaRootGuidePattern().IsMatch(p)) return new(ConfigCategory.ItemBuilds);
        if ((p.StartsWith("remote/itembuilds/") || p.StartsWith("remote/guides/")) && p.Count(c => c == '/') <= 4 && Path.GetExtension(p) is ".txt" or ".build") return new(ConfigCategory.ItemBuilds);
        if (p is "remote/cfg/config.cfg" or "remote/cfg/autoexec.cfg") return new(ConfigCategory.Other, true, Warning: "Whole console script; may contain hardware-specific commands. Explicit consent is required.");
        if (p is "local/cfg/video.txt" or "remote/cfg/video.txt" or "local/cfg/machine_convars.vcfg") return new(ConfigCategory.Video, true);
        return null;
    }

    public static bool IsAllowed(GameId game, string relativePath) => Describe(game, relativePath) is not null;

    public static IReadOnlyList<ConfigCategory> AvailableCategories(GameId game, string path, byte[] content)
    {
        var rule = Describe(game, path);
        if (rule is null) return [];
        if (game == GameId.Cs2 && IsUserConvars(path))
        {
            try { return Convars(KeyValues.Parse(Decode(content))).Entries.Where(e => e.Children is null).Select(e => CategoryForConvar(e.Key)).Where(c => c.HasValue).Select(c => c!.Value).Distinct().ToArray(); }
            catch (InvalidDataException) { return []; }
        }
        if (game == GameId.Dota2 && path.EndsWith("dotakeys_personal.lst", StringComparison.OrdinalIgnoreCase)) return [ConfigCategory.Keybinds, ConfigCategory.HeroSettings];
        return [rule.Category];
    }

    public static ConfigCategory? CategoryForConvar(string key)
    {
        // $2 (and other slot suffixes) are retained exactly during a merge.
        var name = SlotSuffixPattern().Replace(key.ToLowerInvariant(), "");
        if (name.StartsWith("cl_crosshair", StringComparison.Ordinal) || name.StartsWith("cl_grenadecrosshair", StringComparison.Ordinal) || name is "crosshair" or "cl_fixedcrosshairgap") return ConfigCategory.Crosshair;
        if (name is "sensitivity" or "zoom_sensitivity_ratio" or "zoom_sensitivity_ratio_mouse" or "m_yaw" or "m_pitch" or "m_customaccel" or "m_customaccel_exponent" or "m_customaccel_max" or "m_customaccel_scale") return ConfigCategory.Sensitivity;
        if (name.StartsWith("viewmodel_", StringComparison.Ordinal) || name is "cl_prefer_lefthanded" or "cl_righthand") return ConfigCategory.Viewmodel;
        if (name.StartsWith("cl_radar_", StringComparison.Ordinal) || name.StartsWith("cl_hud_", StringComparison.Ordinal) || name is "hud_scaling" or "hud_showtargetid" or "cl_showloadout" or "cl_show_observer_crosshair" or "cl_teamid_overhead_mode" or "cl_teammate_colors_show") return ConfigCategory.RadarHud;
        if (name is "volume" or "snd_menumusic_volume" or "snd_roundstart_volume" or "snd_roundend_volume" or "snd_mapobjective_volume" or "snd_tensecondwarning_volume" or "snd_deathcamera_volume" or "snd_mvp_volume" or "snd_mute_mvp_music_live_players" or "snd_mute_losefocus" or "snd_voipvolume" or "voice_modenable" or "voice_enable" or "snd_mute_all_but_friends_and_party") return ConfigCategory.Audio;
        if (name.StartsWith("cl_buywheel_", StringComparison.Ordinal) || name.StartsWith("cl_buymenu_", StringComparison.Ordinal) || name is "cl_use_opens_buy_menu" or "cl_autohelp" or "cl_showhelp" or "cl_autowepswitch" or "cl_sniper_auto_rezoom" or "cl_sniper_delay_unscope" or "cl_debounce_zoom" or "cl_silencer_mode" or "cl_player_ping_mute" or "cl_teamcounter_playercount_instead_of_avatars" or "cl_color" or "cl_dm_buyrandomweapons") return ConfigCategory.Gameplay;
        return null;
    }

    public static byte[]? Merge(GameId game, string relativePath, byte[] source, byte[]? target, TransferSelection selection)
    {
        var rule = Describe(game, relativePath) ?? throw new InvalidDataException("Unsupported game configuration path: " + relativePath);
        bool whole = selection.WholeFiles.Contains(relativePath) || selection.WholeFiles.Any(p => p.Equals(relativePath, StringComparison.OrdinalIgnoreCase));
        if (rule.HardwareSpecific && !selection.AllowHardware) return null;
        // Source 2 VBKV is validated structurally but never split or rewritten. Its exact bytes require an explicit file choice.
        if(game==GameId.Dota2 && source.AsSpan().StartsWith("VBKV"u8))return whole?source.ToArray():null;
        if (game == GameId.Cs2 && IsUserConvars(relativePath))
        {
            var sourceDoc = KeyValues.Parse(Decode(source));
            var sourceConvars = Convars(sourceDoc);
            _ = sourceDoc.FlattenLeaves();
            if (whole && selection.AllowHardware) return source.ToArray();
            // Never copy unknown/device values under a generic whole-file selection without explicit consent.
            var selected = sourceConvars.Entries.Where(e => e.Children is null && CategoryForConvar(e.Key) is { } c && (whole || selection.Categories.Contains(c))).ToArray();
            if (selected.Length == 0) return null;
            KeyValuesDocument result;
            if (target is null)
            {
                result = new KeyValuesDocument();
                var config = new KeyValuesDocument();
                config.Entries.Add(new("convars", children: new()));
                result.Entries.Add(new("config", children: config));
            }
            else result = KeyValues.Parse(Decode(target));
            _ = result.FlattenLeaves();
            var targetConvars = Convars(result);
            bool changed = false;
            foreach (var item in selected)
            {
                var existing = targetConvars.Find(item.Key);
                if (existing?.Children is not null) throw new InvalidDataException("A target setting has an unexpected nested structure: " + item.Key);
                if (existing is null) { targetConvars.Entries.Add(item.Clone()); changed = true; }
                else if (!string.Equals(existing.Value, item.Value, StringComparison.Ordinal)) { existing.Value = item.Value; changed = true; }
            }
            if (!changed && target is not null) return target.ToArray();
            return Encoding.UTF8.GetBytes(result.ToString());
        }
        if (game == GameId.Cs2 && CsKeysPattern().IsMatch(Path.GetFileName(relativePath.Replace('\\', '/')).ToLowerInvariant()))
        {
            if (!whole && !selection.Categories.Contains(ConfigCategory.Keybinds)) return null;
            var sourceDoc = KeyValues.Parse(Decode(source));
            _ = sourceDoc.FlattenLeaves();
            var sourceBindings = sourceDoc.Find("config")?.Children?.Find("bindings")?.Children ?? throw new InvalidDataException("Expected a bindings object in the CS2 keybind file.");
            if (whole || target is null) return source.ToArray();
            var targetDoc = KeyValues.Parse(Decode(target));
            _ = targetDoc.FlattenLeaves();
            var targetConfig = targetDoc.Find("config")?.Children ?? throw new InvalidDataException("Expected a config object in the target keybind file.");
            var bindings = targetConfig.Find("bindings");
            if (bindings?.Children is { } oldBindings)
            {
                var oldValues = oldBindings.FlattenLeaves();
                var newValues = sourceBindings.FlattenLeaves();
                if (oldValues.Count == newValues.Count && newValues.All(e => oldValues.TryGetValue(e.Key, out var value) && value == e.Value)) return target.ToArray();
            }
            if (bindings is null) targetConfig.Entries.Add(new("bindings", children: sourceBindings.Clone()));
            else { bindings.Value = null; bindings.Children = sourceBindings.Clone(); }
            return Encoding.UTF8.GetBytes(targetDoc.ToString());
        }
        if (!whole && !selection.Categories.Contains(rule.Category)) return null;
        if (game == GameId.Dota2 && relativePath.EndsWith("dotakeys_personal.lst", StringComparison.OrdinalIgnoreCase) && !whole) return null;
        // Keybind files define an entire binding map. A category selection replaces that complete map.
        // Unfamiliar formats are never partially edited.
        return source.ToArray();
    }

    internal static bool IsUserConvars(string path) => Path.GetFileName(path.Replace('\\', '/')).StartsWith("cs2_user_convars_", StringComparison.OrdinalIgnoreCase);
    internal static KeyValuesDocument Convars(KeyValuesDocument doc)
    {
        var config = doc.Find("config")?.Children ?? throw new InvalidDataException("Expected a config object in the VCFG file.");
        return config.Find("convars")?.Children ?? throw new InvalidDataException("Expected a convars object in the VCFG file.");
    }
    public static string Decode(byte[] content)
    {
        if (content.Length == 0 || content.Length > MaxFileBytes) throw new InvalidDataException("Empty or oversized configuration file.");
        try
        {
            if (content.Length >= 2 && content[0] == 0xff && content[1] == 0xfe) return new UnicodeEncoding(false, true, true).GetString(content, 2, content.Length - 2);
            if (content.Length >= 2 && content[0] == 0xfe && content[1] == 0xff) return new UnicodeEncoding(true, true, true).GetString(content, 2, content.Length - 2);
            return Utf8Strict.GetString(content).TrimStart('\uFEFF');
        }
        catch (DecoderFallbackException ex) { throw new InvalidDataException("Unsupported text encoding; UTF-8 or UTF-16 is required for safe editing.", ex); }
    }

    [GeneratedRegex(@"^cs2_user_keys_\d+_slot\d+\.vcfg$", RegexOptions.CultureInvariant)] private static partial Regex CsKeysPattern();
    [GeneratedRegex(@"^cs2_user_convars_\d+_slot\d+\.vcfg$", RegexOptions.CultureInvariant)] private static partial Regex CsConvarsPattern();
    [GeneratedRegex(@"^(?:local/cfg|remote/cfg)/user_keys_\d+_slot\d+\.vcfg$", RegexOptions.CultureInvariant)] private static partial Regex DotaSlotKeysPattern();
    [GeneratedRegex(@"^(?:local/cfg|remote/cfg)/user(?:_convars)?_\d+_slot\d+\.vcfg$", RegexOptions.CultureInvariant)] private static partial Regex DotaSlotConvarsPattern();
    [GeneratedRegex(@"\$\d+$", RegexOptions.CultureInvariant)] private static partial Regex SlotSuffixPattern();
    [GeneratedRegex(@"^remote/guide_\d+\.build$", RegexOptions.CultureInvariant)] private static partial Regex DotaRootGuidePattern();
}

public abstract class GameConfigDiscoveryService(GameId game) : IGameConfigService
{
    public GameId Game { get; } = game;
    public Task<GameConfig> DiscoverAsync(string steamPath, string accountId, CancellationToken ct = default) => Task.Run(() => Discover(steamPath, accountId, ct), ct);
    private GameConfig Discover(string steamPath, string accountId, CancellationToken ct)
    {
        if (!uint.TryParse(accountId, out var numeric) || numeric == 0) throw new InvalidDataException("Invalid Steam AccountID.");
        var root = SafePaths.Resolve(steamPath, $"userdata/{accountId}/{(int)Game}");
        var files = new List<ConfigFile>();
        var warnings = new List<string>();
        if (!Directory.Exists(root)) return new(Game, accountId, root, files, HealthStatus.Warning, "No local configuration was found. This account can still receive a configuration.");
        var pending = new Stack<(string Path, int Depth)>();
        pending.Push((root, 0));
        int inspected = 0;
        while (pending.TryPop(out var directory))
        {
            ct.ThrowIfCancellationRequested();
            if (directory.Depth > 5) continue;
            try
            {
                SafePaths.EnsureNoLinks(directory.Path);
                foreach (var entry in Directory.EnumerateFileSystemEntries(directory.Path))
                {
                    ct.ThrowIfCancellationRequested();
                    if (++inspected > 10_000) throw new InvalidDataException("The config scan reached its safe file-count limit.");
                    var attributes = File.GetAttributes(entry);
                    if ((attributes & FileAttributes.ReparsePoint) != 0) { warnings.Add("Skipped a symbolic link or junction."); continue; }
                    if ((attributes & FileAttributes.Directory) != 0)
                    {
                        var dirRelative = Path.GetRelativePath(root, entry).Replace('\\', '/').ToLowerInvariant();
                        if (dirRelative is "local" or "local/cfg" or "remote" or "remote/cfg" or "remote/itembuilds" or "remote/guides" or "remote/scripts" || dirRelative.StartsWith("remote/itembuilds/") || dirRelative.StartsWith("remote/guides/")) pending.Push((entry, directory.Depth + 1));
                        continue;
                    }
                    var relative = SafePaths.Relative(root, entry);
                    var rule = GameRules.Describe(Game, relative);
                    if (rule is null) continue;
                    var info = new FileInfo(entry);
                    string hash = "", issue = "";
                    try
                    {
                        if (info.Length > GameRules.MaxFileBytes) throw new InvalidDataException("The file is larger than the safe 16 MiB limit.");
                        using var stream = new FileStream(entry, FileMode.Open, FileAccess.Read, FileShare.Read);
                        var content = new byte[checked((int)stream.Length)];
                        stream.ReadExactly(content);
                        hash = Convert.ToHexString(SHA256.HashData(content));
                        ConfigValidationService.Validate(new(relative, content, hash), Game);
                    }
                    catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or InvalidDataException) { issue = ex.Message; }
                    files.Add(new(relative, rule.Category, rule.HardwareSpecific, rule.SupportsPartial, info.Length, info.LastWriteTimeUtc, hash, string.IsNullOrEmpty(issue) ? null : issue));
                }
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or InvalidDataException) { warnings.Add(ex.Message); }
        }
        bool invalid = files.Any(f => f.Issue is not null);
        var health = invalid ? HealthStatus.Warning : files.Count == 0 || warnings.Count > 0 ? HealthStatus.Warning : HealthStatus.Healthy;
        if (files.Count == 0) warnings.Add("No supported local files were found. Login and create settings in the game first, or import a supported profile.");
        if (files.Any(f => f.HardwareSpecific)) warnings.Add("Some files include hardware-dependent settings and require explicit consent.");
        return new(Game, accountId, root, files, health, warnings.Count > 0 ? string.Join(" ", warnings.Distinct()) : null);
    }
}

public sealed class DotaConfigService() : GameConfigDiscoveryService(GameId.Dota2);
public sealed class CS2ConfigService() : GameConfigDiscoveryService(GameId.Cs2);
