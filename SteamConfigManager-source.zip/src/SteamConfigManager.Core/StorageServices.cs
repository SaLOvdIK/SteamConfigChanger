using System.Security.Cryptography;
using System.Text.Json;

namespace SteamConfigManager.Core;

internal static class StorageIO
{
    internal static readonly JsonSerializerOptions Json = new() { WriteIndented = true, PropertyNameCaseInsensitive = false };
    internal const long MaxFileBytes = 16 * 1024 * 1024;
    internal const long MaxProfileBytes = 64 * 1024 * 1024;
    internal static string Hash(byte[] bytes) => Convert.ToHexString(SHA256.HashData(bytes));
    internal static string Id() => Guid.NewGuid().ToString("N");
    internal static void ValidateId(string id)
    {
        if (!Guid.TryParseExact(id, "N", out _)) throw new InvalidDataException("Invalid storage identifier.");
    }
    internal static string DirectoryPath(string root, string name)
    {
        var path = SafePaths.Resolve(Path.GetFullPath(root), name);
        SafePaths.EnsureNoLinks(path);
        Directory.CreateDirectory(path);
        SafePaths.EnsureNoLinks(path);
        return path;
    }
    internal static async Task<byte[]> ReadAsync(string path, CancellationToken ct = default, long maxBytes = MaxProfileBytes)
    {
        SafePaths.EnsureNoLinks(path);
        await using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 81920, true);
        if (stream.Length > maxBytes) throw new InvalidDataException("File exceeds the configured safety limit.");
        var data = new byte[checked((int)stream.Length)];
        await stream.ReadExactlyAsync(data, ct);
        return data;
    }
    internal static async Task WriteAtomicAsync(string path, byte[] bytes, CancellationToken ct = default)
    {
        SafePaths.EnsureNoLinks(path);
        var parent = Path.GetDirectoryName(Path.GetFullPath(path))!;
        Directory.CreateDirectory(parent);
        SafePaths.EnsureNoLinks(parent);
        var temporary = Path.Combine(parent, ".scm-" + Id() + ".tmp");
        try
        {
            await using (var stream = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None, 81920, FileOptions.Asynchronous | FileOptions.WriteThrough))
            {
                await stream.WriteAsync(bytes, ct);
                await stream.FlushAsync(ct);
                stream.Flush(true);
            }
            ct.ThrowIfCancellationRequested();
            SafePaths.EnsureNoLinks(path);
            if (File.Exists(path)) File.Replace(temporary, path, null);
            else File.Move(temporary, path);
        }
        finally { if (File.Exists(temporary)) File.Delete(temporary); }
    }
    internal static Task WriteJsonAsync<T>(string path, T value, CancellationToken ct = default) => WriteAtomicAsync(path, JsonSerializer.SerializeToUtf8Bytes(value, Json), ct);
    internal static async Task<T> ReadJsonAsync<T>(string path, CancellationToken ct = default) =>
        // Presets use JSON base64 for bytes, which expands a 64 MB profile by one third.
        JsonSerializer.Deserialize<T>(await ReadAsync(path, ct, MaxProfileBytes * 2), Json) ?? throw new InvalidDataException("Empty metadata.");
    internal static void ValidateProfile(ConfigProfile profile)
    {
        if (profile is null || !Enum.IsDefined(profile.Game) || profile.Files is null || profile.Files.Count is < 1 or > 2048) throw new InvalidDataException("A supported profile must contain 1–2048 configuration files.");
        long total = 0;
        var paths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var file in profile.Files)
        {
            if (file is null || file.RelativePath is null || file.Content is null) throw new InvalidDataException("A profile entry is missing its path or content.");
            if (!paths.Add(file.RelativePath.Replace('\\', '/'))) throw new InvalidDataException("Duplicate profile path.");
            if (file.Content.LongLength > MaxFileBytes || (total += file.Content.LongLength) > MaxProfileBytes) throw new InvalidDataException("Profile exceeds safety limits.");
            if (!string.Equals(Hash(file.Content), file.Hash, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Profile checksum mismatch: " + file.RelativePath);
            ConfigValidationService.Validate(file, profile.Game);
        }
    }
}

public sealed class ApplicationSettingsService
{
    public string Root { get; }
    public ApplicationSettingsService(string? root = null)
    {
        Root = Path.GetFullPath(root ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SteamConfigManager"));
        SafePaths.EnsureNoLinks(Root);
        Directory.CreateDirectory(Root);
    }
    public AppSettings Load()
    {
        var path = Path.Combine(Root, "settings.json");
        if (!File.Exists(path)) return new();
        // Public settings calls are synchronous; isolate async I/O from WPF's synchronization context.
        var settings = JsonSerializer.Deserialize<AppSettings>(Task.Run(() => StorageIO.ReadAsync(path)).GetAwaiter().GetResult(), StorageIO.Json) ?? new();
        settings.Language = settings.Language is "ru" ? "ru" : "en";
        settings.Effects = Math.Clamp(double.IsFinite(settings.Effects) ? settings.Effects : .65, 0, 1);
        settings.RetentionDays = Math.Clamp(settings.RetentionDays, 1, 3650);
        settings.Aliases ??= [];
        settings.Favorites ??= [];
        return settings;
    }
    public void Save(AppSettings settings) => Task.Run(() => StorageIO.WriteJsonAsync(Path.Combine(Root, "settings.json"), settings)).GetAwaiter().GetResult();
}

public sealed class PresetService
{
    private readonly string _directory;
    public PresetService(string root) => _directory = StorageIO.DirectoryPath(root, "presets");
    public async Task<IReadOnlyList<PresetRecord>> ListAsync(CancellationToken ct = default)
    {
        var records = new List<PresetRecord>();
        foreach (var path in Directory.EnumerateFiles(_directory, "*.json"))
        {
            var record = await StorageIO.ReadJsonAsync<PresetRecord>(path, ct);
            StorageIO.ValidateId(record.Id);
            if (Path.GetFileNameWithoutExtension(path) != record.Id) throw new InvalidDataException("Preset metadata identifier mismatch.");
            StorageIO.ValidateProfile(record.Profile);
            records.Add(record);
        }
        return records.OrderByDescending(x => x.CreatedUtc).ToArray();
    }
    public async Task<PresetRecord> SaveAsync(string name, ConfigProfile profile, CancellationToken ct = default)
    {
        ValidateName(name);
        StorageIO.ValidateProfile(profile);
        var record = new PresetRecord(StorageIO.Id(), name.Trim(), profile, DateTime.UtcNow);
        await StorageIO.WriteJsonAsync(Path.Combine(_directory, record.Id + ".json"), record, ct);
        return record;
    }
    public async Task RenameAsync(string id, string name, CancellationToken ct = default)
    {
        StorageIO.ValidateId(id); ValidateName(name);
        var path = Path.Combine(_directory, id + ".json");
        var record = await StorageIO.ReadJsonAsync<PresetRecord>(path, ct);
        if (record.Id != id) throw new InvalidDataException("Preset identifier mismatch.");
        await StorageIO.WriteJsonAsync(path, record with { Name = name.Trim() }, ct);
    }
    public Task DeleteAsync(string id)
    {
        StorageIO.ValidateId(id);
        var path = Path.Combine(_directory, id + ".json");
        SafePaths.EnsureNoLinks(path); File.Delete(path);
        return Task.CompletedTask;
    }
    private static void ValidateName(string name)
    {
        if (string.IsNullOrWhiteSpace(name) || name.Trim().Length > 120 || name.Any(char.IsControl)) throw new ArgumentException("Use a preset name of 1–120 characters.");
    }
}

public sealed class OperationHistoryService
{
    private readonly string _directory;
    public OperationHistoryService(string root) => _directory = StorageIO.DirectoryPath(root, "history");
    public async Task<IReadOnlyList<OperationRecord>> ListAsync(CancellationToken ct = default)
    {
        var records = new List<OperationRecord>();
        foreach (var path in Directory.EnumerateFiles(_directory, "*.json")) records.Add(await StorageIO.ReadJsonAsync<OperationRecord>(path, ct));
        return records.OrderByDescending(x => x.TimeUtc).ToArray();
    }
    public Task AddAsync(OperationRecord record, CancellationToken ct = default)
    {
        StorageIO.ValidateId(record.Id);
        return StorageIO.WriteJsonAsync(Path.Combine(_directory, record.Id + ".json"), record, ct);
    }
}

public sealed class BackupService
{
    private readonly string _directory;
    public string Root => _directory;
    public BackupService(string root) => _directory = StorageIO.DirectoryPath(root, "backups");
    public async Task<IReadOnlyList<BackupRecord>> ListAsync(CancellationToken ct = default)
    {
        var records = new List<BackupRecord>();
        foreach (var path in Directory.EnumerateDirectories(_directory))
        {
            SafePaths.EnsureNoLinks(path);
            var manifest = Path.Combine(path, "backup.json");
            if (File.Exists(manifest)) records.Add(await LoadAsync(Path.GetFileName(path), ct));
        }
        return records.OrderByDescending(x => x.CreatedUtc).ToArray();
    }
    internal async Task<BackupRecord> LoadAsync(string id, CancellationToken ct = default)
    {
        StorageIO.ValidateId(id);
        var record = await StorageIO.ReadJsonAsync<BackupRecord>(Path.Combine(_directory, id, "backup.json"), ct);
        if (record.Id != id || record.Files is null || record.Files.Count > 2048 || record.Files.Any(f => f is null || f.RelativePath is null) || record.Files.Select(f => f.RelativePath.Replace('\\','/')).Distinct(StringComparer.OrdinalIgnoreCase).Count() != record.Files.Count)
            throw new InvalidDataException("Invalid backup metadata.");
        if (record.State is not ("Complete" or "Pending" or "RecoveryRequired" or "Recovered" or "RolledBack")) throw new InvalidDataException("Unrecognized backup transaction state.");
        ConfigTransferService.ValidateTarget(record.Game, record.AccountId, record.TargetRoot);
        foreach (var file in record.Files)
        {
            if (!GameRules.IsAllowed(record.Game, file.RelativePath)) throw new InvalidDataException("Unrecognized backup path.");
            SafePaths.Resolve(record.TargetRoot, file.RelativePath);
            if (file.Existed != (file.Hash is not null) || file.Hash is { } originalHash && !IsHash(originalHash) || file.AppliedHash is { } appliedHash && !IsHash(appliedHash))
                throw new InvalidDataException("Missing or invalid backup checksum.");
        }
        return record;
    }
    internal async Task<BackupRecord> CreateAsync(TransferPlan plan, string reason, CancellationToken ct)
    {
        var record = new BackupRecord(StorageIO.Id(), plan.Target.Game, plan.Target.AccountId, plan.Target.RootPath, DateTime.UtcNow,
            plan.Changes.Select(c => new BackupFile(c.RelativePath, c.ExpectedHash != null, c.ExpectedHash, string.IsNullOrEmpty(c.NewHash) ? null : c.NewHash)).ToArray(), reason, "Preparing");
        var directory = StorageIO.DirectoryPath(_directory, record.Id);
        foreach (var file in record.Files.Where(f => f.Existed))
        {
            var original = await StorageIO.ReadAsync(SafePaths.Resolve(record.TargetRoot, file.RelativePath), ct, StorageIO.MaxFileBytes);
            if (!string.Equals(StorageIO.Hash(original), file.Hash, StringComparison.OrdinalIgnoreCase)) throw new IOException("Target changed during backup. Refresh the preview.");
            var backupPath = SafePaths.Resolve(StorageIO.DirectoryPath(directory, "files"), file.RelativePath);
            await StorageIO.WriteAtomicAsync(backupPath, original, ct);
            if (!string.Equals(StorageIO.Hash(await StorageIO.ReadAsync(backupPath, ct)), file.Hash, StringComparison.OrdinalIgnoreCase))
                throw new IOException("Backup verification failed before writing target configuration.");
        }
        record = record with { State = "Pending" };
        await SaveAsync(record, ct);
        return record;
    }
    internal Task SaveAsync(BackupRecord record, CancellationToken ct = default) => StorageIO.WriteJsonAsync(Path.Combine(_directory, record.Id, "backup.json"), record, ct);
    internal async Task<byte[]> ReadOriginalAsync(BackupRecord record, BackupFile file, CancellationToken ct = default)
    {
        if (!file.Existed) throw new InvalidOperationException("File did not exist in this backup.");
        var content = await StorageIO.ReadAsync(SafePaths.Resolve(Path.Combine(_directory, record.Id, "files"), file.RelativePath), ct, StorageIO.MaxFileBytes);
        if (!string.Equals(StorageIO.Hash(content), file.Hash, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Backup checksum mismatch: " + file.RelativePath);
        return content;
    }
    public async Task<ConfigProfile> ReadProfileAsync(string id, CancellationToken ct = default)
    {
        var record = await LoadAsync(id, ct);
        var files = new List<ProfileFile>();
        foreach (var file in record.Files.Where(f => f.Existed)) files.Add(new(file.RelativePath, await ReadOriginalAsync(record, file, ct), file.Hash!));
        return new(record.Game, record.AccountId, "Backup " + record.CreatedUtc.ToLocalTime().ToString("g"), files, record.CreatedUtc);
    }
    public async Task ExportAsync(string id, string path, CancellationToken ct = default)
    {
        // A backup is a recovery artifact, including files that were absent and exact possibly malformed originals.
        // It deliberately is not imported as a transfer profile or trusted for an arbitrary absolute target path.
        var record = await LoadAsync(id, ct);
        var originals = new List<ProfileFile>();
        long total = 0;
        foreach (var file in record.Files.Where(f => f.Existed))
        {
            var content = await ReadOriginalAsync(record, file, ct);
            if ((total += content.LongLength) > StorageIO.MaxProfileBytes) throw new InvalidDataException("Backup exceeds export size limits.");
            originals.Add(new(file.RelativePath, content, file.Hash!));
        }
        using var output = new MemoryStream();
        using (var archive = new System.IO.Compression.ZipArchive(output, System.IO.Compression.ZipArchiveMode.Create, true))
        {
            var manifest = archive.CreateEntry("backup.json", System.IO.Compression.CompressionLevel.Optimal);
            await using (var stream = manifest.Open()) await JsonSerializer.SerializeAsync(stream, record, StorageIO.Json, ct);
            foreach (var original in originals)
            {
                var entry = archive.CreateEntry("files/" + original.RelativePath.Replace('\\', '/'), System.IO.Compression.CompressionLevel.Optimal);
                await using var stream = entry.Open();
                await stream.WriteAsync(original.Content, ct);
            }
        }
        await StorageIO.WriteAtomicAsync(path, output.ToArray(), ct);
    }
    private static bool IsHash(string hash) => hash.Length == 64 && hash.All(Uri.IsHexDigit);
    public async Task<int> ApplyRetentionAsync(AppSettings settings, CancellationToken ct = default)
    {
        if (!settings.RetentionEnabled) return 0;
        if (settings.RetentionDays is < 1 or > 3650) throw new ArgumentOutOfRangeException(nameof(settings), "Retention must be between 1 and 3650 days.");
        var cutoff = DateTime.UtcNow.AddDays(-settings.RetentionDays);
        var eligible = (await ListAsync(ct)).Where(b => b.CreatedUtc < cutoff && b.State is "Complete" or "RolledBack" or "Recovered").ToArray();
        foreach (var backup in eligible) { ct.ThrowIfCancellationRequested(); await DeleteAsync(backup.Id); }
        return eligible.Length;
    }
    public async Task DeleteAsync(string id)
    {
        var record = await LoadAsync(id);
        if (record.State is "Pending" or "RecoveryRequired") throw new IOException("This backup is required to recover an interrupted operation.");
        var path = Path.GetFullPath(Path.Combine(_directory, id));
        if (!path.StartsWith(Path.GetFullPath(_directory).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)) throw new IOException("Unsafe backup path.");
        // Walk without following a junction, then remove only the verified subtree.
        var pending = new Stack<string>(); pending.Push(path);
        while (pending.TryPop(out var directory))
            foreach (var entry in Directory.EnumerateFileSystemEntries(directory))
            {
                SafePaths.EnsureNoLinks(entry);
                if (Directory.Exists(entry)) pending.Push(entry);
            }
        SafePaths.EnsureNoLinks(path);
        Directory.Delete(path, true);
    }
}
