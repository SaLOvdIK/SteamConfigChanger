using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("SteamConfigManager.Tests")]
