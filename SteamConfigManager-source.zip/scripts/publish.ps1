param([ValidateSet('win-x64', 'win-arm64')][string]$Runtime = 'win-x64', [switch]$Folder)
. (Join-Path $PSScriptRoot 'common.ps1')
Push-Location -LiteralPath $ProjectRoot
try {
    $PublishRoot = [System.IO.Path]::GetFullPath((Join-Path $ProjectRoot ('artifacts\' + $Runtime + $(if ($Folder) { '-folder' } else { '' }))))
    $SingleFile = (-not $Folder).ToString().ToLowerInvariant()
    & $Dotnet publish 'src\SteamConfigManager.App\SteamConfigManager.App.csproj' --configuration Release --runtime $Runtime --self-contained true --output $PublishRoot "-p:PublishSingleFile=$SingleFile" '-p:IncludeNativeLibrariesForSelfExtract=true' '-p:EnableCompressionInSingleFile=true' '-p:PublishTrimmed=false' '-p:DebugType=none' '-p:DebugSymbols=false'
    if ($LASTEXITCODE -ne 0) { throw 'Publication failed.' }
    $PublishedExe = Join-Path $PublishRoot 'SteamConfigManager.exe'
    if (-not (Test-Path -LiteralPath $PublishedExe)) { throw 'Published executable was not found.' }
    Get-Item -LiteralPath $PublishedExe | Select-Object FullName, Length
} finally { Pop-Location }
