$ErrorActionPreference = 'Stop'
$ProjectRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$LocalDotnet = Join-Path $ProjectRoot '.tools\dotnet\dotnet.exe'
if (Test-Path -LiteralPath $LocalDotnet) {
    $Dotnet = $LocalDotnet
    $env:DOTNET_ROOT = Split-Path -Parent $LocalDotnet
    $env:DOTNET_ROOT_X64 = $env:DOTNET_ROOT
} else {
    $DotnetCommand = Get-Command dotnet -ErrorAction SilentlyContinue
    if ($null -eq $DotnetCommand) { throw 'Install .NET 10 SDK, or place it in .tools\dotnet.' }
    $Dotnet = $DotnetCommand.Source
}
$env:DOTNET_CLI_TELEMETRY_OPTOUT = '1'
$env:DOTNET_NOLOGO = '1'
$env:DOTNET_CLI_HOME = Join-Path $ProjectRoot '.tools\cli'
$env:NUGET_PACKAGES = Join-Path $ProjectRoot '.tools\packages'
$SdkVersion = & $Dotnet --version
if ($LASTEXITCODE -ne 0 -or $SdkVersion -notmatch '^10\.') { throw "A .NET 10 SDK is required; selected SDK: $SdkVersion" }
