param([ValidateSet('Debug', 'Release')][string]$Configuration = 'Release')
. (Join-Path $PSScriptRoot 'common.ps1')
Push-Location -LiteralPath $ProjectRoot
try {
    # The dependency-free test runner returns a nonzero exit code on any failure.
    & $Dotnet run --project 'tests\SteamConfigManager.Tests\SteamConfigManager.Tests.csproj' --configuration $Configuration
    if ($LASTEXITCODE -ne 0) { throw 'Functional and safety verification failed.' }
    & $Dotnet run --project 'tests\SteamConfigManager.UiTests\SteamConfigManager.UiTests.csproj' --configuration $Configuration
    if ($LASTEXITCODE -ne 0) { throw 'WPF command and persistence verification failed.' }
} finally { Pop-Location }
