param([ValidateSet('Debug', 'Release')][string]$Configuration = 'Release')
. (Join-Path $PSScriptRoot 'common.ps1')
Push-Location -LiteralPath $ProjectRoot
try {
    & $Dotnet build 'SteamConfigManager.slnx' --configuration $Configuration
    if ($LASTEXITCODE -ne 0) { throw 'Build failed.' }
} finally { Pop-Location }
