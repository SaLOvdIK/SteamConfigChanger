param([string]$Version = '', [switch]$Rebuild)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$PackageRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
if ($Rebuild) { & (Join-Path $PSScriptRoot 'publish.ps1') -Runtime win-x64 }
[xml]$AppProject = Get-Content -LiteralPath (Join-Path $PackageRoot 'src\SteamConfigManager.App\SteamConfigManager.App.csproj') -Raw
if ([string]::IsNullOrWhiteSpace($Version)) { $Version = [string]$AppProject.Project.PropertyGroup.Version }
if ($Version -notmatch '^\d+\.\d+\.\d+(?:-[A-Za-z0-9.-]+)?$') { throw 'Use a version such as 1.0.0.' }
if ($Version -ne [string]$AppProject.Project.PropertyGroup.Version) { throw 'Package version must match the application project version.' }
$PublishedExe = Join-Path $PackageRoot 'artifacts\win-x64\SteamConfigManager.exe'
if (-not (Test-Path -LiteralPath $PublishedExe -PathType Leaf)) { throw 'Run scripts\publish.ps1 first, or package.ps1 -Rebuild.' }
$ExeInfo = [Diagnostics.FileVersionInfo]::GetVersionInfo($PublishedExe)
if ($ExeInfo.ProductVersion.Split('+')[0] -ne $Version) { throw 'Published executable version does not match the project. Rebuild it first.' }
$ReleaseRoot = Join-Path $PackageRoot ('artifacts\releases\v' + $Version)
[void][IO.Directory]::CreateDirectory($ReleaseRoot)
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$Utf8 = New-Object Text.UTF8Encoding($false)

function Assert-RegularFile([string]$Path) {
    $FullPath = [IO.Path]::GetFullPath($Path)
    if (-not $FullPath.StartsWith($PackageRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Package file is outside the project.' }
    $Current = Get-Item -LiteralPath $FullPath -Force
    if ($Current.PSIsContainer) { throw 'Expected a regular file.' }
    if (($Current.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Do not package symbolic links.' }
    $Current = $Current.Directory
    while ($null -ne $Current -and $Current.FullName.Length -ge $PackageRoot.Length) {
        if (($Current.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Do not package symbolic links or junctions.' }
        $Current = $Current.Parent
    }
}

function Publish-File([string]$Temporary, [string]$Destination) {
    if (Test-Path -LiteralPath $Destination) { [IO.File]::Replace($Temporary, $Destination, [NullString]::Value) }
    else { [IO.File]::Move($Temporary, $Destination) }
}

function Write-Archive([string]$Name, [Collections.IDictionary]$Entries) {
    $Destination = Join-Path $ReleaseRoot $Name
    $Temporary = Join-Path $ReleaseRoot ('.' + [Guid]::NewGuid().ToString('N') + '.zip.tmp')
    try {
    $Archive = [IO.Compression.ZipFile]::Open($Temporary, [IO.Compression.ZipArchiveMode]::Create)
    try {
        foreach ($EntryName in ($Entries.Keys | Sort-Object)) {
            if ($EntryName.StartsWith('/') -or $EntryName.Contains('\') -or $EntryName -match '(^|/)\.\.(/|$)') { throw 'Unsafe ZIP entry.' }
            $Entry = $Archive.CreateEntry($EntryName, [IO.Compression.CompressionLevel]::Optimal)
            $Stream = $Entry.Open()
            try {
                $Value = $Entries[$EntryName]
                if ($Value -is [byte[]]) { $Stream.Write($Value, 0, $Value.Length) }
                else {
                    Assert-RegularFile $Value
                    $InputFile = [IO.File]::OpenRead($Value)
                    try { $InputFile.CopyTo($Stream) } finally { $InputFile.Dispose() }
                }
            } finally { $Stream.Dispose() }
        }
    } finally { $Archive.Dispose() }
    $Check = [IO.Compression.ZipFile]::OpenRead($Temporary)
    try {
        if ($Check.Entries.Count -ne $Entries.Count) { throw 'Archive entry count verification failed.' }
        foreach ($Entry in $Check.Entries) {
            $Expected = $Entries[$Entry.FullName]
            $ExpectedHash = if ($Expected -is [byte[]]) {
                $HashAlgorithm = [Security.Cryptography.SHA256]::Create()
                try { [BitConverter]::ToString($HashAlgorithm.ComputeHash($Expected)).Replace('-', '') } finally { $HashAlgorithm.Dispose() }
            } else { (Get-FileHash -LiteralPath $Expected -Algorithm SHA256).Hash }
            $HashAlgorithm = [Security.Cryptography.SHA256]::Create()
            $Stream = $Entry.Open()
            try { $ActualHash = [BitConverter]::ToString($HashAlgorithm.ComputeHash($Stream)).Replace('-', '') }
            finally { $Stream.Dispose(); $HashAlgorithm.Dispose() }
            if ($ExpectedHash -ne $ActualHash) { throw ('Archive verification failed: ' + $Entry.FullName) }
        }
    } finally { $Check.Dispose() }
    Publish-File $Temporary $Destination
    return $Destination
    } finally {
        if ([IO.File]::Exists($Temporary)) { [IO.File]::Delete($Temporary) }
    }
}

$SourceEntries = @{}
foreach ($Name in @('.gitignore', 'Directory.Build.props', 'SteamConfigManager.slnx', 'README.md', 'THIRD-PARTY-NOTICES.txt')) {
    $Path = Join-Path $PackageRoot $Name
    Assert-RegularFile $Path
    $SourceEntries.Add($Name, $Path)
}
$AllowedExtensions = @{
    src = @('.cs', '.csproj', '.xaml', '.manifest', '.ico')
    tests = @('.cs', '.csproj')
    scripts = @('.ps1')
    docs = @('.md')
    licenses = @('.txt', '.md')
}
foreach ($Directory in @('src', 'tests', 'scripts', 'docs', 'licenses')) {
    $DirectoryPath = Join-Path $PackageRoot $Directory
    $Pending = New-Object 'Collections.Generic.Stack[string]'
    $Pending.Push($DirectoryPath)
    while ($Pending.Count -gt 0) {
        $Folder = $Pending.Pop()
        foreach ($Item in (Get-ChildItem -LiteralPath $Folder -Force)) {
            if (($Item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Unexpected link in source tree.' }
            if ($Item.PSIsContainer) {
                if ($Item.Name -notin @('bin', 'obj', '.git', '.vs', '.tools', 'artifacts', 'runtime', 'node_modules')) { $Pending.Push($Item.FullName) }
            } elseif ($Item.Extension.ToLowerInvariant() -in $AllowedExtensions[$Directory]) {
                $Relative = $Item.FullName.Substring($PackageRoot.Length + 1).Replace('\', '/')
                $SourceEntries.Add($Relative, $Item.FullName)
            }
        }
    }
}
$LicenseEntries = @($SourceEntries.Keys | Where-Object { $_.StartsWith('licenses/') })
if ($LicenseEntries.Count -lt 6) { throw 'Bundled component licenses are missing.' }

$ExeHash = (Get-FileHash -LiteralPath $PublishedExe -Algorithm SHA256).Hash
$ReleaseInfo = [ordered]@{
    Application = 'Steam Config Manager'
    Version = $Version
    Runtime = 'win-x64'
    SelfContained = $true
    Executable = 'SteamConfigManager.exe'
    SHA256 = $ExeHash
    PackagedUtc = [DateTime]::UtcNow.ToString('o')
} | ConvertTo-Json
$PortableEntries = @{
    'SteamConfigManager.exe' = $PublishedExe
    'INSTALL_RU.txt' = (Join-Path $PackageRoot 'docs\INSTALL_RU.md')
    'THIRD-PARTY-NOTICES.txt' = (Join-Path $PackageRoot 'THIRD-PARTY-NOTICES.txt')
    'release-info.json' = $Utf8.GetBytes($ReleaseInfo + "`r`n")
}
foreach ($Name in $LicenseEntries) { $PortableEntries.Add($Name, $SourceEntries[$Name]) }

$PortableArchive = Write-Archive 'SteamConfigManager-win-x64.zip' $PortableEntries
$SourceArchive = Write-Archive 'SteamConfigManager-source.zip' $SourceEntries
$ChecksumLines = foreach ($Path in @($PortableArchive, $SourceArchive)) {
    (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() + '  ' + [IO.Path]::GetFileName($Path)
}
[IO.File]::WriteAllText((Join-Path $ReleaseRoot 'SHA256SUMS.txt'), ($ChecksumLines -join "`r`n") + "`r`n", $Utf8)
foreach ($Path in @($PortableArchive, $SourceArchive)) {
    $File = Get-Item -LiteralPath $Path
    Write-Output ('{0} ({1:N2} MiB)' -f $File.FullName, ($File.Length / 1MB))
}
Write-Output ('Verified every archived file. SHA256SUMS.txt: ' + $ReleaseRoot)
