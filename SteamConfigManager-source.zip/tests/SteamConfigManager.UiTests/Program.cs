using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using CommunityToolkit.Mvvm.Input;
using SteamConfigManager.App;
using SteamConfigManager.Core;

internal static class Program
{
    private const string Convars = "local/cfg/cs2_user_convars_0_slot0.vcfg";
    private const string AdditionalSlot = "local/cfg/cs2_user_convars_0_slot1.vcfg";
    private const string Keys = "local/cfg/cs2_user_keys_0_slot0.vcfg";
    private const string Video = "local/cfg/cs2_video.txt";
    private static readonly string Root = Path.Combine(Path.GetFullPath(".ui-test-runtime"), Guid.NewGuid().ToString("N"));
    private static string Steam => Path.Combine(Root, "synthetic-steam");
    private static string Storage => Path.Combine(Root, "app-data");
    private static int _checks;

    [STAThread]
    private static int Main()
    {
        // A real STA dispatcher preserves exactly the synchronization context used by WPF commands.
        // No game, Steam process, window, native dialog or real Steam userdata is opened.
        var application = new Application { ShutdownMode = ShutdownMode.OnExplicitShutdown };
        SynchronizationContext.SetSynchronizationContext(new DispatcherSynchronizationContext(application.Dispatcher));
        var exitCode = 1;
        application.Dispatcher.BeginInvoke(new Action(async () =>
        {
            try
            {
                await RunAsync();
                Console.WriteLine($"PASS: {_checks} WPF/MVVM integration checks. Fixture: {Root}");
                exitCode = 0;
            }
            catch (Exception error) { Console.Error.WriteLine("FAIL: " + error); }
            finally { application.Shutdown(exitCode); }
        }));
        application.Run();
        return exitCode;
    }

    private static async Task RunAsync()
    {
        await SeedAsync();
        new ApplicationSettingsService(Storage).Save(new AppSettings { SteamPath = Steam, AutoScan = true, Animations = false });
        var vm = new MainViewModel(Storage);
        await vm.InitializeAsync();
        Check(Application.Current.Dispatcher.CheckAccess(), "Initialize returns to the WPF dispatcher");
        Check(!vm.IsBusy && vm.CanWork, "initialization releases the UI busy state");
        Equal(3, vm.SourceAccounts.Count, "three accounts discovered through the VM");
        Equal("101", vm.Source!.AccountId, "MostRecent source selected");
        Equal((SteamAccountService.IndividualPublicBase + 101).ToString(), vm.Source.SteamId64, "SteamID64 is mapped to userdata AccountID");
        Check(vm.Source.HasAvatar && vm.Source.Avatar is BitmapSource { IsFrozen: true },
            "account loads and freezes its genuine SteamID64-named local avatar cache image");
        Check(!vm.SourceAccounts.Single(a => a.AccountId == "202").HasAvatar,
            "malformed local avatar image safely falls back to initials");
        Check(!vm.SourceAccounts.Single(a => a.AccountId == "303").HasAvatar,
            "missing local avatar image safely falls back to initials");
        Check(vm.TargetAccounts.All(a => a.AccountId != vm.Source.AccountId), "source excluded from single target choices");
        Check(vm.BatchTargets.All(a => a.AccountId != vm.Source.AccountId), "source excluded from batch choices");
        Check(!Category(vm, ConfigCategory.Keybinds).Available && !Category(vm, ConfigCategory.HeroSettings).Available,
            "combined Dota .lst does not advertise separate keybind or hero transfers");
        Check(vm.ConfigFiles.Single(f => f.Path.EndsWith("dotakeys_personal.lst")).Enabled,
            "combined Dota file remains available through explicit whole-file selection");
        Check(Category(vm, ConfigCategory.HeroGrids).Available, "real Dota hero-grid JSON is recognized");

        vm.SelectGameCommand.Execute("730");
        Check(vm.IsCs && !vm.IsDota, "game selection updates the VM");
        vm.Source = vm.SourceAccounts.Single(a => a.AccountId == "101");
        vm.Target = vm.TargetAccounts.Single(a => a.AccountId == "202");
        Check(!Category(vm, ConfigCategory.Sensitivity).Available, "CS2 fields are unavailable until snapshot parsing");
        Check(!Category(vm, ConfigCategory.Video).Available && !vm.ConfigFiles.Single(f => f.Path == Video).Enabled,
            "video is unavailable without explicit hardware consent");

        var beforeComparison = await File.ReadAllBytesAsync(Config("202", Convars));
        await Execute(vm.CompareCommand);
        Check(vm.PanelOpen && vm.HasProfile, "Compare before Copy captures and inspects the source safely");
        Check(Category(vm, ConfigCategory.Sensitivity).Available,
            "Compare before Copy exposes detected categories instead of falsely calling them unavailable");
        Check(vm.PanelRows.Single(r => r.Title == vm.Text["Sensitivity"]).Detail.StartsWith(vm.Text["Changed"]),
            "pre-copy comparison reports actual sensitivity differences");
        var existingComparison = vm.PanelRows.Single(r => r.Title == Convars).Detail;
        Check(existingComparison.Contains(vm.Text["Changed"] + ": 3") && existingComparison.Contains(vm.Text["Added"] + ": 0") && existingComparison.Contains("unchanged: 2"),
            "comparison reports exactly three changed and two preserved existing convars");
        var slotComparison = vm.PanelRows.Single(r => r.Title == AdditionalSlot).Detail;
        Check(slotComparison.Contains(vm.Text["Changed"] + ": 0") && slotComparison.Contains(vm.Text["Added"] + ": 2"),
            "comparison counts the missing slot's two added parameters correctly");
        Check(vm.PanelRows.Any(r => r.Title.EndsWith("sensitivity") && r.Detail == "1.2 → 2.5"),
            "comparison lists actual old and new parameter values");
        Check(Enumerable.SequenceEqual(beforeComparison, await File.ReadAllBytesAsync(Config("202", Convars))),
            "comparison leaves target file bytes untouched");
        vm.ClosePanelCommand.Execute(null);

        await Execute(vm.CopyCommand);
        Check(vm.HasProfile && vm.CanUseProfile, "Copy captures a real profile");
        Check(Category(vm, ConfigCategory.Sensitivity).Available && Category(vm, ConfigCategory.Crosshair).Available,
            "parsed CS2 snapshot exposes detected sensitivity and crosshair fields");
        Check(Category(vm, ConfigCategory.Keybinds).Available, "parsed keybind VCFG is available");
        Check(!Category(vm, ConfigCategory.Viewmodel).Available, "absent fields are not advertised");
        vm.HardwareConsent = true;
        Check(Category(vm, ConfigCategory.Video).Available && vm.ConfigFiles.Single(f => f.Path == Video).Enabled,
            "explicit consent unlocks detected hardware files");
        vm.HardwareConsent = false;
        Check(!Category(vm, ConfigCategory.Video).Available && !Category(vm, ConfigCategory.Video).Selected,
            "revoking consent deselects hardware categories");
        SensitivityOnly(vm);

        var originalTarget = await File.ReadAllBytesAsync(Config("202", Convars));
        var originalKeys = await File.ReadAllBytesAsync(Config("202", Keys));
        var originalVideo = await File.ReadAllBytesAsync(Config("202", Video));
        await Execute(vm.ApplyCommand);
        Check(vm.PanelOpen && vm.PanelRows.Any(r => r.Title == Convars), "Apply opens an actual change preview");
        Check(Enumerable.SequenceEqual(originalTarget, await File.ReadAllBytesAsync(Config("202", Convars))),
            "preview does not write the target before confirmation");
        await Execute(vm.ConfirmPanelCommand);
        var merged = ReadConvars(Config("202", Convars));
        Equal("2.5", merged["sensitivity"], "confirmed apply changes selected sensitivity");
        Equal("2", merged["cl_crosshairsize"], "partial apply preserves target crosshair");
        Equal("0.4", merged["volume"], "partial apply preserves target audio");
        Equal("target-device", merged["snd_device_override"], "partial apply preserves target devices");
        Equal("keep-target", merged["unknown_option"], "partial apply preserves unknown target values");
        Check(Enumerable.SequenceEqual(originalKeys, await File.ReadAllBytesAsync(Config("202", Keys))), "unselected keybind file is byte-identical");
        Check(Enumerable.SequenceEqual(originalVideo, await File.ReadAllBytesAsync(Config("202", Video))), "unselected hardware file is byte-identical");
        Check(File.Exists(Config("202", AdditionalSlot)), "detected additional slot is transferred");
        Check(vm.Backups.Count == 1 && vm.History.Count == 1 && vm.History[0].CanUndo,
            "confirmed transfer persists backup, history and Undo availability");
        var firstBackup = (BackupRecord)vm.Backups[0].Raw;
        Check(firstBackup.Files.Any(f => f.RelativePath == AdditionalSlot && !f.Existed),
            "backup records that a slot file did not previously exist");
        vm.ClosePanelCommand.Execute(null);

        vm.UndoCommand.Execute(vm.History.Single());
        Check(vm.PanelOpen && originalTarget.Length > 0, "Undo requests explicit restore confirmation");
        await Execute(vm.ConfirmPanelCommand);
        Check(Enumerable.SequenceEqual(originalTarget, await File.ReadAllBytesAsync(Config("202", Convars))),
            "Undo restores exact original target bytes");
        Check(!File.Exists(Config("202", AdditionalSlot)), "Undo removes the newly introduced slot file");
        Check(vm.Backups.Count >= 2, "restoration creates its own recovery point");
        vm.ClosePanelCommand.Execute(null);

        await Execute(vm.CopyCommand);
        SensitivityOnly(vm);
        vm.SavePresetCommand.Execute(null);
        Check(vm.PanelOpen && vm.PanelHasInput, "Save Preset opens the inline name editor");
        vm.PanelInput = "Integration sensitivity preset";
        await Execute(vm.ConfirmPanelCommand);
        Equal(1, vm.Presets.Count, "preset appears in the VM library");
        Equal(1, (await new PresetService(Storage).ListAsync()).Count, "preset exists on disk");
        var preset = (PresetRecord)vm.Presets.Single().Raw;
        Check(preset.Profile.Files.All(f => f.RelativePath.Contains("cs2_user_convars_")),
            "saved preset contains only selected convar files");
        Check(preset.Profile.Files.All(f => !ReadConvars(Encoding.UTF8.GetString(f.Content)).ContainsKey("snd_device_override")),
            "saved partial preset excludes unselected device values");
        vm.RenamePresetCommand.Execute(vm.Presets.Single());
        vm.PanelInput = "Renamed sensitivity preset";
        await Execute(vm.ConfirmPanelCommand);
        Equal("Renamed sensitivity preset", vm.Presets.Single().Title, "preset rename refreshes persisted library metadata");
        vm.Source = vm.SourceAccounts.Single(a => a.AccountId == "202");
        Check(!vm.HasProfile, "changing source clears a stale clipboard snapshot");
        vm.LoadPresetCommand.Execute(vm.Presets.Single());
        Check(vm.HasProfile && vm.Source?.AccountId == "101" && vm.IsCs, "Load Preset restores its game and source metadata");

        vm.ManageAccountCommand.Execute(null);
        vm.PanelInput = "Main Local";
        vm.PanelFavorite = true;
        await Execute(vm.ConfirmPanelCommand);
        var storedSettings = new ApplicationSettingsService(Storage).Load();
        Equal("Main Local", storedSettings.Aliases["101"], "local alias is persisted");
        Check(storedSettings.Favorites.Contains("101") && vm.SourceAccounts.First().AccountId == "101",
            "favorite account is persisted and sorted first");
        Equal("ML", vm.Source!.Initials, "favorite marker is excluded from account initials");

        vm.Language = "ru";
        Equal("Библиотека", vm.Text["Library"], "Russian localization updates through VM");
        vm.SaveSettingsCommand.Execute(null);
        await WaitUntil(() => !vm.IsBusy);
        Equal("ru", new ApplicationSettingsService(Storage).Load().Language, "chosen language is persisted by Save Settings");
        vm.Language = "en";

        // Every selected recipient gets a separate plan, backup and independently recorded result.
        vm.LoadPresetCommand.Execute(vm.Presets.Single());
        SensitivityOnly(vm);
        foreach (var account in vm.BatchTargets) account.Selected = true;
        Equal(2, vm.BatchTargets.Count(a => a.Selected), "batch mode selects both non-source accounts");
        var historyBeforeBatch = vm.History.Count;
        var backupsBeforeBatch = vm.Backups.Count;
        await Execute(vm.ApplyCommand);
        Check(vm.PanelRows.Any(r => r.Title.Contains("Second")) && vm.PanelRows.Any(r => r.Title.Contains("Third")),
            "batch preview lists both recipients");
        await Execute(vm.ConfirmPanelCommand);
        Equal("2.5", ReadConvars(Config("202", Convars))["sensitivity"], "batch applies existing target");
        Equal("2.5", ReadConvars(Config("303", Convars))["sensitivity"], "batch creates missing target configuration");
        Equal(backupsBeforeBatch + 2, vm.Backups.Count, "batch creates a backup per recipient");
        Equal(historyBeforeBatch + 2, vm.History.Count, "batch records a result per recipient");
        Check(vm.PanelOpen && vm.PanelRows.Count == 2, "batch completion exposes individual outcomes");
        vm.ClosePanelCommand.Execute(null);

        await WriteAsync(Config("303", Convars), "\"config\" { \"convars\" { \"sensitivity\" \"1.1\" \"unknown_option\" \"third-retained\" } }");
        var lockedOriginal = await File.ReadAllBytesAsync(Config("202", Convars));
        vm.LoadPresetCommand.Execute(vm.Presets.Single());
        SensitivityOnly(vm);
        foreach (var account in vm.BatchTargets) account.Selected = true;
        var backupsBeforeFailure = vm.Backups.Count;
        await using (var locked = new FileStream(Config("202", Convars), FileMode.Open, FileAccess.ReadWrite, FileShare.None))
        {
            await Execute(vm.ApplyCommand);
            Check(vm.PanelOpen && vm.PanelRows.Any(r => r.Title.Contains("Second") && r.Detail.StartsWith(vm.Text["Error"])),
                "batch preview explains the locked recipient failure");
            await Execute(vm.ConfirmPanelCommand);
            Equal("2.5", ReadConvars(Config("303", Convars))["sensitivity"], "unlocked batch recipient succeeds when another target is locked");
            Equal("third-retained", ReadConvars(Config("303", Convars))["unknown_option"], "partial-failure batch preserves unrelated target values");
            Equal(backupsBeforeFailure + 1, vm.Backups.Count, "only writable batch recipient receives a new recovery point");
            Check(vm.PanelRows.Count == 2 && vm.PanelRows.Any(r => r.Title.Contains("Second") && r.Detail.StartsWith(vm.Text["Error"])),
                "completion retains a separate failed-target outcome");
        }
        Check(Enumerable.SequenceEqual(lockedOriginal, await File.ReadAllBytesAsync(Config("202", Convars))),
            "locked batch recipient remains byte-identical");
        vm.ClosePanelCommand.Execute(null);
        await Execute(vm.RescanCommand);

        var reopened = new MainViewModel(Storage);
        await reopened.InitializeAsync();
        Equal(1, reopened.Presets.Count, "presets survive application restart");
        Equal(vm.Backups.Count, reopened.Backups.Count, "backups survive application restart");
        Equal(vm.History.Count, reopened.History.Count, "operation history survives application restart");
        Check(reopened.SourceAccounts.Any(a => a.DisplayName.Contains("Main Local")), "account aliases survive restart");
        vm.DeletePresetCommand.Execute(vm.Presets.Single());
        Check(vm.PanelOpen && (await new PresetService(Storage).ListAsync()).Count == 1,
            "preset deletion waits for explicit confirmation");
        await Execute(vm.ConfirmPanelCommand);
        Equal(0, (await new PresetService(Storage).ListAsync()).Count, "confirmed preset deletion removes persisted record");
        Check(!vm.IsBusy && vm.CanWork && Application.Current.Dispatcher.CheckAccess(),
            "all asynchronous operations finish on the WPF dispatcher and release the UI");
        await CheckImportedProfileAsync(preset.Profile);
        CheckThemeAndMotion();
        CheckServiceMessages();
    }

    private static void CheckServiceMessages()
    {
        const string applied = "Applied and verified 3 file(s). Start the game to confirm; Steam Cloud may offer a conflict.";
        Equal("Применены и проверены файлы: 3. Запустите игру для проверки; Steam Cloud может сообщить о конфликте.",
            ServiceMessages.Translate(applied, "ru"), "generated successful-transfer message is fully localized");
        Equal(applied, ServiceMessages.Translate(applied, "en"), "English service message retains its original bytes");
        const string rollback = "Target changed since the preview. Refresh before applying: local/cfg/cs2_user_convars_0_slot0.vcfg Original files restored and verified.";
        Equal("Целевой файл изменился после предварительного обзора. Обновите обзор перед применением: local/cfg/cs2_user_convars_0_slot0.vcfg Исходные файлы восстановлены и проверены.",
            ServiceMessages.Translate(rollback, "ru"), "rollback translation preserves filename and translates the verified-recovery outcome");
        const string recovery = "Recovery requires attention for account 202: Backup checksum mismatch: local/cfg/cs2_user_convars_0_slot0.vcfg";
        Equal("Восстановление аккаунта 202 требует внимания: Контрольная сумма резервной копии не совпадает: local/cfg/cs2_user_convars_0_slot0.vcfg",
            ServiceMessages.Translate(recovery, "ru"), "nested recovery message localizes account result and checksum reason");
        const string technicalPath = @"E:\Steam libraries\userdata\202\730\local\cfg\cs2_user_convars_0_slot0.vcfg";
        Equal(technicalPath, ServiceMessages.Translate(technicalPath, "ru"), "service localization preserves a technical absolute path exactly");
        Equal("sensitivity$2", ServiceMessages.Translate("sensitivity$2", "ru"), "service localization preserves an arbitrary technical parameter key");
        Equal("Future unknown service detail", ServiceMessages.Translate("Future unknown service detail", "ru"), "unknown diagnostic text remains intact");
        Equal("Чувствительность, Прицел", ServiceMessages.Translate("Sensitivity, Crosshair", "ru"), "known operation category lists are localized");
        Equal("Ожидает завершения\r\nИсходные файлы восстановлены и проверены.\r\n" + technicalPath,
            ServiceMessages.Translate("Pending\r\nOriginal files restored and verified.\r\n" + technicalPath, "ru"),
            "multiline service translation preserves newline format and technical paths");
    }

    private static async Task CheckImportedProfileAsync(ConfigProfile profile)
    {
        // Import uses a native file picker in the app. A persisted externally-owned profile exercises
        // the exact same VM state without opening a dialog or assigning it to an unrelated local account.
        var imported = await new PresetService(Storage).SaveAsync("External imported fixture", profile with { SourceAccountId = "", SourceName = "Imported fixture" });
        var vm = new MainViewModel(Storage);
        await vm.InitializeAsync();
        vm.LoadPresetCommand.Execute(vm.Presets.Single(p => p.Id == imported.Id));
        Check(vm.HasProfile && vm.Source is null, "externally owned profile has no invented local source account");
        Equal(3, vm.TargetAccounts.Count, "imported profile can target every local account");
        Check(vm.TargetAccounts.Any(a => a.AccountId == "101"), "imported profile can target the previously selected source account");
        Check(vm.ProfileSummary.Contains("Imported fixture"), "imported profile summary retains its real external source name");
        foreach (var account in vm.BatchTargets) account.Selected = account.AccountId is "101" or "303";
        vm.Target = vm.TargetAccounts.Single(a => a.AccountId == "101");
        vm.Language = "ru";
        Check(vm.HasProfile && vm.Source is null && vm.ProfileSummary.Contains("Imported fixture"),
            "language changes preserve the imported snapshot and its virtual source");
        Check(vm.BatchTargets.Where(a => a.Selected).Select(a => a.AccountId).ToHashSet().SetEquals(["101", "303"]),
            "language changes preserve the selected batch-recipient subset");
        Equal("101", vm.Target!.AccountId, "language changes preserve an imported profile's selected target");
        await Execute(vm.RescanCommand);
        Check(vm.HasProfile && vm.Source is null && vm.ProfileSummary.Contains("Imported fixture"),
            "rescan preserves the imported snapshot instead of assigning a local source");
        Check(vm.BatchTargets.Where(a => a.Selected).Select(a => a.AccountId).ToHashSet().SetEquals(["101", "303"]),
            "rescan preserves the selected batch-recipient subset");
        Check(Category(vm, ConfigCategory.Sensitivity).Available && !Category(vm, ConfigCategory.Keybinds).Available,
            "imported snapshot categories still reflect its selected stored files after rescan");
    }

    private static void CheckThemeAndMotion()
    {
        var theme = new ResourceDictionary { Source = new Uri("/SteamConfigManager;component/Theme.xaml", UriKind.Relative) };
        Application.Current.Resources.MergedDictionaries.Add(theme);
        var primary = new Button { Content = "Primary contrast", Style = (Style)theme["PrimaryButton"], Width = 220, Margin = new Thickness(10) };
        var radio = new RadioButton { Content = "Game selection", Style = (Style)theme["GameButton"], Height = 90, Margin = new Thickness(10) };
        var panel = new StackPanel();
        panel.Children.Add(primary);
        panel.Children.Add(radio);
        var surface = new Border { Child = panel, Background = (Brush)theme["SpaceBrush"], Width = 360, Height = 200 };
        TextElement.SetForeground(surface, (Brush)theme["TextBrush"]);
        surface.Measure(new Size(360, 200));
        surface.Arrange(new Rect(0, 0, 360, 200));
        surface.UpdateLayout();
        var renderedLabel = Descendants<TextBlock>(primary).Single(t => t.Text == "Primary contrast");
        Equal(Color.FromRgb(18, 19, 27), ((SolidColorBrush)renderedLabel.Foreground).Color,
            "PrimaryButton's rendered label inherits readable dark foreground on its white surface");
        var frozen = new ScaleTransform();
        frozen.Freeze();
        var primaryBody = (FrameworkElement)primary.Template.FindName("Surface", primary);
        primaryBody.RenderTransform = frozen;
        primary.RaiseEvent(new MouseButtonEventArgs(Mouse.PrimaryDevice, Environment.TickCount, MouseButton.Left)
            { RoutedEvent = UIElement.PreviewMouseLeftButtonDownEvent });
        Check(primaryBody.RenderTransform is ScaleTransform { IsFrozen: false } && !ReferenceEquals(frozen, primaryBody.RenderTransform),
            "press feedback safely clones a frozen template transform");
        primary.RaiseEvent(new MouseButtonEventArgs(Mouse.PrimaryDevice, Environment.TickCount, MouseButton.Left)
            { RoutedEvent = UIElement.PreviewMouseLeftButtonUpEvent });
        var oldMotion = Motion.Enabled;
        Motion.Enabled = true;
        radio.IsChecked = true;
        Check(radio.IsChecked == true, "game-selection feedback completes without a frozen-animation exception");
        Motion.Enabled = oldMotion;
        var rendered = new RenderTargetBitmap(360, 200, 96, 96, PixelFormats.Pbgra32);
        rendered.Render(surface);
        var png = new PngBitmapEncoder();
        png.Frames.Add(BitmapFrame.Create(rendered));
        using var image = File.Create(Path.Combine(Root, "theme-regression.png"));
        png.Save(image);
        Check(image.Length > 500, "actual WPF button and selected game templates render to a PNG");
    }

    private static IEnumerable<T> Descendants<T>(DependencyObject root) where T : DependencyObject
    {
        for (var i = 0; i < VisualTreeHelper.GetChildrenCount(root); i++)
        {
            var child = VisualTreeHelper.GetChild(root, i);
            if (child is T matched) yield return matched;
            foreach (var descendant in Descendants<T>(child)) yield return descendant;
        }
    }

    private static CategoryVM Category(MainViewModel vm, ConfigCategory category) => vm.Categories.Single(c => c.Category == category);
    private static void SensitivityOnly(MainViewModel vm)
    {
        foreach (var category in vm.Categories) category.Selected = category.Available && category.Category == ConfigCategory.Sensitivity;
        foreach (var file in vm.ConfigFiles) file.Selected = false;
    }
    private static async Task Execute(IAsyncRelayCommand command)
    {
        Check(command.CanExecute(null), "async command can execute");
        await command.ExecuteAsync(null);
    }
    private static async Task WaitUntil(Func<bool> condition)
    {
        var limit = DateTime.UtcNow.AddSeconds(10);
        while (!condition()) { if (DateTime.UtcNow > limit) throw new TimeoutException("UI operation did not finish."); await Task.Delay(10); }
    }
    private static Dictionary<string, string?> ReadConvars(string value)
    {
        var contents = File.Exists(value) ? File.ReadAllText(value) : value;
        return KeyValues.Parse(contents).Find("config")!.Children!.Find("convars")!.Children!.Entries.ToDictionary(e => e.Key, e => e.Value);
    }
    private static string Config(string account, string path, int game = 730) => Path.Combine(Steam, "userdata", account, game.ToString(), path.Replace('/', Path.DirectorySeparatorChar));
    private static async Task WriteAsync(string path, string contents)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        await File.WriteAllTextAsync(path, contents, new UTF8Encoding(false));
    }
    private static async Task SeedAsync()
    {
        await WriteAsync(Path.Combine(Steam, "steam.exe"), "Synthetic installation marker. Never executed.");
        var users = string.Join("\n", new[] { (101, "Main", "1"), (202, "Second", "0"), (303, "Third", "0") }
            .Select(a => $"\"{SteamAccountService.IndividualPublicBase + (ulong)a.Item1}\" {{ \"PersonaName\" \"{a.Item2}\" \"MostRecent\" \"{a.Item3}\" }}"));
        await WriteAsync(Path.Combine(Steam, "config", "loginusers.vdf"), "\"users\" {\n" + users + "\n}");
        var avatarPath = Path.Combine(Steam, "config", "avatarcache", (SteamAccountService.IndividualPublicBase + 101) + ".png");
        Directory.CreateDirectory(Path.GetDirectoryName(avatarPath)!);
        var avatar = BitmapSource.Create(2, 2, 96, 96, PixelFormats.Bgra32, null,
            new byte[] { 110, 90, 80, 255, 120, 100, 90, 255, 130, 110, 100, 255, 140, 120, 110, 255 }, 8);
        var encoder = new PngBitmapEncoder();
        encoder.Frames.Add(BitmapFrame.Create(avatar));
        using (var file = File.Create(avatarPath)) encoder.Save(file);
        await WriteAsync(Path.Combine(Steam, "config", "avatarcache", (SteamAccountService.IndividualPublicBase + 202) + ".png"), "Malformed synthetic image");
        await WriteAsync(Config("101", Convars), "\"config\" { \"convars\" { \"sensitivity\" \"2.5\" \"cl_crosshairsize\" \"4\" \"volume\" \"0.9\" \"snd_device_override\" \"source-device\" \"unknown_option\" \"source-value\" } }");
        await WriteAsync(Config("101", AdditionalSlot), "\"config\" { \"convars\" { \"sensitivity$2\" \"3.25\" \"cl_crosshairsize$2\" \"5\" } }");
        await WriteAsync(Config("101", Keys), "\"config\" { \"bindings\" { \"F1\" \"echo source\" } }");
        await WriteAsync(Config("101", Video), "\"video.cfg\" { \"setting.defaultres\" \"1920\" }");
        await WriteAsync(Config("202", Convars), "// Original target bytes must survive Undo.\n\"config\" { \"convars\" { \"sensitivity\" \"1.2\" \"cl_crosshairsize\" \"2\" \"volume\" \"0.4\" \"snd_device_override\" \"target-device\" \"unknown_option\" \"keep-target\" } }\n");
        await WriteAsync(Config("202", Keys), "\"config\" { \"bindings\" { \"F1\" \"echo target\" } }");
        await WriteAsync(Config("202", Video), "\"video.cfg\" { \"setting.defaultres\" \"1280\" }");
        await WriteAsync(Config("101", "remote/cfg/dotakeys_personal.lst", 570), "\"config\" { \"bindings\" { \"Q\" \"dota_ability_execute 0\" } }");
        await WriteAsync(Config("101", "remote/cfg/hero_grid_config.json", 570), "{\"version\":1,\"configs\":[]}");
        Directory.CreateDirectory(Path.Combine(Steam, "userdata", "303"));
    }
    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
        _checks++;
        Console.WriteLine("  PASS " + message);
    }
    private static void Equal<T>(T expected, T actual, string message) => Check(EqualityComparer<T>.Default.Equals(expected, actual), $"{message} (expected {expected}, actual {actual})");
}

