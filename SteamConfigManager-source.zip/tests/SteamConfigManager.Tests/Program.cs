using System.IO.Compression;
using System.Diagnostics;
using System.Text;
using SteamConfigManager.Core;

internal static class Program
{
    private const string Convars = "local/cfg/cs2_user_convars_0_slot0.vcfg";
    private const string Keys = "local/cfg/cs2_user_keys_0_slot0.vcfg";
    private const string Video = "local/cfg/cs2_video.txt";
    private static int _passed;
    private static readonly string TestRoot = Path.Combine(Path.GetFullPath(".test-runtime"), Guid.NewGuid().ToString("N"));
    private static async Task<int> Main(string[] args)
    {
        if (args.Contains("--synthetic-game-hold")) { await Task.Delay(30_000); return 0; }
        Directory.CreateDirectory(TestRoot);
        try
        {
            await Test("partial merge retains unknown, audio, device, and other target values", async f =>
            {
                await f.SeedAsync();
                var profile = await f.ProfileAsync();
                var plan = await f.Transfer.PreviewAsync(profile, await f.TargetAsync(), Selected(ConfigCategory.Crosshair, ConfigCategory.Sensitivity));
                Equal(1, plan.Changes.Count);
                var result = await f.Transfer.ApplyAsync(plan); True(result.Success, result.Message);
                var settings = ReadConvars(await File.ReadAllTextAsync(f.TargetPath(Convars)));
                Equal("2", settings["sensitivity$2"]); Equal("3", settings["cl_crosshairsize"]);
                Equal("0.4", settings["volume"]); Equal("target-device", settings["snd_device_override"]); Equal("keep", settings["unknown_option"]);
                Equal("target", ReadBindings(await File.ReadAllTextAsync(f.TargetPath(Keys)))["F1"]);
            });
            await Test("hardware and script files are excluded by default", async f =>
            {
                await f.SeedAsync();
                var profile = await f.ProfileAsync();
                var selection = new TransferSelection(Enum.GetValues<ConfigCategory>().ToHashSet(), profile.Files.Select(x => x.RelativePath).ToHashSet());
                var plan = await f.Transfer.PreviewAsync(profile, await f.TargetAsync(), selection);
                True(plan.Changes.All(c => c.RelativePath != Video));
                var settings = ReadConvars(Encoding.UTF8.GetString(plan.Changes.Single(c => c.RelativePath == Convars).Content));
                Equal("target-device", settings["snd_device_override"]);
            });
            await Test("explicit hardware opt-in transfers complete video file", async f =>
            {
                await f.SeedAsync();
                var selection = new TransferSelection([ConfigCategory.Video], [Video], true);
                var plan = await f.Transfer.PreviewAsync(await f.ProfileAsync(), await f.TargetAsync(), selection);
                Equal(1, plan.Changes.Count); Equal(Video, plan.Changes[0].RelativePath);
                True((await f.Transfer.ApplyAsync(plan)).Success);
                Equal(await File.ReadAllTextAsync(f.SourcePath(Video)), await File.ReadAllTextAsync(f.TargetPath(Video)));
            });
            await Test("same source and target account rejected", async f =>
            {
                await f.SeedAsync();
                await Throws<InvalidOperationException>(async () => await f.Transfer.PreviewAsync(await f.ProfileAsync(), await f.SourceAsync(), Selected(ConfigCategory.Keybinds)));
            });
            await Test("wrong game profile rejected", async f =>
            {
                await f.SeedAsync();
                var profile = await f.ProfileAsync();
                await Throws<InvalidDataException>(() => f.Transfer.PreviewAsync(profile, new(GameId.Dota2, "200", Path.Combine(f.Steam, "userdata", "200", "570"), []), Selected(ConfigCategory.Keybinds)));
            });
            await Test("identical second application produces no writes or backup", async f =>
            {
                await f.SeedAsync(); var profile = await f.ProfileAsync();
                var plan = await f.Transfer.PreviewAsync(profile, await f.TargetAsync(), Selected(ConfigCategory.Crosshair));
                True((await f.Transfer.ApplyAsync(plan)).Success);
                var again = await f.Transfer.PreviewAsync(profile, await f.TargetAsync(), Selected(ConfigCategory.Crosshair));
                Equal(0, again.Changes.Count); True((await f.Transfer.ApplyAsync(again)).Success);
                Equal(1, (await f.Backups.ListAsync()).Count);
            });
            await Test("stale preview refuses to overwrite external change", async f =>
            {
                await f.SeedAsync(); var plan = await f.Transfer.PreviewAsync(await f.ProfileAsync(), await f.TargetAsync(), Selected(ConfigCategory.Keybinds));
                await File.WriteAllTextAsync(f.TargetPath(Keys), KeyText("external"));
                var result = await f.Transfer.ApplyAsync(plan); True(!result.Success); Equal(0, (await f.Backups.ListAsync()).Count);
                True((await File.ReadAllTextAsync(f.TargetPath(Keys))).Contains("external"));
            });
            await Test("exclusively locked target fails before backup or write", async f =>
            {
                await f.SeedAsync(); var plan = await f.Transfer.PreviewAsync(await f.ProfileAsync(), await f.TargetAsync(), Selected(ConfigCategory.Keybinds));
                using var locked = new FileStream(f.TargetPath(Keys), FileMode.Open, FileAccess.ReadWrite, FileShare.None);
                var result = await f.Transfer.ApplyAsync(plan); True(!result.Success); Equal(0, (await f.Backups.ListAsync()).Count);
            });
            await Test("running game process blocks apply and restore", async f =>
            {
                await f.SeedAsync(); var plan = await f.Transfer.PreviewAsync(await f.ProfileAsync(), await f.TargetAsync(), Selected(ConfigCategory.Keybinds));
                True((await f.Transfer.ApplyAsync(plan)).Success); var backup = (await f.Backups.ListAsync()).Single();
                // Rename this test app's host, which runs only the inert hold branch above.
                foreach (var file in Directory.EnumerateFiles(AppContext.BaseDirectory)) File.Copy(file, Path.Combine(f.Root, Path.GetFileName(file)), true);
                var fakeGame = Path.Combine(f.Root, "cs2.exe"); File.Copy(Path.Combine(AppContext.BaseDirectory, "SteamConfigManager.Tests.exe"), fakeGame, true);
                using var process = Process.Start(new ProcessStartInfo(fakeGame, "--synthetic-game-hold") { UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden })!;
                try
                {
                    True(!process.WaitForExit(300), "Synthetic process exited before the safety check.");
                    var refused = await f.Transfer.ApplyAsync(plan); True(!refused.Success && refused.Message.Contains("running"));
                    await Throws<IOException>(() => f.Transfer.RestoreAsync(backup));
                }
                finally { if (!process.HasExited) { process.Kill(true); process.WaitForExit(5000); } }
            });
            await Test("mid-operation failure rolls back every changed original", async f =>
            {
                await f.SeedAsync(); var beforeKeys = await File.ReadAllBytesAsync(f.TargetPath(Keys)); var beforeVars = await File.ReadAllBytesAsync(f.TargetPath(Convars));
                var plan = await f.Transfer.PreviewAsync(await f.ProfileAsync(), await f.TargetAsync(), Selected(ConfigCategory.Keybinds, ConfigCategory.Crosshair));
                f.Transfer.AfterWriteForTesting = _ => throw new IOException("Injected write interruption");
                var result = await f.Transfer.ApplyAsync(plan); True(!result.Success);
                Sequence(beforeKeys, await File.ReadAllBytesAsync(f.TargetPath(Keys))); Sequence(beforeVars, await File.ReadAllBytesAsync(f.TargetPath(Convars)));
                Equal("RolledBack", (await f.Backups.ListAsync()).Single().State);
            });
            await Test("rollback removes files that did not exist before transfer", async f =>
            {
                await f.SeedAsync(); File.Delete(f.TargetPath(Keys)); File.Delete(f.TargetPath(Convars));
                var plan = await f.Transfer.PreviewAsync(await f.ProfileAsync(), await f.TargetAsync(), Selected(ConfigCategory.Keybinds, ConfigCategory.Crosshair));
                f.Transfer.AfterWriteForTesting = _ => throw new IOException("Injected interruption");
                True(!(await f.Transfer.ApplyAsync(plan)).Success);
                True(!File.Exists(f.TargetPath(Keys))); True(!File.Exists(f.TargetPath(Convars)));
            });
            await Test("undo restores originals and absence and creates its own backup", async f =>
            {
                await f.SeedAsync(); var original = await File.ReadAllBytesAsync(f.TargetPath(Convars)); File.Delete(f.TargetPath(Keys));
                var plan = await f.Transfer.PreviewAsync(await f.ProfileAsync(), await f.TargetAsync(), Selected(ConfigCategory.Keybinds, ConfigCategory.Crosshair));
                var applied = await f.Transfer.ApplyAsync(plan); True(applied.Success);
                var backup = (await f.Backups.ListAsync()).Single();
                var restored = await f.Transfer.RestoreAsync(backup); True(restored.Success, restored.Message);
                Sequence(original, await File.ReadAllBytesAsync(f.TargetPath(Convars))); True(!File.Exists(f.TargetPath(Keys)));
                Equal(2, (await f.Backups.ListAsync()).Count);
            });
            await Test("damaged backup fails restore without modifying current files", async f =>
            {
                await f.SeedAsync(); var plan = await f.Transfer.PreviewAsync(await f.ProfileAsync(), await f.TargetAsync(), Selected(ConfigCategory.Keybinds));
                True((await f.Transfer.ApplyAsync(plan)).Success); var backup = (await f.Backups.ListAsync()).Single();
                var current = await File.ReadAllBytesAsync(f.TargetPath(Keys));
                await File.WriteAllTextAsync(Path.Combine(f.Backups.Root, backup.Id, "files", Keys), "damaged");
                await Throws<InvalidDataException>(() => f.Transfer.RestoreAsync(backup));
                Sequence(current, await File.ReadAllBytesAsync(f.TargetPath(Keys)));
            });
            await Test("pending crash journal recovers partially applied files", async f =>
            {
                await f.SeedAsync(); var original = await File.ReadAllBytesAsync(f.TargetPath(Keys));
                var plan = await f.Transfer.PreviewAsync(await f.ProfileAsync(), await f.TargetAsync(), Selected(ConfigCategory.Keybinds, ConfigCategory.Crosshair));
                await f.Backups.CreateAsync(plan, "Simulated crash", default);
                var change = plan.Changes.First(c => c.RelativePath == Keys);
                await StorageIO.WriteAtomicAsync(f.TargetPath(Keys), change.Content);
                True((await f.Transfer.RecoverPendingAsync()).Single().StartsWith("Recovered"));
                Sequence(original, await File.ReadAllBytesAsync(f.TargetPath(Keys))); Equal("Recovered", (await f.Backups.ListAsync()).Single().State);
            });
            await Test("recovery refuses external conflicts and keeps durable backup", async f =>
            {
                await f.SeedAsync(); var plan = await f.Transfer.PreviewAsync(await f.ProfileAsync(), await f.TargetAsync(), Selected(ConfigCategory.Keybinds));
                var backup = await f.Backups.CreateAsync(plan, "Simulated crash", default);
                await File.WriteAllTextAsync(f.TargetPath(Keys), KeyText("external-after-crash"));
                var messages = await f.Transfer.RecoverPendingAsync(); True(messages.Single().Contains("will not overwrite"));
                True((await File.ReadAllTextAsync(f.TargetPath(Keys))).Contains("external-after-crash"));
                Equal("RecoveryRequired", (await f.Backups.ListAsync()).Single().State);
                await Throws<IOException>(() => f.Backups.DeleteAsync(backup.Id));
            });
            await Test("profile ZIP roundtrip preserves every byte and checksum", async f =>
            {
                await f.SeedAsync(); var profile = await f.ProfileAsync(); var zip = Path.Combine(f.Root, "profile.zip"); var service = new ImportExportService();
                await service.ExportAsync(profile, zip); var imported = await service.ImportAsync(zip, GameId.Cs2);
                Equal(profile.Files.Count, imported.Files.Count);
                foreach (var file in profile.Files) Sequence(file.Content, imported.Files.Single(x => x.RelativePath == file.RelativePath).Content);
                await Throws<InvalidDataException>(() => service.ImportAsync(zip, GameId.Dota2));
            });
            await Test("ZIP traversal and case-insensitive duplicate entries rejected", async f =>
            {
                foreach (var names in new[] { new[] { "../escape.cfg" }, new[] { "profile.json", "PROFILE.JSON" } })
                {
                    var zip = Path.Combine(f.Root, Guid.NewGuid() + ".zip");
                    using (var archive = ZipFile.Open(zip, ZipArchiveMode.Create)) foreach (var name in names) using (var writer = new StreamWriter(archive.CreateEntry(name).Open())) writer.Write("{}");
                    await Throws<InvalidDataException>(() => new ImportExportService().ImportAsync(zip, GameId.Cs2));
                }
                True(!File.Exists(Path.Combine(f.Root, "escape.cfg")));
            });
            await Test("ZIP manifest checksum catches modified content", async f =>
            {
                await f.SeedAsync(); var service = new ImportExportService(); var zip = Path.Combine(f.Root, "profile.zip");
                await service.ExportAsync(await f.ProfileAsync(), zip);
                using (var archive = ZipFile.Open(zip, ZipArchiveMode.Update))
                {
                    var original = archive.GetEntry("files/" + Keys)!; var length = original.Length; original.Delete();
                    using var stream = archive.CreateEntry("files/" + Keys).Open(); stream.Write(Enumerable.Repeat((byte)' ', (int)length).ToArray());
                }
                await Throws<InvalidDataException>(() => service.ImportAsync(zip, GameId.Cs2));
            });
            await Test("raw VCFG import maps to selected game's allowed directory", async f =>
            {
                var path = Path.Combine(f.Root, Path.GetFileName(Keys)); await File.WriteAllTextAsync(path, KeyText("import"));
                var profile = await new ImportExportService().ImportAsync(path, GameId.Cs2); Equal(Keys, profile.Files.Single().RelativePath);
                await Throws<InvalidDataException>(() => new ImportExportService().ImportAsync(path, GameId.Dota2));
            });
            await Test("presets persist, rename, validate identifiers, and delete", async f =>
            {
                await f.SeedAsync(); var presets = new PresetService(f.App); var saved = await presets.SaveAsync("Competitive", await f.ProfileAsync());
                await presets.RenameAsync(saved.Id, "Training"); Equal("Training", (await new PresetService(f.App).ListAsync()).Single().Name);
                await Throws<InvalidDataException>(() => presets.DeleteAsync("../escape")); await presets.DeleteAsync(saved.Id); Equal(0, (await presets.ListAsync()).Count);
            });
            await Test("retention preserves backups by default and deletes only after opt-in", async f =>
            {
                await f.SeedAsync(); var plan = await f.Transfer.PreviewAsync(await f.ProfileAsync(), await f.TargetAsync(), Selected(ConfigCategory.Keybinds));
                True((await f.Transfer.ApplyAsync(plan)).Success); var backup = (await f.Backups.ListAsync()).Single();
                await f.Backups.SaveAsync(backup with { CreatedUtc = DateTime.UtcNow.AddDays(-100) });
                Equal(0, await f.Backups.ApplyRetentionAsync(new() { RetentionEnabled = false, RetentionDays = 30 })); Equal(1, (await f.Backups.ListAsync()).Count);
                Equal(1, await f.Backups.ApplyRetentionAsync(new() { RetentionEnabled = true, RetentionDays = 30 })); Equal(0, (await f.Backups.ListAsync()).Count);
            });
            await Test("retention never deletes a pending recovery backup", async f =>
            {
                await f.SeedAsync(); var plan = await f.Transfer.PreviewAsync(await f.ProfileAsync(), await f.TargetAsync(), Selected(ConfigCategory.Keybinds));
                var backup = await f.Backups.CreateAsync(plan, "Interrupted", default);
                await f.Backups.SaveAsync(backup with { CreatedUtc = DateTime.UtcNow.AddDays(-100) });
                Equal(0, await f.Backups.ApplyRetentionAsync(new() { RetentionEnabled = true, RetentionDays = 30 })); Equal(1, (await f.Backups.ListAsync()).Count);
            });
            await Test("settings and operation history persist after reload", async f =>
            {
                var service = new ApplicationSettingsService(f.App); var settings = new AppSettings { Language = "ru", Effects = .2, Favorites = ["100"], Aliases = new() { ["100"] = "Основной" } };
                service.Save(settings); var loaded = new ApplicationSettingsService(f.App).Load(); Equal("ru", loaded.Language); Equal("Основной", loaded.Aliases["100"]);
                await f.SeedAsync(); var plan = await f.Transfer.PreviewAsync(await f.ProfileAsync(), await f.TargetAsync(), Selected(ConfigCategory.Keybinds)); True((await f.Transfer.ApplyAsync(plan)).Success);
                var record = (await new OperationHistoryService(f.App).ListAsync()).Single(); True(record.Success); True(record.BackupId != null);
            });
            await Test("tampered paths and arbitrary target root never write", async f =>
            {
                await f.SeedAsync(); var profile = await f.ProfileAsync();
                var evil = profile with { Files = [new("../outside.cfg", Encoding.UTF8.GetBytes("text"), StorageIO.Hash(Encoding.UTF8.GetBytes("text")))] };
                await Throws<InvalidDataException>(async () => await f.Transfer.PreviewAsync(evil, await f.TargetAsync(), Selected(ConfigCategory.Other)));
                var plan = new TransferPlan(new(GameId.Cs2, "200", f.Root, []), [], "source", "100", []);
                True(!(await f.Transfer.ApplyAsync(plan)).Success);
            });
            _passed += await DiscoveryTests.RunAsync(TestRoot);
            _passed += await SafetyTests.RunAsync(TestRoot);
            _passed += await BinaryTests.RunAsync(TestRoot);
            Console.WriteLine($"PASS: {_passed} tests. All Steam data used by tests was synthetic.");
            return 0;
        }
        catch (Exception ex) { Console.Error.WriteLine("FAIL after " + _passed + " tests: " + ex); return 1; }
        finally
        {
            var actual = Path.GetFullPath(TestRoot);
            var expected = Path.GetFullPath(".test-runtime") + Path.DirectorySeparatorChar;
            if (actual.StartsWith(expected, StringComparison.OrdinalIgnoreCase) && Directory.Exists(actual)) Directory.Delete(actual, true);
        }
    }
    private static async Task Test(string name, Func<Fixture, Task> test)
    {
        var fixture = new Fixture(Path.Combine(TestRoot, Guid.NewGuid().ToString("N")));
        await test(fixture); ++_passed; Console.WriteLine("PASS " + name);
    }
    private static TransferSelection Selected(params ConfigCategory[] categories) => new(categories.ToHashSet(), []);
    private static Dictionary<string, string> ReadConvars(string text) => KeyValues.Parse(text).Find("config")!.Children!.Find("convars")!.Children!.Entries.ToDictionary(x => x.Key, x => x.Value!);
    private static Dictionary<string, string> ReadBindings(string text) => KeyValues.Parse(text).Find("config")!.Children!.Find("bindings")!.Children!.Entries.ToDictionary(x => x.Key, x => x.Value!);
    private static string KeyText(string value) => $"\"config\" {{ \"bindings\" {{ \"F1\" \"{value}\" }} }}";
    private static void True(bool value, string? message = null) { if (!value) throw new Exception(message ?? "Assertion failed."); }
    private static void Equal<T>(T expected, T actual) { if (!EqualityComparer<T>.Default.Equals(expected, actual)) throw new Exception($"Expected {expected}; got {actual}."); }
    private static void Sequence(byte[] expected, byte[] actual) => True(expected.SequenceEqual(actual), "Bytes differ.");
    private static async Task Throws<T>(Func<Task> action) where T : Exception
    {
        try { await action(); } catch (T) { return; }
        throw new Exception("Expected " + typeof(T).Name);
    }
    private sealed class Fixture
    {
        public string Root { get; }
        public string Steam => Path.Combine(Root, "Steam");
        public string App => Path.Combine(Root, "App");
        public BackupService Backups { get; }
        public ConfigTransferService Transfer { get; }
        public Fixture(string root) { Root = root; Directory.CreateDirectory(Root); Backups = new(App); Transfer = new(Backups, new(App)); }
        public string SourcePath(string relative) => SafePaths.Resolve(Path.Combine(Steam, "userdata", "100", "730"), relative);
        public string TargetPath(string relative) => SafePaths.Resolve(Path.Combine(Steam, "userdata", "200", "730"), relative);
        public Task<GameConfig> SourceAsync() => new CS2ConfigService().DiscoverAsync(Steam, "100");
        public Task<GameConfig> TargetAsync() => new CS2ConfigService().DiscoverAsync(Steam, "200");
        public async Task<ConfigProfile> ProfileAsync() => await Transfer.CaptureAsync(await SourceAsync(), "Main");
        public async Task SeedAsync()
        {
            Directory.CreateDirectory(Path.GetDirectoryName(SourcePath(Keys))!); Directory.CreateDirectory(Path.GetDirectoryName(TargetPath(Keys))!);
            await File.WriteAllTextAsync(SourcePath(Keys), KeyText("source")); await File.WriteAllTextAsync(TargetPath(Keys), KeyText("target"));
            await File.WriteAllTextAsync(SourcePath(Convars), "\"config\" { \"convars\" { \"sensitivity$2\" \"2\" \"cl_crosshairsize\" \"3\" \"volume\" \"0.8\" \"snd_device_override\" \"source-device\" \"unknown_option\" \"source-unknown\" } }");
            await File.WriteAllTextAsync(TargetPath(Convars), "\"config\" { \"convars\" { \"sensitivity$2\" \"1\" \"cl_crosshairsize\" \"5\" \"volume\" \"0.4\" \"snd_device_override\" \"target-device\" \"unknown_option\" \"keep\" } }");
            await File.WriteAllTextAsync(SourcePath(Video), "\"video.cfg\" { \"setting.defaultres\" \"1920\" }"); await File.WriteAllTextAsync(TargetPath(Video), "\"video.cfg\" { \"setting.defaultres\" \"1280\" }");
        }
    }
}
