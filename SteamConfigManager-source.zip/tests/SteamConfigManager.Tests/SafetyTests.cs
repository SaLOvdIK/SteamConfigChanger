using System.Diagnostics;
using System.IO.Compression;
using System.Text;
using System.Text.Json;
using SteamConfigManager.Core;

internal static class SafetyTests
{
    private const string Keys = "local/cfg/cs2_user_keys_0_slot0.vcfg";
    private const string Convars = "local/cfg/cs2_user_convars_0_slot0.vcfg";
    private static TransferSelection Selected(params ConfigCategory[] categories) => new(categories.ToHashSet(), []);
    private static byte[] Bytes(string value) => Encoding.UTF8.GetBytes(value);
    private static ProfileFile FileEntry(string path, string value) { var data = Bytes(value); return new(path, data, StorageIO.Hash(data)); }
    private static void Check(bool value, string message = "Assertion failed") { if (!value) throw new Exception(message); }
    private static async Task<T> Reject<T>(Func<Task> action) where T : Exception
    {
        try { await action(); } catch (T ex) { return ex; }
        throw new Exception("Expected " + typeof(T).Name);
    }

    public static async Task<int> RunAsync(string root)
    {
        var passed = 0;
        async Task Test(string name, Func<Fixture, Task> action)
        {
            var fixture = new Fixture(Path.Combine(root, "safety-" + Guid.NewGuid().ToString("N")));
            await action(fixture); passed++; Console.WriteLine("PASS " + name);
        }
        await Test("duplicate object and object/leaf names cannot bypass safe KV merging", async f =>
        {
            foreach (var text in new[] { "root { a b } root { c d }", "root { a b } root c", "root { child { a b } child { c d } }" })
                await Reject<InvalidDataException>(() => Task.Run(() => KeyValues.Parse(text).FlattenLeaves()));
        });
        await Test("keybind category preserves target metadata outside bindings", async f =>
        {
            await f.SeedAsync();
            await File.WriteAllTextAsync(f.PathFor("200", Keys), "config { bindings { F1 old } target_metadata keep other { x y } }");
            var result = await f.Transfer.ApplyAsync(await f.PlanAsync("200", ConfigCategory.Keybinds)); Check(result.Success, result.Message);
            var values = KeyValues.Parse(await File.ReadAllTextAsync(f.PathFor("200", Keys))).FlattenLeaves();
            Check(values["config/bindings/F1"] == "source" && values["config/target_metadata"] == "keep" && values["config/other/x"] == "y");
        });
        await Test("source changes after scan require rescan before capture", async f =>
        {
            await f.SeedAsync(); var scanned = await f.ConfigAsync("100");
            await File.WriteAllTextAsync(f.PathFor("100", Keys), "config { bindings { F1 changed } }");
            await Reject<IOException>(() => f.Transfer.CaptureAsync(scanned, "Main"));
            Check((await f.Backups.ListAsync()).Count == 0);
        });
        await Test("read-only target is refused without modifying bytes", async f =>
        {
            await f.SeedAsync(); var plan = await f.PlanAsync("200", ConfigCategory.Keybinds);
            var path = f.PathFor("200", Keys); var before = await File.ReadAllBytesAsync(path);
            File.SetAttributes(path, File.GetAttributes(path) | FileAttributes.ReadOnly);
            try { Check(!(await f.Transfer.ApplyAsync(plan)).Success); Check(Enumerable.SequenceEqual(before, await File.ReadAllBytesAsync(path))); }
            finally { File.SetAttributes(path, FileAttributes.Normal); }
            Check((await f.Backups.ListAsync()).Count == 0);
        });
        await Test("cancellation after first replacement rolls back every original", async f =>
        {
            await f.SeedAsync(); var before = await File.ReadAllBytesAsync(f.PathFor("200", Keys));
            using var cancellation = new CancellationTokenSource();
            var plan = await f.PlanAsync("200", ConfigCategory.Keybinds, ConfigCategory.Crosshair);
            f.Transfer.AfterWriteForTesting = _ => cancellation.Cancel();
            var result = await f.Transfer.ApplyAsync(plan, cancellation.Token);
            Check(!result.Success && result.Message.Contains("cancelled"));
            Check(Enumerable.SequenceEqual(before, await File.ReadAllBytesAsync(f.PathFor("200", Keys))));
            Check((await f.Backups.ListAsync()).Single().State == "RolledBack");
        });
        await Test("multiple target results and backup ownership remain independent", async f =>
        {
            await f.SeedAsync(); await f.SeedTargetAsync("300"); await f.SeedTargetAsync("400");
            var plans = new[] { await f.PlanAsync("200", ConfigCategory.Keybinds), await f.PlanAsync("300", ConfigCategory.Keybinds), await f.PlanAsync("400", ConfigCategory.Keybinds) };
            using var locked = new FileStream(f.PathFor("300", Keys), FileMode.Open, FileAccess.ReadWrite, FileShare.None);
            var results = new List<TransferResult>(); foreach (var plan in plans) results.Add(await f.Transfer.ApplyAsync(plan));
            Check(results[0].Success && !results[1].Success && results[2].Success);
            var backups = await f.Backups.ListAsync(); Check(backups.Count == 2 && backups.Select(b => b.AccountId).ToHashSet().SetEquals(["200", "400"]));
        });
        await Test("pending transaction blocks subsequent application to that account", async f =>
        {
            await f.SeedAsync(); var plan = await f.PlanAsync("200", ConfigCategory.Keybinds);
            await f.Backups.CreateAsync(plan, "Interrupted", default);
            var before = await File.ReadAllBytesAsync(f.PathFor("200", Keys));
            var result = await f.Transfer.ApplyAsync(plan); Check(!result.Success && result.Message.Contains("interrupted"));
            Check(Enumerable.SequenceEqual(before, await File.ReadAllBytesAsync(f.PathFor("200", Keys))));
        });
        await Test("backup ZIP keeps exact malformed originals and absence metadata", async f =>
        {
            await f.SeedAsync();
            var original = Bytes("config { malformed original"); await File.WriteAllBytesAsync(f.PathFor("200", Keys), original);
            File.Delete(f.PathFor("200", Convars));
            var selection = new TransferSelection([ConfigCategory.Crosshair], [Keys]);
            var plan = await f.Transfer.PreviewAsync(await f.ProfileAsync(), await f.ConfigAsync("200"), selection);
            Check((await f.Transfer.ApplyAsync(plan)).Success);
            var backup = (await f.Backups.ListAsync()).Single(); var zip = Path.Combine(f.Root, "backup.zip");
            await f.Backups.ExportAsync(backup.Id, zip);
            using (var archive = ZipFile.OpenRead(zip))
            {
                var manifest = JsonSerializer.Deserialize<BackupRecord>(await ReadEntryAsync(archive.GetEntry("backup.json")!))!;
                Check(manifest.Files.Single(x => x.RelativePath == Convars).Existed == false);
                Check(Enumerable.SequenceEqual(original, await ReadEntryAsync(archive.GetEntry("files/" + Keys)!)));
                Check(archive.GetEntry("files/" + Convars) is null);
            }
            var error = await Reject<InvalidDataException>(() => new ImportExportService().ImportAsync(zip, GameId.Cs2)); Check(error.Message.Contains("backup archive"));
            Check((await f.Transfer.RestoreAsync(backup)).Success); Check(Enumerable.SequenceEqual(original, await File.ReadAllBytesAsync(f.PathFor("200", Keys))));
        });
        await Test("archive symlinks and Windows reparse entries are rejected", async f =>
        {
            foreach (var attributes in new[] { unchecked((int)0xA1FF0000), (int)FileAttributes.ReparsePoint })
            {
                var path = Path.Combine(f.Root, Guid.NewGuid() + ".zip");
                using (var archive = ZipFile.Open(path, ZipArchiveMode.Create)) { var entry = archive.CreateEntry("profile.json"); entry.ExternalAttributes = attributes; await using var stream = entry.Open(); await stream.WriteAsync(Bytes("{}")); }
                await Reject<InvalidDataException>(() => new ImportExportService().ImportAsync(path, GameId.Cs2));
            }
        });
        await Test("profile ZIP rejects undeclared files", async f =>
        {
            await f.SeedAsync(); var path = Path.Combine(f.Root, "profile.zip"); var service = new ImportExportService(); await service.ExportAsync(await f.ProfileAsync(), path);
            using (var archive = ZipFile.Open(path, ZipArchiveMode.Update)) { await using var stream = archive.CreateEntry("files/extra.cfg").Open(); await stream.WriteAsync(Bytes("unexpected")); }
            await Reject<InvalidDataException>(() => service.ImportAsync(path, GameId.Cs2));
        });
        await Test("oversized expanded archive entry is rejected before decompression", async f =>
        {
            var path = Path.Combine(f.Root, "large.zip");
            using (var archive = ZipFile.Open(path, ZipArchiveMode.Create))
            {
                await using var stream = archive.CreateEntry("files/" + Keys, CompressionLevel.Optimal).Open();
                await stream.WriteAsync(new byte[GameRules.MaxFileBytes + 1]);
            }
            await Reject<InvalidDataException>(() => new ImportExportService().ImportAsync(path, GameId.Cs2));
        });
        await Test("null profile entries are a structured validation error", async f =>
        {
            var profile = new ConfigProfile(GameId.Cs2, "", "Malformed", [new(Keys, null!, "")], DateTime.UtcNow);
            await Reject<InvalidDataException>(() => new ImportExportService().ExportAsync(profile, Path.Combine(f.Root, "invalid.zip")));
        });
        await Test("empty profiles cannot masquerade as a successful import or preset", async f =>
        {
            var profile = new ConfigProfile(GameId.Cs2, "", "Empty", [], DateTime.UtcNow);
            await Reject<InvalidDataException>(() => new PresetService(f.Root).SaveAsync("Empty", profile));
            var zip = Path.Combine(f.Root, "empty.zip");
            using (var archive = ZipFile.Open(zip, ZipArchiveMode.Create))
            {
                await using var stream = archive.CreateEntry("profile.json").Open();
                await stream.WriteAsync(Bytes("{\"Format\":\"SteamConfigManager\",\"Version\":1,\"Game\":730,\"SourceAccountId\":\"\",\"SourceName\":\"Empty\",\"CapturedUtc\":\"2026-11-15T00:00:00Z\",\"Files\":[]}"));
            }
            await Reject<InvalidDataException>(() => new ImportExportService().ImportAsync(zip, GameId.Cs2));
        });
        await Test("linked target ancestor is refused and external folder is untouched", async f =>
        {
            var external = Path.Combine(f.Root, "external"); Directory.CreateDirectory(external);
            var junction = Path.Combine(f.Steam, "userdata"); Directory.CreateDirectory(f.Steam);
            var start = new ProcessStartInfo("cmd.exe") { UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden, RedirectStandardOutput = true, RedirectStandardError = true };
            start.ArgumentList.Add("/c"); start.ArgumentList.Add("mklink"); start.ArgumentList.Add("/J"); start.ArgumentList.Add(junction); start.ArgumentList.Add(external);
            using var process = Process.Start(start)!; var output = await process.StandardOutput.ReadToEndAsync(); var errors = await process.StandardError.ReadToEndAsync(); await process.WaitForExitAsync();
            Check(process.ExitCode == 0, "Could not create synthetic junction: " + output + errors);
            try
            {
                await Reject<InvalidDataException>(() => new CS2ConfigService().DiscoverAsync(f.Steam, "200"));
                Check(!Directory.EnumerateFileSystemEntries(external).Any());
            }
            finally { Directory.Delete(junction); }
        });
        await Test("malformed discovered source is warned and never captured silently", async f =>
        {
            await f.SeedAsync(); await File.WriteAllTextAsync(f.PathFor("100", Convars), "config { convars {");
            var config = await f.ConfigAsync("100"); Check(config.Health == HealthStatus.Warning && config.Files.Single(x => x.RelativePath == Convars).Issue is not null);
            await Reject<InvalidDataException>(() => f.Transfer.CaptureAsync(config, "Main"));
        });
        await Test("Dota grids and hero bindings are discovered and transfer conservatively", async f =>
        {
            var service = new DotaConfigService(); var source = Path.Combine(f.Steam, "userdata", "100", "570"); var target = Path.Combine(f.Steam, "userdata", "200", "570");
            const string grid = "remote/cfg/hero_grid_config.json", heroes = "remote/cfg/dotakeys_personal.lst", settings = "remote/user_convars.vcfg";
            foreach (var file in new[] { FileEntry(grid, "{\"configs\":[{\"config_name\":\"My grid\",\"categories\":[]}]}"), FileEntry(heroes, "KeyBindings { npc_dota_hero_axe { ability1 Q } }"), FileEntry(settings, "config { convars { volume 0.5 } }") })
            { var path = SafePaths.Resolve(source, file.RelativePath); Directory.CreateDirectory(Path.GetDirectoryName(path)!); await File.WriteAllBytesAsync(path, file.Content); }
            var discovered = await service.DiscoverAsync(f.Steam, "100"); Check(discovered.Files.Count == 3);
            var profile = await f.Transfer.CaptureAsync(discovered, "Dota Main");
            var plan = await f.Transfer.PreviewAsync(profile, await service.DiscoverAsync(f.Steam, "200"), new(Enum.GetValues<ConfigCategory>().ToHashSet(), []));
            Check(plan.Changes.Count == 1 && plan.Changes[0].RelativePath == grid);
            Check((await f.Transfer.ApplyAsync(plan)).Success && File.Exists(SafePaths.Resolve(target, grid)));
            var full = await f.Transfer.PreviewAsync(profile, await service.DiscoverAsync(f.Steam, "200"), new([], [heroes])); Check(full.Changes.Count == 1 && full.Changes[0].RelativePath == heroes);
        });
        await Test("comparison counts actual changed added and unchanged effective values", async f =>
        {
            await f.SeedAsync(); var source = await f.ProfileAsync(); var results = await new ConfigComparisonService().CompareAsync(source, await f.ConfigAsync("200"), Selected(ConfigCategory.Crosshair, ConfigCategory.Sensitivity));
            var comparison = results.Single(x => x.RelativePath == Convars);
            Check(comparison.Status == "Different" && comparison.ChangedParameters == 1 && comparison.AddedParameters == 1 && comparison.RemovedParameters == 0 && comparison.UnchangedParameters == 2);
            Check(comparison.Parameters.Single(p => p.Key.EndsWith("unknown")).Status == "Unchanged");
            Check(results.Single(x => x.RelativePath == Keys).Status == "Skipped");
        });
        await Test("comparison accepts same-account backup and reports identical values", async f =>
        {
            await f.SeedAsync(); var results = await new ConfigComparisonService().CompareAsync(await f.ProfileAsync(), await f.ConfigAsync("100"), Selected(ConfigCategory.Keybinds, ConfigCategory.Crosshair));
            Check(results.All(x => x.Status == "Identical"));
        });
        await Test("backup target tampering cannot redirect recovery", async f =>
        {
            await f.SeedAsync(); var plan = await f.PlanAsync("200", ConfigCategory.Keybinds); Check((await f.Transfer.ApplyAsync(plan)).Success);
            var backup = (await f.Backups.ListAsync()).Single(); var before = await File.ReadAllBytesAsync(f.PathFor("200", Keys));
            await StorageIO.WriteJsonAsync(Path.Combine(f.Backups.Root, backup.Id, "backup.json"), backup with { TargetRoot = f.Root });
            await Reject<InvalidDataException>(() => f.Transfer.RestoreAsync(backup)); Check(Enumerable.SequenceEqual(before, await File.ReadAllBytesAsync(f.PathFor("200", Keys))));
        });
        await Test("recovery verifies all originals before restoring any target", async f =>
        {
            await f.SeedAsync(); var plan = await f.PlanAsync("200", ConfigCategory.Keybinds, ConfigCategory.Crosshair); var backup = await f.Backups.CreateAsync(plan, "Interrupted", default);
            foreach (var change in plan.Changes) await StorageIO.WriteAtomicAsync(f.PathFor("200", change.RelativePath), change.Content);
            File.Delete(SafePaths.Resolve(Path.Combine(f.Backups.Root, backup.Id, "files"), Convars));
            Check((await f.Transfer.RecoverPendingAsync()).Single().Contains("attention"));
            foreach (var change in plan.Changes) Check(Enumerable.SequenceEqual(change.Content, await File.ReadAllBytesAsync(f.PathFor("200", change.RelativePath))));
            Check((await f.Backups.ListAsync()).Single().State == "RecoveryRequired");
        });
        Console.WriteLine($"{passed} additional safety/functional tests passed."); return passed;
    }
    private static async Task<byte[]> ReadEntryAsync(ZipArchiveEntry entry)
    { await using var input = entry.Open(); using var output = new MemoryStream(); await input.CopyToAsync(output); return output.ToArray(); }
    private sealed class Fixture
    {
        public string Root { get; }
        public string Steam => Path.Combine(Root, "Steam");
        public BackupService Backups { get; }
        public ConfigTransferService Transfer { get; }
        public Fixture(string root) { Root = root; Directory.CreateDirectory(root); var app = Path.Combine(root, "App"); Backups = new(app); Transfer = new(Backups, new(app)); }
        public string PathFor(string account, string relative) => SafePaths.Resolve(Path.Combine(Steam, "userdata", account, "730"), relative);
        public Task<GameConfig> ConfigAsync(string account) => new CS2ConfigService().DiscoverAsync(Steam, account);
        public async Task<ConfigProfile> ProfileAsync() => await Transfer.CaptureAsync(await ConfigAsync("100"), "Main");
        public async Task<TransferPlan> PlanAsync(string account, params ConfigCategory[] categories) => await Transfer.PreviewAsync(await ProfileAsync(), await ConfigAsync(account), Selected(categories));
        public async Task SeedAsync()
        {
            Directory.CreateDirectory(Path.GetDirectoryName(PathFor("100", Keys))!);
            await File.WriteAllTextAsync(PathFor("100", Keys), "config { bindings { F1 source } }");
            await File.WriteAllTextAsync(PathFor("100", Convars), "config { convars { cl_crosshairsize 5 sensitivity 2 volume 0.7 unknown source } }");
            await SeedTargetAsync("200");
        }
        public async Task SeedTargetAsync(string account)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(PathFor(account, Keys))!);
            await File.WriteAllTextAsync(PathFor(account, Keys), "config { bindings { F1 target } }");
            await File.WriteAllTextAsync(PathFor(account, Convars), "config { convars { cl_crosshairsize 3 volume 0.4 unknown target } }");
        }
    }
}
