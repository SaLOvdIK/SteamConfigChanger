using System.Security.Cryptography;
using System.Text;
using SteamConfigManager.Core;

public static class DiscoveryTests
{
    public static async Task<int> RunAsync(string root)
    {
        int passed = 0;
        void Check(bool condition, string name) { if (!condition) throw new Exception("Discovery test failed: " + name); passed++; Console.WriteLine("PASS " + name); }
        void Reject(Action action, string name) { bool rejected = false; try { action(); } catch (InvalidDataException) { rejected = true; } Check(rejected, name); }
        static byte[] Bytes(string value) => Encoding.UTF8.GetBytes(value);
        static ProfileFile Profile(string path, byte[] data) => new(path, data, Convert.ToHexString(SHA256.HashData(data)));

        Check(SteamAccountService.TryGetAccountId("76561197960265729", out var one) && one == "1", "SteamID64 maps to AccountID");
        Check(SteamAccountService.TryGetAccountId((SteamAccountService.IndividualPublicBase + uint.MaxValue).ToString(), out var max) && max == uint.MaxValue.ToString(), "AccountID upper boundary");
        Check(!SteamAccountService.TryGetAccountId("76561197960265728", out _) && !SteamAccountService.TryGetAccountId("76561197960265727", out _) && !SteamAccountService.TryGetAccountId("76561202255233024", out _), "Reject invalid public individual IDs");

        var parsed = KeyValues.Parse("// comment\n\"root\" { \"{\" \"}\" \"path\" \"cfg\\\\test.cfg\" \"nickname\" \"Имя\" }");
        var reparsed = KeyValues.Parse(parsed.ToString());
        Check(reparsed.Find("root")?.Children?.Find("{")?.Value == "}" && reparsed.Find("root")?.Children?.Find("nickname")?.Value == "Имя", "KV quoted braces, escapes and Unicode roundtrip");
        var literalBackslash="\"KeyBindings\" { \"Keys\" { \"Console\" { \"Key\" \"\\\" } } }";
        var legacyKeys=KeyValues.Parse(literalBackslash,useEscapeSequences:false);
        Check(legacyKeys.Find("KeyBindings")?.Children?.Find("Keys")?.Children?.Find("Console")?.Children?.Find("Key")?.Value=="\\","Dota legacy .lst parses literal backslash without escape interpretation");
        Reject(() => KeyValues.Parse("root { a b"), "Reject unclosed KV object");
        Reject(() => KeyValues.Parse("#include settings.vdf"), "Reject unsupported KV include directive");
        Reject(() => KeyValues.Parse("root { key value key value2 }").FlattenLeaves(), "Reject ambiguous duplicate setting keys");
        Reject(() => SafePaths.Resolve(root, "../escape.cfg"), "Reject parent traversal");
        Reject(() => SafePaths.Resolve(root, "local/cfg/config.cfg:stream"), "Reject alternate data stream");
        Reject(() => SafePaths.Resolve(root, "local/cfg/NUL.vcfg"), "Reject reserved Windows path component");

        const string convarsPath = "local/cfg/cs2_user_convars_0_slot0.vcfg";
        var source = Bytes("\"config\" { \"convars\" { \"sensitivity$2\" \"2\" \"cl_crosshairsize\" \"5\" \"snd_device_override\" \"source-device\" \"future_setting\" \"source\" } }");
        var target = Bytes("\"config\" { \"convars\" { \"sensitivity\" \"1\" \"sensitivity$2\" \"1.5\" \"cl_crosshairsize\" \"3\" \"snd_device_override\" \"target-device\" \"future_setting\" \"target\" } \"future_section\" { \"a\" \"b\" } }");
        ConfigValidationService.Validate(Profile(convarsPath, source), GameId.Cs2);
        var selection = new TransferSelection([ConfigCategory.Sensitivity], []);
        var merged = GameRules.Merge(GameId.Cs2, convarsPath, source, target, selection)!;
        var values = KeyValues.Parse(GameRules.Decode(merged)).FlattenLeaves();
        Check(values["config/convars/sensitivity$2"] == "2" && values["config/convars/sensitivity"] == "1", "CS2 exact slot suffix preserved during merge");
        Check(values["config/convars/cl_crosshairsize"] == "3" && values["config/convars/snd_device_override"] == "target-device" && values["config/convars/future_setting"] == "target" && values["config/future_section/a"] == "b", "Partial transfer preserves unrelated and unknown target values");
        var unchanged = GameRules.Merge(GameId.Cs2, convarsPath, merged, merged, selection)!;
        Check(unchanged.SequenceEqual(merged), "Identical selected values preserve original target bytes");
        var categories = GameRules.AvailableCategories(GameId.Cs2, convarsPath, source);
        Check(categories.Count == 2 && categories.Contains(ConfigCategory.Sensitivity) && categories.Contains(ConfigCategory.Crosshair), "Only actual recognized categories are reported");
        var fresh = KeyValues.Parse(GameRules.Decode(GameRules.Merge(GameId.Cs2, convarsPath, source, null, selection)!)).FlattenLeaves();
        Check(fresh.Count == 1 && fresh["config/convars/sensitivity$2"] == "2", "Missing target creates only selected settings");
        var allWithoutHardware = KeyValues.Parse(GameRules.Decode(GameRules.Merge(GameId.Cs2, convarsPath, source, target, new([], [convarsPath]))!)).FlattenLeaves();
        Check(allWithoutHardware["config/convars/snd_device_override"] == "target-device", "Whole selection without device consent preserves target hardware");
        Check(GameRules.Merge(GameId.Cs2, "local/cfg/cs2_machine_convars.vcfg", Bytes("root { a b }"), null, new([ConfigCategory.Video], [])) is null, "Hardware file blocked without explicit consent");
        Check(GameRules.Merge(GameId.Dota2, "remote/cfg/dotakeys_personal.lst", Bytes("root { a b }"), null, new([ConfigCategory.Keybinds,ConfigCategory.HeroSettings], [])) is null, "Combined Dota keys require explicit whole-file selection");
        Check(!GameRules.IsAllowed(GameId.Dota2, "remote/scripts/clientstorage.txt") && !GameRules.IsAllowed(GameId.Cs2, "local/cfg/steam.exe"), "Unrelated Steam and executable files excluded");
        Reject(() => ConfigValidationService.Validate(new(convarsPath, source, new string('0', 64)), GameId.Cs2), "Profile hash verification");

        var fixture = Path.Combine(root, "discovery-steam");
        Directory.CreateDirectory(Path.Combine(fixture, "config"));
        await File.WriteAllTextAsync(Path.Combine(fixture, "steam.exe"), "");
        await File.WriteAllTextAsync(Path.Combine(fixture, "config", "loginusers.vdf"), "\"users\" { \"76561197960265729\" { \"PersonaName\" \"Main Account\" \"MostRecent\" \"1\" } \"76561197960265731\" { \"PersonaName\" \"Known without userdata\" } }");
        var sourceDir = Path.Combine(fixture, "userdata", "1", "730", "local", "cfg");
        Directory.CreateDirectory(sourceDir);
        await File.WriteAllBytesAsync(Path.Combine(sourceDir, "cs2_user_convars_0_slot0.vcfg"), source);
        await File.WriteAllTextAsync(Path.Combine(sourceDir, "unrelated-secret.txt"), "ignored");
        Directory.CreateDirectory(Path.Combine(fixture, "userdata", "2"));
        var dotaRemote=Path.Combine(fixture,"userdata","1","570","remote");
        Directory.CreateDirectory(dotaRemote);
        await File.WriteAllTextAsync(Path.Combine(dotaRemote,"guide_42.build"),"\"itembuild\" { \"Title\" \"Test guide\" }");
        var scan = await new SteamDiscoveryService().ScanAsync(fixture);
        Check(scan.Accounts.Count == 3 && scan.Accounts.Single(a => a.AccountId == "1").Name == "Main Account" && scan.Accounts.Single(a => a.AccountId == "2").SteamId64 == "76561197960265730", "Discover named, orphan and missing-data accounts");
        var game = scan.Configs.Single(c => c.AccountId == "1" && c.Game == GameId.Cs2);
        Check(game.Files.Count == 1 && game.Files[0].RelativePath == convarsPath && game.Health == HealthStatus.Healthy, "Discovery recognizes supported files and ignores unrelated data");
        Check(scan.Configs.Single(c => c.AccountId == "3" && c.Game == GameId.Dota2).Files.Count == 0, "Missing config account remains an available target");
        Check(scan.Configs.Single(c=>c.AccountId=="1"&&c.Game==GameId.Dota2).Files.Single().RelativePath=="remote/guide_42.build" && !GameRules.IsAllowed(GameId.Dota2,"remote/unrelated.build"),"Discover numeric Dota root guides without accepting arbitrary cloud files");
        Console.WriteLine($"{passed} discovery/parser checks passed.");
        return passed;
    }
}
