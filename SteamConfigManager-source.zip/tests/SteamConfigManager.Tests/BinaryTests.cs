using System.Buffers.Binary;
using System.Text;
using SteamConfigManager.Core;

internal static class BinaryTests
{
    public static async Task<int> RunAsync(string root)
    {
        int passed = 0;
        void Check(bool ok, string name) { if (!ok) throw new Exception("Binary regression failed: " + name); passed++; Console.WriteLine("PASS " + name); }
        void Reject(byte[] content, string name, string path = "remote/cfg/herobuilds.cfg")
        {
            bool refused = false; try { ConfigValidationService.Validate(Entry(path, content), GameId.Dota2); } catch (InvalidDataException) { refused = true; }
            Check(refused, name);
        }
        Check(BinaryKeyValues.ComputeCrc32("123456789"u8) == 0xCBF43926, "CRC32 matches independent standard check vector");
        var payload = Payload("HeroBuildConfig"); var valid = Envelope(payload);
        ConfigValidationService.Validate(Entry("remote/cfg/herobuilds.cfg", valid), GameId.Dota2);
        Check(true, "Dota VBKV header checksum and nested structure accepted");
        var altered = valid.ToArray(); altered[^3] ^= 1; Reject(altered, "VBKV checksum rejects changed bytes");
        var badHeader = valid.ToArray(); badHeader[0] = (byte)'X';
        bool headerRejected = false; try { BinaryKeyValues.Validate(badHeader, "HeroBuildConfig"); } catch (InvalidDataException) { headerRejected = true; }
        Check(headerRejected, "VBKV invalid header rejected");
        Reject(Envelope(payload[..^1]), "VBKV truncated end marker rejected despite matching CRC");
        Reject(Envelope([..payload, 0]), "VBKV trailing bytes rejected despite matching CRC");
        var unknown = payload.ToArray(); unknown["HeroBuildConfig".Length + 2] = 9;
        Reject(Envelope(unknown), "VBKV unknown typed variant rejected safely");
        Reject(Envelope(Payload("hero_facet_config")), "VBKV root must match the specific recognized filename");
        Reject(valid, "VBKV cannot masquerade as arbitrary console script", "remote/cfg/autoexec.cfg");
        var selected = new TransferSelection([ConfigCategory.HeroSettings], []);
        Check(GameRules.Merge(GameId.Dota2, "remote/cfg/herobuilds.cfg", valid, null, selected) is null, "VBKV category-only transfer refused");
        var whole = GameRules.Merge(GameId.Dota2, "remote/cfg/herobuilds.cfg", valid, null, new([], ["remote/cfg/herobuilds.cfg"]))!;
        Check(valid.SequenceEqual(whole), "Explicit VBKV whole-file transfer preserves every byte");

        var literalKeys = Encoding.UTF8.GetBytes("\"KeyBindings\" { \"Key\" \"\\\" \"Command\" \"test\" }");
        const string lst = "remote/cfg/dotakeys_personal.lst";
        ConfigValidationService.Validate(Entry(lst, literalKeys), GameId.Dota2);
        Check(literalKeys.SequenceEqual(GameRules.Merge(GameId.Dota2, lst, literalKeys, null, new([], [lst]))!), "Dota LST literal backslash validates and transfers without escape rewriting");
        const string guide = "remote/guide_123.build";
        var guideBytes = Encoding.UTF8.GetBytes("\"guidedata\" { \"Title\" \"My build\" }\0");
        ConfigValidationService.Validate(Entry(guide, guideBytes), GameId.Dota2);
        Check(guideBytes.SequenceEqual(GameRules.Merge(GameId.Dota2, guide, guideBytes, null, new([ConfigCategory.ItemBuilds], []))!), "Dota guide final NUL accepted and preserved exactly");
        Reject(Encoding.UTF8.GetBytes("\"guidedata\" { \"Title\" \"My\0build\" }\0"), "Dota guide embedded NUL remains invalid", guide);
        Reject([..guideBytes, 0], "Dota guide repeated trailing NUL remains invalid", guide);

        var app = Path.Combine(root, "binary-transaction"); var steam = Path.Combine(app, "Steam");
        var backups = new BackupService(app); var transfer = new ConfigTransferService(backups, new(app));
        var sourceRoot = Path.Combine(steam, "userdata", "100", "570"); var targetRoot = Path.Combine(steam, "userdata", "200", "570");
        const string relative = "remote/cfg/herobuilds.cfg";
        var source = SafePaths.Resolve(sourceRoot, relative); var target = SafePaths.Resolve(targetRoot, relative);
        Directory.CreateDirectory(Path.GetDirectoryName(source)!); Directory.CreateDirectory(Path.GetDirectoryName(target)!);
        await File.WriteAllBytesAsync(source, valid); var original = Envelope(Payload("HeroBuildConfig", 3)); await File.WriteAllBytesAsync(target, original);
        var profile = await transfer.CaptureAsync(await new DotaConfigService().DiscoverAsync(steam, "100"), "Binary Main");
        var zip = Path.Combine(app, "binary-profile.zip"); await new ImportExportService().ExportAsync(profile, zip);
        var imported = await new ImportExportService().ImportAsync(zip, GameId.Dota2);
        Check(imported.Files.Single().Content.SequenceEqual(valid), "VBKV profile ZIP roundtrip preserves original bytes");
        var plan = await transfer.PreviewAsync(imported, await new DotaConfigService().DiscoverAsync(steam, "200"), new([], [relative]));
        Check((await transfer.ApplyAsync(plan)).Success && Enumerable.SequenceEqual(valid, await File.ReadAllBytesAsync(target)), "VBKV transfer creates verified backup and writes exact bytes");
        Check((await transfer.RestoreAsync((await backups.ListAsync()).Single())).Success && Enumerable.SequenceEqual(original, await File.ReadAllBytesAsync(target)), "VBKV undo restores original binary bytes");
        return passed;
    }
    private static ProfileFile Entry(string path, byte[] content) => new(path, content, StorageIO.Hash(content));
    private static byte[] Payload(string root, int version = 2)
    {
        using var output = new MemoryStream();
        output.WriteByte(0); output.Write(Encoding.UTF8.GetBytes(root)); output.WriteByte(0);
        output.WriteByte(2); output.Write("version\0"u8); output.Write(BitConverter.GetBytes(version));
        output.WriteByte(0); output.Write("heroes\0"u8); output.WriteByte(1); output.Write("npc_dota_hero_axe\0example\0"u8);
        output.Write([11, 11, 11]); return output.ToArray();
    }
    private static byte[] Envelope(byte[] payload)
    {
        var result = new byte[payload.Length + 8]; "VBKV"u8.CopyTo(result); BinaryPrimitives.WriteUInt32LittleEndian(result.AsSpan(4), BinaryKeyValues.ComputeCrc32(payload)); payload.CopyTo(result, 8); return result;
    }
}
